# El Conejo (Beta 2)

A Spanish ↔ English language-learning RPG. Help the bunny collect carrots for Abuela's Carrot Festival across four worlds: the Garden, the Market Town, Forest and Hills, and the City (32 levels).

## Play

The game runs as a website. Open the GitHub Pages link for this repository, or run it locally (see below).

> Opening `index.html` by double-clicking will not load the levels, because browsers block loading the level files from your disk. Use GitHub Pages or a local server.

## Files

- `index.html` – the game
- `content/w1.json` … `w4.json` – the levels for each world
- `source/` – the source code the game is built from
  - `src/` – engine, art, scenes and screens
  - `content/w1.js` … `w4.js` – the level scripts (edit these to change levels)
  - `build.py` – rebuilds the game into `source/dist/`

## Run locally

```
python3 -m http.server 8000
```
Then open http://localhost:8000 in your browser.

## Edit and rebuild

Needs Python 3 and Node.js.

```
cd source
python3 build.py
```
Copy `source/dist/index.html` and `source/dist/content/*.json` to the top of the repository to update the live game.
