const {w,o,a,m,T}=require('./lib.js');
module.exports={
id:1,key:'garden',color:'#5E9C45',
name:T('El Jardín','The Garden'),
cast:['turtle','mole','fox','hen','squirrel','frog'],
intro:{en:'Abuela is throwing the Carrot Festival in the city, and she asked you to bring carrots from every place on the way. Your trip starts at home, in the garden. Meet the neighbors and learn their words.',
       es:'La Abuela hace la Fiesta de la Zanahoria en la ciudad y te pidió llevar zanahorias de cada lugar del camino. Tu viaje empieza en casa, en el jardín. Conoce a los vecinos y aprende sus palabras.'},
outro:{en:'The big gate is open. Past it, the road runs down to the market town.',
       es:'La gran puerta está abierta. Detrás, el camino baja hasta el pueblo del mercado.'},
levels:[

/* 1-1 greetings */
{id:'w1l1',diff:'easy',npc:'turtle',
 title:T('La puerta del jardín','The Garden Gate'),theme:{en:'Greetings',es:'Saludos'},
 can:{en:'say hello, give your name and say goodbye.',es:'saludar, decir tu nombre y despedirte.'},
 note:{en:'Spanish has a greeting for each part of the day: <b>buenos días</b> in the morning, <b>buenas tardes</b> after lunch and <b>buenas noches</b> at night. <b>Buenas noches</b> works for both hello and goodbye after dark.',
       es:'En inglés, <b>good morning</b>, <b>good afternoon</b> y <b>good evening</b> sirven para saludar. Pero <b>good night</b> solo se usa para despedirse o antes de dormir, nunca para saludar.'},
 lesson:[w('hola','hello',[],['hi','hey']),w('buenos días','good morning',['buen dia'],['morning']),w('¿cómo te llamas?',"what's your name?",['cual es tu nombre'],['what is your name']),
   w('me llamo','my name is',['mi nombre es','yo me llamo'],['i am called']),w('mucho gusto','nice to meet you',['encantado','encantada','un placer','un gusto'],['pleased to meet you','nice meeting you','good to meet you']),
   w('gracias','thank you',['muchas gracias'],['thanks','thank you very much']),w('adiós','goodbye',['chao','chau'],['bye']),w('la puerta','the gate',['puerta'],['gate']),
   w('está cerrada',"it's closed",[],['it is closed']),w('el camino','the path',['camino'],['path','the trail']),w('la cerca','the fence',['cerca'],['fence'])],
 scene:{w:1200,sky:'day',ground:'grass',back:'hills',sun:120,start:[-40,270],
  items:[['path','M-30 280C200 278 420 276 620 274S800 264 836 248S900 238 948 242',24],
   ['patch',972,232,1176,[232,254,276],{1:{988:'c1'}}],
   ['g','fenceMid',[['fence',440,800,236,592]]],['gate',592,236,T('JARDÍN','GARDEN'),'gate'],
   ['sign',826,232,'→',1,'pathEnd'],['bush',380,238,.8],['flowerpot',332,244,'#E2504A'],
   ['scatter',11,0,430,200,296,26],['scatter',12,430,860,248,298,10,[[500,800]]],['scatter',13,1180,1200,200,296,3]],
  finale:{walk:[[946,256]],pull:'c1',src:[990,226]}},
 outro:'¡Buen provecho,|Enjoy your meal, / Conejo!|Conejo!',
 nodes:[
  {t:'say',b:[150,270],n:[280,272],line:'Buenos días,|Good morning, / conejito.|little bunny.',opts:[
    o('Buenos días.','Good morning.',1),
    o('Buenas noches.','Good night.',0,'"Buenas noches" is for nighttime. The sun is up!','"Good night" es para la noche, y en inglés solo para despedirse. ¡Hay sol!'),
    o('Adiós.','Goodbye.',0,'You just arrived. "Adiós" is for leaving.','Acabas de llegar. "Goodbye" es para irse.')]},
  {t:'type',b:[150,270],n:[280,272],line:'¿Cómo te llamas?|What\'s your name?',
    prompt:{en:'Tell her your name is Conejo.',es:'Dile que te llamas Conejo.'},
    say:{es:'Me llamo Conejo.',en:'My name is Conejo.'},
    ans:{es:['mi nombre es conejo','soy conejo','yo soy conejo','yo me llamo conejo'],en:['i am conejo',"i'm conejo",'call me conejo']}},
  {t:'listen',b:[150,270],n:[280,272],line:'Mucho gusto.|Nice to meet you. / Las zanahorias|The carrots / están en el jardín.|are in the garden.',opts:[
    m('Nice to meet you. The carrots are in the garden.','Mucho gusto. Las zanahorias están en el jardín.',1),
    m('Nice to meet you. The carrots are in the market.','Mucho gusto. Las zanahorias están en el mercado.',0,'Listen for the last word: "jardín" is garden.','Escucha la última palabra: "garden" es jardín.'),
    m('Thank you. The gate is in the garden.','Gracias. La puerta está en el jardín.',0,'She started with "mucho gusto", nice to meet you, and talked about carrots.','Empezó con "nice to meet you", mucho gusto, y habló de zanahorias.')]},
  {t:'act',b:[482,268],n:[570,250],line:'La puerta|The gate / está cerrada.|is closed. / Sigue el camino|Follow the path / hasta el final|to the end / de la cerca.|of the fence.',opts:[
    a('Path to the end','Camino al final',{ok:1,hot:'pathEnd',at:[770,296],walk:[[600,276],[690,272],[790,262],[838,246],[900,240]]}),
    a('Jump the fence','Saltar la cerca',{hot:'fenceMid',at:[683,296],walk:[[566,284],[684,248]],fx:'bonk',fb:{en:'She said to follow the path to the end of the fence, not to jump it.',es:'Dijo que sigas el camino hasta el final de la cerca, no que la saltes.'}}),
    a('Wait at the gate','Esperar en la puerta',{hot:'gate',at:[596,296],walk:[[534,258]],fx:'sleep',fb:{en:'"La puerta está cerrada": the gate is closed. Waiting won\'t help.',es:'"The gate is closed": la puerta está cerrada. Esperar no sirve.'}})]},
  {t:'say',b:[912,244],n:[852,258],line:'¡Ya llegaste!|You made it! / ¡Adiós,|Goodbye, / conejo!|bunny!',opts:[
    o('¡Adiós! ¡Gracias!','Goodbye! Thank you!',1),
    o('¡Hola!','Hello!',0,'"Hola" is for arriving. She is saying goodbye.','"Hello" es para llegar. Ella se está despidiendo.'),
    o('Me llamo Tortuga.','My name is Turtle.',0,'That\'s her name, not yours!','¡Ese es su nombre, no el tuyo!')]}
 ]},

/* 1-2 who is who: ser */
{id:'w1l2',diff:'easy',npc:'mole',
 title:T('Los montículos del topo','The Mole\'s Mounds'),theme:{en:'Who is who: soy, eres, es',es:'Quién es quién: I am, you are, he is'},
 can:{en:'say who you are, ask who someone is, and point to things next to each other.',es:'decir quién eres, preguntar quién es alguien y señalar cosas que están al lado.'},
 note:{en:'<b>Ser</b> says who or what something is: <b>soy</b> (I am), <b>eres</b> (you are), <b>es</b> (he, she, it is). Use it for names and identity: <b>Soy un conejo.</b> For where something is, Spanish switches to <b>estar</b>: <b>Mi casa está al lado de la regadera.</b>',
       es:'En inglés, <b>I am, you are, he/she/it is</b> sirven para lo que es algo y también para dónde está: <b>I am a rabbit</b> y <b>My house is next to the watering can</b>. Inglés no separa ser y estar.'},
 lesson:[w('¿quién eres?','who are you?',['quien eres tu'],['who are u']),w('soy','I am',['yo soy'],["i'm"]),w('eres','you are',['tu eres'],["you're"]),w('es','he is',['el es'],["he's",'she is','it is']),
   w('el amigo','the friend',['amigo','mi amigo'],['friend','my friend']),w('la regadera','the watering can',['regadera'],['watering can']),w('la carretilla','the wheelbarrow',['carretilla'],['wheelbarrow']),
   w('al lado de','next to',['junto a'],['beside','by']),w('aquí','here',['aca'],['over here'])],
 scene:{w:1000,sky:'day',ground:'meadow',back:'hills',sun:860,start:[-40,274],
  items:[['path','M-30 280C200 279 400 278 600 278S800 276 1030 276',22],
   ['tree',150,236,.9],['bush',236,240,.7,'#5E9C45'],
   ['g','byCan',[['wateringCan',466,236],['molehill',500,252]]],
   ['g','byBarrow',[['wheelbarrow',572,234],['molehill',612,252]]],
   ['g','byTree',[['tree',682,236,.6],['molehill',714,252]]],
   ['molehill',344,254],['patch',840,226,980,[226,248],{0:{856:'c2'}}],
   ['scatter',21,0,440,200,296,20],['scatter',22,800,1000,262,298,6]],
  finale:{walk:[[820,262]],pull:'c2',src:[858,214]}},
 outro:'¡Aquí están|Here they are, / tus zanahorias,|your carrots, / amigo!|friend!',
 nodes:[
  {t:'say',b:[230,274],n:[344,262],line:'¡Hola!|Hi! / ¿Quién eres?|Who are you?',opts:[
    o('Soy Conejo.','I am Conejo.',1),
    o('Estoy Conejo.','I am Conejo.',0,'Names and identity use "ser": soy. "Estoy" is for where you are or how you feel.','En inglés las dos se dicen "I am", pero en español el nombre va con "soy", no con "estoy".'),
    o('Eres Conejo.','You are Conejo.',0,'"Eres" means "you are". He would think HE is Conejo!','"You are" significa "eres". ¡Pensaría que él es Conejo!')]},
  {t:'type',b:[230,274],n:[344,262],line:'Yo soy Topo.|I am Mole. / ¿Eres amigo|Are you a friend / de Tortuga?|of Turtle\'s?',
    prompt:{en:'Say yes, you are her friend.',es:'Di que sí, que eres su amigo.'},
    say:{es:'Sí, soy su amigo.',en:'Yes, I am her friend.'},
    ans:{es:['si soy amigo de tortuga','si soy su amigo','si soy amigo','soy su amigo','si yo soy su amigo','si soy amiga de tortuga','si soy su amiga'],en:["yes i'm her friend",'yes i am a friend','yes i am turtles friend',"yes i'm turtle's friend","yes i am turtle's friend",'i am her friend']}},
  {t:'act',b:[420,284],n:[340,262],line:'¡Muy bien, amigo!|Very good, friend! / Mi casa está|My house is / al lado de|next to / la regadera.|the watering can.',opts:[
    a('By the can','Junto a la regadera',{ok:1,hot:'byCan',at:[492,298],walk:[[460,282]]}),
    a('By the wheelbarrow','Junto a la carretilla',{hot:'byBarrow',at:[598,298],walk:[[572,284]],fx:'look',fb:{en:'"La carretilla" is the wheelbarrow. He said "la regadera", the watering can.',es:'"Wheelbarrow" es la carretilla. Dijo "watering can", la regadera.'}}),
    a('By the tree','Junto al árbol',{hot:'byTree',at:[700,298],walk:[[676,284]],fx:'look',fb:{en:'No tree in what he said. Listen for "la regadera", the watering can.',es:'No dijo nada de un árbol. Busca "watering can", la regadera.'}})]},
  {t:'listen',b:[420,284],n:[500,256],line:'Sí, aquí es.|Yes, this is it. / Mi casa|My house / es pequeña.|is small.',opts:[
    m('Yes, this is it. My house is small.','Sí, aquí es. Mi casa es pequeña.',1),
    m('No, it\'s not here. My house is big.','No, no es aquí. Mi casa es grande.',0,'He began with "sí", yes. You found it.','Empezó con "yes", sí. La encontraste.'),
    m('Yes, this is it. Your house is small.','Sí, aquí es. Tu casa es pequeña.',0,'"Mi casa" is MY house: his, not yours.','"My house" es mi casa: la de él, no la tuya.')]},
  {t:'say',b:[420,284],n:[500,256],line:'¿Quieres zanahorias,|Do you want carrots, / amigo?|friend?',opts:[
    o('Sí, gracias, amigo.','Yes, thanks, friend.',1),
    o('Sí, eres zanahorias.','Yes, you are carrots.',0,'"Eres" means you are. He is a mole, not carrots!','"You are" significa eres. ¡Él es un topo, no zanahorias!'),
    o('Adiós, amigo.','Goodbye, friend.',0,'He is offering you carrots. Don\'t leave yet!','Te está ofreciendo zanahorias. ¡No te vayas todavía!')]}
 ]},

/* 1-3 asking politely */
{id:'w1l3',diff:'easy',npc:'fox',
 title:T('El seto del zorro','The Fox\'s Hedge'),theme:{en:'Asking politely',es:'Pedir con cortesía'},
 can:{en:'ask for things politely and ask permission.',es:'pedir cosas con cortesía y pedir permiso.'},
 note:{en:'<b>Quiero</b> (I want) is fine with friends, but with <b>por favor</b> it sounds much kinder. To ask permission, use <b>¿Puedo…?</b> (Can I…?) plus the action: <b>¿Puedo pasar?</b>',
       es:'En inglés, <b>I want</b> suena brusco con desconocidos. Es más amable <b>I would like</b> o <b>Can I have…, please?</b> Para pedir permiso: <b>Can I…?</b> o <b>May I…?</b>'},
 lesson:[w('quiero','I want',['yo quiero'],['i would like']),w('por favor','please',['porfa'],['pls']),w('la zanahoria','the carrot',['zanahoria','una zanahoria'],['carrot','a carrot']),
   w('¿puedo pasar?','can I pass?',['puedo pasar por favor'],['may i pass','can i get by','can i come through']),w('sí','yes',['si claro'],['yeah','yep']),w('detrás de','behind',['atras de'],['in back of']),
   w('el árbol','the tree',['arbol','un arbol'],['tree','a tree']),w('el río','the river',['rio'],['river','the stream']),w('la piedra','the rock',['piedra','la roca'],['rock','the stone'])],
 scene:{w:1000,sky:'day',ground:'grass',back:'hills',sun:860,start:[-40,272],
  items:[['path','M-30 280C140 278 280 276 345 272S500 268 580 262S640 262 690 266',22],
   ['bush',300,250,1.1,'#5E9C45'],['bush',392,250,1.1,'#5E9C45'],['bush',290,226,.9,'#6FAE52'],['bush',402,226,.9,'#6FAE52'],['zone',258,192,178,64],
   ['stream',782,786,30,84,'river'],
   ['pile',588,240],['tree',580,240,1.1,'oak'],['rock',694,250,1,'bigrock'],['zone',562,186,38,58],
   ['scatter',21,0,280,200,296,18],['scatter',22,420,560,200,296,7],['scatter',23,880,1000,200,296,8]],
  finale:{walk:[[600,250]],src:[636,252]}},
 outro:'¡Gracias,|Thanks, / conejo!|bunny!',
 nodes:[
  {t:'say',b:[230,270],n:[345,266],line:'¡Alto!|Stop! / Este es mi seto.|This is my hedge. / ¿Qué quieres?|What do you want?',opts:[
    o('Quiero zanahorias, por favor.','I want carrots, please.',1),
    o('Quiero un zorro.','I want a fox.',0,'"Zorro" means fox. He might take that the wrong way!','"Fox" significa zorro. ¡Se puede ofender!'),
    o('Tengo zanahorias.','I have carrots.',0,'"Tengo" means "I have". He\'ll think you don\'t need any.','"I have" significa "tengo". Pensará que no necesitas.')]},
  {t:'type',b:[230,270],n:[345,266],line:'Primero,|First, / pide permiso|ask permission / para pasar.|to pass.',
    prompt:{en:'Ask: "Can I pass, please?"',es:'Pregunta: "¿Puedo pasar, por favor?"'},
    say:{es:'¿Puedo pasar, por favor?',en:'Can I pass, please?'},
    ans:{es:['por favor puedo pasar','puedo pasar'],en:['may i pass please','please can i pass','please may i pass','can i please pass','may i please pass','can i pass','may i pass']}},
  {t:'act',b:[514,268],via:[[345,272]],n:[448,254],line:'Sí, pasa.|Yes, go ahead. / Las zanahorias están|The carrots are / detrás del árbol.|behind the tree.',opts:[
    a('Behind the tree','Detrás del árbol',{ok:1,hot:'oak',at:[568,296],walk:[[556,258],[584,248]],reveal:'pile'}),
    a('Under the rock','Debajo de la piedra',{hot:'bigrock',at:[650,296],walk:[[668,264]],fx:'look',fb:{en:'"Detrás del árbol" means behind the tree. Nothing under this rock.',es:'"Behind the tree" significa detrás del árbol. No hay nada debajo de la piedra.'}}),
    a('Dig by the river','Excavar junto al río',{hot:'river',at:[732,296],walk:[[750,268]],fx:'splash',fb:{en:'He said "el árbol", the tree. Nothing about a river.',es:'Dijo "the tree", el árbol. Nada de un río.'}})]},
  {t:'say',b:[584,248],n:[516,268],line:'¡Las encontraste!|You found them! / ¿Me das|Will you give me / una zanahoria,|a carrot, / por favor?|please?',opts:[
    o('Sí, una para ti.','Yes, one for you.',1),
    o('No, por favor.','No, please.',0,'He asked nicely. Sharing is the polite move, and "no, por favor" doesn\'t answer him.','Te pidió con cortesía. Lo amable es compartir, y "no, please" no le responde.'),
    o('Quiero pasar.','I want to pass.',0,'You already passed! He is asking for a carrot.','¡Ya pasaste! Te está pidiendo una zanahoria.')]}
 ]},

/* 1-4 colors */
{id:'w1l4',diff:'easy',npc:'hen',
 title:T('Las puertas de colores','The Colored Doors'),theme:{en:'Colors',es:'Colores'},
 can:{en:'name colors and ask what color something is.',es:'nombrar colores y preguntar de qué color es algo.'},
 note:{en:'In Spanish the color comes <b>after</b> the thing, and it matches it: <b>la puerta roja</b>, <b>el techo rojo</b>. Colors ending in -e, like <b>verde</b> and <b>azul</b>, stay the same for both.',
       es:'En inglés el color va <b>antes</b> de la cosa y nunca cambia: <b>the red door</b>, <b>the red roofs</b>. No se dice "the door red".'},
 lesson:[w('rojo','red',['roja'],[]),w('azul','blue',[],[]),w('amarillo','yellow',['amarilla'],[]),w('verde','green',[],[]),w('blanco','white',['blanca'],[]),
   w('¿de qué color es?','what color is it?',['de que color es','que color es'],['what colour is it','what color is that']),w('la casita','the little house',['casita'],['little house','the small house']),
   w('el gallinero','the henhouse',['gallinero'],['henhouse','the chicken coop','chicken coop']),w('la puerta roja','the red door',['puerta roja'],['red door'])],
 scene:{w:1000,sky:'warm',ground:'grass',back:'hills',sun:140,start:[-40,274],
  items:[['path','M-30 282C200 281 420 280 640 279S860 276 1030 276',22],
   ['henhouse',280,244,'#3F7FBF','coop'],['scarecrow',140,246],
   ['pile',470,240,'pile'],['shed',500,240,'#C0563F','','shedR'],['doghouse',592,246,'#F2C230','dogY'],['henhouse',672,244,'#3D7A33','coopG'],
   ['flowerbed',800,250,100,'#F2C230'],
   ['scatter',41,0,140,200,296,10],['scatter',42,860,1000,262,298,6]],
  finale:{walk:[[530,286]],src:[506,254]}},
 outro:'¡Qué bonitas|How pretty / son!|they are! / ¡Buen viaje!|Have a good trip!',
 nodes:[
  {t:'say',b:[220,282],n:[345,264],line:'¡Cocorocó!|Cock-a-doodle-doo! / Hola, conejo.|Hello, bunny. / ¿Te gusta|Do you like / mi casita azul?|my little blue house?',opts:[
    o('Sí, ¡es muy bonita!','Yes, it\'s very pretty!',1),
    o('Sí, ¡es muy roja!','Yes, it\'s very red!',0,'"Azul" is blue. Her house door is blue, not red.','"Blue" es azul. La puerta de su casa es azul, no roja.'),
    o('No, soy un conejo.','No, I\'m a bunny.',0,'She asked if you like her house, not who you are.','Te preguntó si te gusta su casa, no quién eres.')]},
  {t:'type',b:[220,282],n:[345,264],line:'Gracias.|Thanks. / ¿De qué color es|What color is / la puerta?|the door?',
    prompt:{en:'Say that it is blue.',es:'Di que es azul.'},
    say:{es:'Es azul.',en:'It is blue.'},
    ans:{es:['azul','la puerta es azul','es de color azul'],en:["it's blue",'blue','the door is blue']}},
  {t:'act',b:[420,284],n:[345,264],line:'Las zanahorias|The carrots / están en la casita|are in the little house / de la puerta roja.|with the red door.',opts:[
    a('Red door','Puerta roja',{ok:1,hot:'shedR',at:[500,298],walk:[[480,284]],reveal:'pile'}),
    a('Yellow roof','Techo amarillo',{hot:'dogY',at:[592,298],walk:[[592,286]],fx:'look',fb:{en:'"Rojo/roja" is red. This house has a yellow roof: "amarillo".',es:'"Red" es rojo. Esta casita tiene el techo amarillo: "yellow".'}}),
    a('Green door','Puerta verde',{hot:'coopG',at:[672,298],walk:[[672,286]],fx:'look',fb:{en:'This door is green: "verde". She said "roja", red.',es:'Esta puerta es verde: "green". Ella dijo "red", roja.'}})]},
  {t:'listen',b:[480,284],n:[400,268],line:'¡Muy bien!|Very good! / Llévate|Take / las zanahorias|the carrots / y una flor amarilla.|and a yellow flower.',opts:[
    m('Very good! Take the carrots and a yellow flower.','¡Muy bien! Llévate las zanahorias y una flor amarilla.',1),
    m('Very good! Take the carrots and a white flower.','¡Muy bien! Llévate las zanahorias y una flor blanca.',0,'"Amarilla" is yellow. "Blanca" would be white.','"Yellow" es amarilla. "White" sería blanca.'),
    m('Very good! Leave the carrots here.','¡Muy bien! Deja las zanahorias aquí.',0,'"Llévate" means take them with you.','"Take" significa llévate: llévalas contigo.')]},
  {t:'say',b:[480,284],n:[400,268],line:'¿De qué color es|What color is / tu zanahoria?|your carrot?',opts:{
    es:[{t:'Es naranja.',ok:1},{t:'Es verde.',fb:'The leaves are green, but the carrot itself is orange: "naranja".'},{t:'Es azul.',fb:'A blue carrot? Carrots are orange: "naranja".'}],
    en:[{t:'It\'s orange.',ok:1},{t:'It\'s green.',fb:'Las hojas son verdes, pero la zanahoria es naranja: "orange".'},{t:'It\'s blue.',fb:'¿Una zanahoria azul? Las zanahorias son naranjas: "orange".'}]}}
 ]},

/* 1-5 numbers */
{id:'w1l5',diff:'easy',npc:'squirrel',
 title:T('Las hileras de la ardilla','The Squirrel\'s Rows'),theme:{en:'Numbers 1 to 10',es:'Números del 1 al 10'},
 can:{en:'count to ten and ask how many there are.',es:'contar hasta diez y preguntar cuántos hay.'},
 note:{en:'<b>Hay</b> means both "there is" and "there are": <b>hay una hilera</b>, <b>hay seis zanahorias</b>. To ask how many, <b>¿cuántos?</b> matches the thing: <b>¿cuántas zanahorias?</b> (feminine) but <b>¿cuántos árboles?</b>',
       es:'En inglés, <b>hay</b> cambia: <b>there is</b> para uno y <b>there are</b> para varios. Y para contar se pregunta <b>how many…?</b>: <b>How many carrots are there?</b>'},
 lesson:[w('uno','one',['1','una'],['1']),w('dos','two',['2'],['2']),w('tres','three',['3'],['3']),w('cuatro','four',['4'],['4']),w('cinco','five',['5'],['5']),w('seis','six',['6'],['6']),
   w('diez','ten',['10'],['10']),w('hay','there are',[],['there is']),w('¿cuántas?','how many?',['cuantos'],['how much']),w('la hilera','the row',['hilera','la fila'],['row'])],
 scene:{w:1050,sky:'day',ground:'meadow',back:'hills',sun:900,start:[-40,276],
  items:[['path','M-30 282C200 282 420 282 640 282S860 280 1080 280',22],
   ['tree',140,238,1],['stump',300,252],
   ['g','row2',[['bed',464,228,542,262],['bedRow',466,540,250,[488,518]]]],
   ['g','row4',[['bed',558,228,636,262],['bedRow',560,634,250,[572,590,608,626]]]],
   ['g','row6',[['bed',652,228,730,262],['bedRow',654,728,250,[663,676,689,702,715,728],{676:'c5'}]]],
   ['wheelbarrow',830,252],['scatter',51,0,420,200,298,16],['scatter',52,880,1050,262,298,6]],
  finale:{walk:[[690,282]],pull:'c5',src:[676,230]}},
 outro:'¡Seis zanahorias!|Six carrots! / ¡Qué suerte!|How lucky!',
 nodes:[
  {t:'say',b:[220,278],n:[300,232],line:'¡Hola!|Hi! / Cuento zanahorias.|I\'m counting carrots. / Uno, dos, tres…|One, two, three…',opts:[
    o('Cuatro, cinco, seis.','Four, five, six.',1),
    o('Tres, dos, uno.','Three, two, one.',0,'She is counting up, so keep going: cuatro, cinco, seis.','Ella cuenta hacia arriba. Sigue: four, five, six.'),
    o('Diez, dos, cinco.','Ten, two, five.',0,'Those are out of order. After "tres" comes "cuatro".','Están en desorden. Después de "three" viene "four".')]},
  {t:'listen',b:[220,278],n:[300,232],line:'¡Bien!|Good! / Hay tres hileras|There are three rows / en mi huerto.|in my garden.',opts:[
    m('There are three rows in my garden.','Hay tres hileras en mi huerto.',1),
    m('There are ten rows in my garden.','Hay diez hileras en mi huerto.',0,'"Tres" is three. "Diez" would be ten.','"Three" es tres. "Ten" sería diez.'),
    m('There are three carrots in my garden.','Hay tres zanahorias en mi huerto.',0,'"Hileras" are rows, not carrots.','"Rows" son hileras, no zanahorias.')]},
  {t:'act',b:[430,284],n:[300,262],line:'Tus zanahorias|Your carrots / están en la hilera|are in the row / que tiene seis.|that has six.',opts:[
    a('Row with 2','Hilera con 2',{hot:'row2',at:[503,298],walk:[[490,284]],fx:'look',fb:{en:'Count them: this row has "dos", two. She said "seis", six.',es:'Cuéntalas: esta hilera tiene "two", dos. Ella dijo "six", seis.'}}),
    a('Row with 4','Hilera con 4',{hot:'row4',at:[597,298],walk:[[584,284]],fx:'look',fb:{en:'This row has "cuatro", four. Find the one with "seis", six.',es:'Esta hilera tiene "four", cuatro. Busca la que tiene "six", seis.'}}),
    a('Row with 6','Hilera con 6',{ok:1,hot:'row6',at:[691,298],walk:[[676,284]]})]},
  {t:'type',b:[676,284],n:[590,282],line:'¡Sí!|Yes! / ¿Cuántas|How many / zanahorias quieres?|carrots do you want?',
    prompt:{en:'Ask for two, please.',es:'Pide dos, por favor.'},
    say:{es:'Dos, por favor.',en:'Two, please.'},
    ans:{es:['quiero dos','quiero dos por favor','dos zanahorias por favor','quiero dos zanahorias','dos','2 por favor'],en:['two','i want two','two carrots please','i would like two','i would like two please','2 please']}},
  {t:'say',b:[676,284],n:[590,282],line:'Dos para ti|Two for you / y cuatro para mí.|and four for me. / ¿Cuántas hay?|How many are there?',opts:[
    o('Hay seis.','There are six.',1),
    o('Hay cinco.','There are five.',0,'Two plus four: dos y cuatro son seis.','Two plus four: two and four make six.'),
    o('Hay diez.','There are ten.',0,'Count again: dos y cuatro son seis, not ten.','Cuenta otra vez: two and four make six, no ten.')]}
 ]},

/* 1-6 prepositions */
{id:'w1l6',diff:'medium',npc:'frog',
 title:T('El estanque','The Pond'),theme:{en:'Where things are',es:'Dónde están las cosas'},
 can:{en:'ask where something is and say on, under, behind and next to.',es:'preguntar dónde está algo y decir encima, debajo, detrás y al lado.'},
 note:{en:'Location always uses <b>estar</b>: <b>¿Dónde está?</b> Most place words end in <b>de</b>: <b>debajo de</b>, <b>detrás de</b>, <b>encima de</b>. And <b>de + el</b> joins into <b>del</b>: <b>detrás del muro</b>.',
       es:'En inglés, las palabras de lugar son cortas y van solas: <b>under the bridge</b>, <b>behind the wall</b>, <b>on the leaf</b>. No llevan "of".'},
 lesson:[w('¿dónde está?','where is it?',['donde esta'],["where's it",'where is']),w('¿dónde están?','where are they?',['donde estan'],['where are']),w('encima de','on top of',['sobre','arriba de'],['on','on top']),
   w('debajo de','under',['abajo de'],['underneath','below']),w('detrás de','behind',['atras de'],[]),w('el puente','the bridge',['puente'],['bridge']),
   w('la maceta','the flowerpot',['maceta'],['flowerpot','the pot']),w('el muro','the wall',['muro','la pared'],['wall']),w('la hoja','the leaf',['hoja'],['leaf'])],
 scene:{w:1000,sky:'day',ground:'grass',back:'hills',sun:160,start:[-40,276],
  items:[['raw','<path d="M176 285Q178 270 210 266Q250 262 290 266Q330 272 334 284Q334 296 296 298Q250 300 206 298Q176 294 176 285Z" fill="#6FB7D9" stroke="#25311F" stroke-width="1.6"/><path d="M190 280Q206 272 236 271" stroke="#9FD3EC" stroke-width="2.4" fill="none" stroke-linecap="round"/><g class="ripple"><path d="M262 290q6-3 12 0" stroke="#fff" stroke-width="2" fill="none"/></g>'],
   ['zone',176,262,160,40],['reeds',176,272],['reeds',338,276],['pad',274,282,14],['pad',214,291,9,1],
   ['path','M-30 280C120 280 150 252 360 250S560 250 610 250',20],['path','M710 250C800 250 900 252 1030 254',20],
   ['stream',662,658,52,64,'brook'],['footbridge',660,252,116,'bridge'],
   ['flowerpot',560,236,'#E2504A','pot'],['pile',820,232,'pile'],['stoneWall',750,870,232,'wall'],
   ['scatter',61,360,520,200,240,8],['scatter',62,900,1000,262,298,5],['scatter',63,0,170,200,296,8]],
  finale:{walk:[[900,270]],src:[856,240]}},
 outro:'¡Croac!|Ribbit! / ¡Hasta luego,|See you later, / conejo!|bunny!',
 nodes:[
  {t:'say',b:[380,258],n:[274,282],line:'¡Croac!|Ribbit! / Estoy encima de|I\'m on top of / la hoja.|the leaf. / ¿Qué buscas?|What are you looking for?',opts:[
    o('Busco zanahorias.','I\'m looking for carrots.',1),
    o('Busco la hoja.','I\'m looking for the leaf.',0,'She is ON the leaf. You want carrots!','Ella está ENCIMA de la hoja. ¡Tú quieres zanahorias!'),
    o('Estoy debajo de la hoja.','I am under the leaf.',0,'"Debajo de" is under. You\'re on the grass, not under a leaf.','"Under" es debajo de. Estás en la hierba, no debajo de una hoja.')]},
  {t:'type',b:[380,258],n:[274,282],line:'Ah, zanahorias…|Ah, carrots…',
    prompt:{en:'Ask her where they are.',es:'Pregúntale dónde están.'},
    say:{es:'¿Dónde están las zanahorias?',en:'Where are the carrots?'},
    ans:{es:['donde estan','donde estan las zanahorias por favor','donde estan por favor'],en:['where are they','where are the carrots please','where are they please']}},
  {t:'act',b:[510,256],n:[430,246],line:'No están debajo del puente.|They aren\'t under the bridge. / Están detrás del muro.|They\'re behind the wall.',opts:[
    a('Under the bridge','Debajo del puente',{hot:'bridge',at:[656,298],walk:[[600,262],[650,276]],fx:'splash',fb:{en:'"No están debajo del puente": they are NOT under the bridge.',es:'"They aren\'t under the bridge": NO están debajo del puente.'}}),
    a('In the flowerpot','En la maceta',{hot:'pot',at:[560,298],walk:[[556,256]],fx:'look',fb:{en:'She never said "la maceta". Listen for "detrás del muro".',es:'Nunca dijo "flowerpot". Busca "behind the wall".'}}),
    a('Behind the wall','Detrás del muro',{ok:1,hot:'wall',at:[810,298],walk:[[600,252],[716,252],[800,262],[892,268]],reveal:'pile'})]},
  {t:'listen',b:[892,268],n:[800,280],line:'¡Sí, ahí están!|Yes, there they are! / Mi casa está|My house is / al lado del puente.|next to the bridge.',opts:[
    m('Yes, there they are! My house is next to the bridge.','¡Sí, ahí están! Mi casa está al lado del puente.',1),
    m('Yes, there they are! My house is under the bridge.','¡Sí, ahí están! Mi casa está debajo del puente.',0,'"Al lado de" is next to. "Debajo de" would be under.','"Next to" es al lado de. "Under" sería debajo de.'),
    m('No, they aren\'t there.','No, no están ahí.',0,'She said "sí", yes. You found them.','Dijo "yes", sí. Las encontraste.')]}
 ]},

/* 1-7 weather */
{id:'w1l7',diff:'medium',npc:'mole',
 title:T('Un día de lluvia','A Rainy Day'),theme:{en:'Weather',es:'El tiempo'},
 can:{en:'say what the weather is like and find shelter.',es:'decir qué tiempo hace y buscar refugio.'},
 note:{en:'Most weather uses <b>hace</b> (it makes): <b>hace sol</b>, <b>hace frío</b>, <b>hace calor</b>. Rain and snow are verbs of their own: <b>llueve</b> (it rains), <b>está lloviendo</b> (it\'s raining).',
       es:'En inglés el tiempo siempre lleva <b>it</b>: <b>it\'s raining</b>, <b>it\'s cold</b>, <b>it\'s sunny</b>. No se puede decir solo "is raining".'},
 lesson:[w('llueve','it\'s raining',['esta lloviendo'],['it rains','it is raining']),w('hace frío','it\'s cold',['hace mucho frio'],['it is cold']),w('hace sol','it\'s sunny',[],['it is sunny']),
   w('¿qué tiempo hace?','what\'s the weather like?',['que tiempo hace','como esta el tiempo'],['what is the weather like','how is the weather']),w('el cobertizo','the shed',['cobertizo'],['shed']),
   w('estoy mojado','I\'m wet',['estoy mojada'],['i am wet']),w('rápido','quickly',['rapido','deprisa'],['fast','quick']),w('el campo','the field',['campo'],['field','the open field'])],
 scene:{w:1050,sky:'rain',ground:'meadow',back:'hills',start:[-40,278],
  items:[['path','M-30 282C200 282 400 282 600 280S800 274 1080 274',22],
   ['tree',330,240,1.1,'bigtree'],['molehill',220,262],
   ['g','field',[['raw','<path d="M440 240H520" stroke="transparent" stroke-width="30"/>'],['flowerbed',480,250,80,'#B6A06E']]],
   ['pile',600,236,'pile'],['shed',612,240,'#3F7FBF',T('COBERTIZO','SHED'),'shed'],['scarecrow',790,244],
   ['scatter',71,0,150,200,298,10],['scatter',72,940,1050,262,298,6]],
  finale:{walk:[[604,288]],src:[636,244]}},
 outro:'Ya hace sol.|Now it\'s sunny. / ¡Adiós,|Goodbye, / amigo!|friend!',
 nodes:[
  {t:'say',b:[120,282],n:[220,262],line:'¡Hola otra vez,|Hello again, / Conejo!|Conejo! / ¿Qué tiempo hace?|What\'s the weather like?',opts:[
    o('Llueve mucho.','It\'s raining a lot.',1),
    o('Hace sol.','It\'s sunny.',0,'Look up! Those are rain clouds. "Hace sol" means it\'s sunny.','¡Mira arriba! Son nubes de lluvia. "It\'s sunny" es hace sol.'),
    o('Soy mojado.','I am wet.',0,'Being wet is a state, so it takes "estoy": estoy mojado. And he asked about the weather.','Estar mojado es un estado: "estoy mojado". Y te preguntó por el tiempo.')]},
  {t:'type',b:[120,282],n:[220,262],line:'¡Uf!|Phew! / ¿Y cómo estás tú?|And how are you?',
    prompt:{en:'Tell him you are wet and cold.',es:'Dile que estás mojado y que tienes frío.'},
    say:{es:'Estoy mojado y tengo frío.',en:'I\'m wet and cold.'},
    ans:{es:['estoy mojada y tengo frio','estoy mojado y hace frio','tengo frio y estoy mojado','estoy mojado y con frio'],en:['i am wet and cold',"i'm wet and i'm cold",'i am wet and i am cold',"i'm cold and wet"]}},
  {t:'act',b:[400,286],n:[220,262],line:'¡Rápido!|Quick! / Ve al cobertizo.|Go to the shed. / No te quedes|Don\'t stay / en el campo.|in the field.',opts:[
    a('Under the tree','Debajo del árbol',{hot:'bigtree',at:[330,298],walk:[[350,284]],fx:'splash',fb:{en:'The tree drips everywhere. He said "al cobertizo", to the shed.',es:'El árbol gotea por todos lados. Dijo "to the shed", al cobertizo.'}}),
    a('Into the field','Al campo',{hot:'field',at:[480,298],walk:[[480,272]],fx:'splash',fb:{en:'"No te quedes en el campo": don\'t stay in the field!',es:'"Don\'t stay in the field": ¡no te quedes en el campo!'}}),
    a('To the shed','Al cobertizo',{ok:1,hot:'shed',at:[612,298],walk:[[540,286],[596,284]],reveal:'pile'})]},
  {t:'listen',b:[596,284],n:[500,288],line:'Ya no llueve.|It\'s not raining anymore. / Mira,|Look, / hay zanahorias|there are carrots / en el cobertizo.|in the shed.',opts:[
    m('It\'s not raining anymore. Look, there are carrots in the shed.','Ya no llueve. Mira, hay zanahorias en el cobertizo.',1),
    m('It\'s still raining. Stay in the shed.','Todavía llueve. Quédate en el cobertizo.',0,'"Ya no llueve": it has stopped raining.','"It\'s not raining anymore": ya no llueve.'),
    m('Look, there are carrots in the field.','Mira, hay zanahorias en el campo.',0,'He said "en el cobertizo", in the shed.','Dijo "in the shed", en el cobertizo.')]}
 ]},

/* 1-8 BOSS: the big gate */
{id:'w1l8',diff:'hard',npc:'turtle',
 title:T('La gran puerta','The Big Gate'),theme:{en:'Everything from the garden',es:'Todo lo del jardín'},
 can:{en:'hold a whole conversation: greet, give details, follow directions and say goodbye.',es:'mantener una conversación entera: saludar, dar datos, seguir indicaciones y despedirte.'},
 note:{en:'You mixed <b>ser</b> (who you are), <b>estar</b> (where things are), <b>hace</b> (weather), colors after nouns and numbers. That is the backbone of everyday Spanish.',
       es:'Usaste <b>I am</b> para quién eres y dónde estás, <b>it\'s</b> para el tiempo, colores antes del sustantivo y números. Esa es la base del inglés de todos los días.'},
 lesson:[w('buenas tardes','good afternoon',[],['afternoon']),w('la llave','the key',['llave'],['key']),w('abrir','to open',[],['open']),w('el pueblo','the town',['pueblo'],['town','the village']),
   w('la fiesta','the party',['fiesta'],['party','the festival']),w('buen viaje','have a good trip',['feliz viaje'],['good trip','safe travels'])],
 scene:{w:1150,sky:'evening',ground:'grass',back:'hills',sun:980,start:[-40,278],
  items:[['path','M-30 282C200 282 400 282 560 280S760 270 900 252S1000 240 1180 240',22],
   ['flowerbed',120,246,120,'#E2504A'],['tree',40,240,.9],
   ['g','potR',[['flowerpot',470,246,'#E2504A']]],['g','potB',[['flowerpot',540,246,'#3F7FBF']]],['g','potY',[['flowerpot',610,246,'#F2C230']]],
   ['stoneWall',760,880,232],['stoneWall',1010,1150,232],['gate',944,236,T('PUEBLO','TOWN'),'biggate'],
   ['g','crops',[['bedRow',1020,1140,268,[1036,1068,1100,1132],{1068:'c8'}]],'crops'],['bed',1018,256,1142,282],
   ['scatter',81,0,100,200,298,8],['scatter',82,640,760,262,298,6]],
  finale:{walk:[[944,244],[998,250]],crops:'crops',pull:'c8',src:[1068,240]}},
 outro:'¡Adiós, Conejo!|Goodbye, Conejo! / ¡Buen viaje!|Have a good trip!',
 nodes:[
  {t:'say',b:[220,280],n:[360,264],line:'Buenas tardes,|Good afternoon, / Conejo.|Conejo.',opts:[
    o('Buenas tardes, Tortuga.','Good afternoon, Turtle.',1),
    o('Buenos días, Tortuga.','Good morning, Turtle.',0,'The sun is going down. After lunch it\'s "buenas tardes".','El sol se está poniendo. Después del almuerzo es "good afternoon".'),
    o('Buenas noches, Tortuga.','Good night, Turtle.',0,'It isn\'t night yet, and she is saying hello.','Todavía no es de noche, y ella te está saludando.')]},
  {t:'type',b:[220,280],n:[360,264],line:'¿Qué tiempo hace hoy?|What\'s the weather like today?',
    prompt:{en:'Say that it\'s sunny.',es:'Di que hace sol.'},
    say:{es:'Hace sol.',en:'It\'s sunny.'},
    ans:{es:['hoy hace sol','hace mucho sol','hace sol hoy'],en:['it is sunny','it is sunny today',"it's sunny today",'the sun is out']}},
  {t:'listen',b:[220,280],n:[360,264],line:'Para abrir la puerta|To open the gate / necesito la llave.|I need the key.',opts:[
    m('To open the gate I need the key.','Para abrir la puerta necesito la llave.',1),
    m('The gate is open. I have the key.','La puerta está abierta. Tengo la llave.',0,'"Para abrir" means to open: it\'s still closed.','"To open" es para abrir: todavía está cerrada.'),
    m('To close the gate I need a rock.','Para cerrar la puerta necesito una piedra.',0,'"Abrir" is open, and "la llave" is the key.','"Open" es abrir, y "the key" es la llave.')]},
  {t:'act',b:[400,280],n:[340,264],line:'La llave está|The key is / debajo de la maceta azul.|under the blue flowerpot.',opts:[
    a('Red pot','Maceta roja',{hot:'potR',at:[470,298],walk:[[466,268]],fx:'look',fb:{en:'That pot is "roja", red. She said "azul", blue.',es:'Esa maceta es "red", roja. Dijo "blue", azul.'}}),
    a('Blue pot','Maceta azul',{ok:1,hot:'potB',at:[540,298],walk:[[536,268]],fx:null}),
    a('Yellow pot','Maceta amarilla',{hot:'potY',at:[610,298],walk:[[606,268]],fx:'look',fb:{en:'That pot is "amarilla", yellow. She said "azul", blue.',es:'Esa maceta es "yellow", amarilla. Dijo "blue", azul.'}})]},
  {t:'type',b:[540,270],n:[440,276],line:'¡Muy bien!|Very good! / ¿Cuántas macetas hay?|How many flowerpots are there?',
    prompt:{en:'Say there are three.',es:'Di que hay tres.'},
    say:{es:'Hay tres.',en:'There are three.'},
    ans:{es:['hay tres macetas','tres','3','hay 3'],en:['there are three flowerpots','three','3','there are 3','three flowerpots']}},
  {t:'say',b:[860,262],n:[760,272],line:'La Fiesta|The Festival / es en la ciudad.|is in the city. / ¿Adónde vas ahora?|Where are you going now?',opts:{
    es:[{t:'Voy al pueblo.',ok:1},{t:'Soy el pueblo.',fb:'"Soy" means I am. Going somewhere is "voy a": voy al pueblo.'},{t:'Estoy la puerta.',fb:'That says "I am the gate". You are going TO the town: voy al pueblo.'}],
    en:[{t:'I\'m going to the town.',ok:1},{t:'I\'m the town.',fb:'"I\'m" es soy o estoy. Para ir a un lugar: "I\'m going to the town".'},{t:'I go the town.',fb:'Falta "to": "I\'m going to the town".'}]}},
  {t:'say',b:[860,262],n:[760,272],line:'¡Adiós, Conejo!|Goodbye, Conejo! / ¡Buen viaje!|Have a good trip!',opts:[
    o('¡Gracias, Tortuga! ¡Adiós!','Thank you, Turtle! Goodbye!',1),
    o('¡Mucho gusto, Tortuga!','Nice to meet you, Turtle!',0,'You met her long ago! "Mucho gusto" is for first meetings.','¡La conociste hace mucho! "Nice to meet you" es para la primera vez.'),
    o('¿Cómo te llamas?','What\'s your name?',0,'You already know her name: Tortuga!','¡Ya sabes su nombre: Tortuga!')]}
 ]}
]};
