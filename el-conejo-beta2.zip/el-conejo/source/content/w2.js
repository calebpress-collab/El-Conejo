const {w,o,a,m,T}=require('./lib.js');
const town={sky:'warm',ground:'town',back:'town'};
const road=(w)=>['path',`M-30 284H${w+30}`,30,'#E3D2A8'];
module.exports={
id:2,key:'town',color:'#D8813A',
name:T('El Pueblo','The Market Town'),
cast:['cat','mouse','hedgehog','squirrel','fox'],
intro:{en:'The road ends in a busy market town. Shopkeepers here are polite and a little formal, so you will learn to say "usted". Buy what Abuela needs, and keep your coins straight.',
       es:'El camino llega a un pueblo con mucho mercado. Aquí los tenderos hablan con cortesía, así que aprenderás frases amables para comprar en inglés. Compra lo que necesita la Abuela y cuenta bien tus monedas.'},
outro:{en:'You won the market contest! With a basket of carrots on your back, you head for the forest and the hills.',
       es:'¡Ganaste el concurso del mercado! Con una cesta de zanahorias a la espalda, sales hacia el bosque y las colinas.'},
levels:[

/* 2-1 formal greetings */
{id:'w2l1',diff:'easy',npc:'cat',
 title:T('La entrada del pueblo','The Town Entrance'),theme:{en:'Polite greetings with usted',es:'Saludos formales'},
 can:{en:'greet adults politely with usted and ask where a place is.',es:'saludar con cortesía a adultos y preguntar dónde está un lugar.'},
 note:{en:'Spanish has two words for "you". <b>Tú</b> is for friends and kids; <b>usted</b> is for strangers, shopkeepers and older people. With usted the verb looks like "he/she": <b>¿Cómo está usted?</b> not <b>¿Cómo estás?</b>',
       es:'En inglés solo hay un <b>you</b> para todos. La cortesía se nota en otras palabras: <b>please</b>, <b>sir</b>, <b>ma\'am</b>, o preguntas como <b>Could you…?</b>'},
 lesson:[w('¿cómo está usted?','how are you?',['como esta usted','como esta'],['how are you doing']),w('muy bien','very well',[],['very good','fine']),w('¿y usted?','and you?',['y usted'],['and yourself','what about you']),
   w('bienvenido','welcome',['bienvenida'],[]),w('el pueblo','the town',['pueblo'],['town','the village']),w('la plaza','the square',['plaza'],['square','the plaza']),
   w('la fuente','the fountain',['fuente'],['fountain']),w('el pozo','the well',['pozo'],['well']),w('la torre','the tower',['torre'],['tower']),w('pase','come in',['adelante','pasa'],['go ahead','come on in'])],
 scene:{w:1000,...town,start:[-40,280],
  items:[road(1000),['archBanner',130,282,120,T('PUEBLO','TOWN'),'#E2681C'],
   ['house',330,236,110,74,'#F3E3C3','#B0402E','#6E4630'],['lamp',420,252],
   ['fountain',530,250,'fountain'],['well',620,250,'well'],['clocktower',710,240,'3:00','tower'],
   ['house',880,236,120,80,'#E8D2B0','#3F7FBF','#6E4630'],['bench',960,256]],
  finale:{walk:[[570,284]],src:[530,236]}},
 outro:'¡Bienvenido|Welcome / al pueblo!|to town!',
 nodes:[
  {t:'say',b:[236,280],n:[330,266],line:'Buenas tardes.|Good afternoon. / Bienvenido|Welcome / al pueblo.|to town.',opts:[
    o('Buenas tardes. Gracias.','Good afternoon. Thank you.',1),
    o('Buenas noches.','Good night.',0,'It\'s the afternoon, and he is welcoming you. Answer "buenas tardes".','Es de tarde y te da la bienvenida. Contesta "good afternoon".'),
    o('Adiós.','Goodbye.',0,'You just arrived in town! "Adiós" is for leaving.','¡Acabas de llegar al pueblo! "Goodbye" es para irse.')]},
  {t:'say',b:[236,280],n:[330,266],line:'¿Cómo está usted?|How are you?',opts:{
    es:[{t:'Muy bien, gracias. ¿Y usted?',ok:1},{t:'Muy bien. ¿Y tú?',fb:'He used "usted" with you, so answer the same polite way: ¿y usted?'},{t:'Soy bien, gracias.',fb:'How you are uses "estar": estoy bien. Or just "muy bien".'}],
    en:[{t:'Very well, thank you. And you?',ok:1},{t:'I\'m very good, sir, how are you doing it?',fb:'"How are you doing it?" no se dice. Basta con "And you?".'},{t:'I have fine, thanks.',fb:'Para cómo estás se usa "I am": "I\'m fine" o "Very well".'}]}},
  {t:'type',b:[236,280],n:[330,266],line:'Muy bien también.|Very well too. / ¿Qué busca?|What are you looking for?',
    prompt:{en:'Ask where the market is.',es:'Pregunta dónde está el mercado.'},
    say:{es:'¿Dónde está el mercado?',en:'Where is the market?'},
    ans:{es:['donde esta el mercado por favor','busco el mercado','donde queda el mercado'],en:["where's the market",'where is the market please','i am looking for the market','where can i find the market']}},
  {t:'act',b:[430,282],n:[340,268],line:'El mercado|The market / está en la plaza,|is in the square, / al lado de la fuente.|next to the fountain.',opts:[
    a('The fountain','La fuente',{ok:1,hot:'fountain',at:[530,298],walk:[[510,284]]}),
    a('The well','El pozo',{hot:'well',at:[620,298],walk:[[616,284]],fx:'look',fb:{en:'"El pozo" is the well. He said "la fuente", the fountain.',es:'"Well" es el pozo. Dijo "fountain", la fuente.'}}),
    a('The tower','La torre',{hot:'tower',at:[710,298],walk:[[704,284]],fx:'look',fb:{en:'That is the clock tower: "la torre". He said "la fuente", the fountain.',es:'Esa es la torre del reloj: "tower". Dijo "fountain", la fuente.'}})]},
  {t:'listen',b:[510,284],n:[420,270],line:'¡Exacto!|Exactly! / Pase, por favor.|Go ahead, please.',opts:[
    m('Exactly! Go ahead, please.','¡Exacto! Pase, por favor.',1),
    m('No! Wait here, please.','¡No! Espere aquí, por favor.',0,'"Exacto" means you got it right, and "pase" means go ahead.','"Exactly" significa que acertaste, y "go ahead" es "pase".'),
    m('Exactly! It costs five coins.','¡Exacto! Cuesta cinco monedas.',0,'Nothing about coins. "Pase" means go ahead.','Nada de monedas. "Go ahead" significa pase.')]}
 ]},

/* 2-2 bakery */
{id:'w2l2',diff:'easy',npc:'mouse',
 title:T('La panadería','The Bakery'),theme:{en:'Ordering politely: quisiera',es:'Pedir con cortesía: I would like'},
 can:{en:'order food politely and finish an order.',es:'pedir comida con cortesía y terminar un pedido.'},
 note:{en:'<b>Quisiera</b> means "I would like" and is the polite way to order. <b>Quiero</b> (I want) is fine with friends but blunt with a shopkeeper. When paying, <b>aquí tiene</b> means "here you are" (formal).',
       es:'En inglés, <b>I would like</b> (o <b>I\'d like</b>) es la forma amable de pedir. <b>I want</b> suena brusco en una tienda. Al pagar se dice <b>here you are</b> o <b>here you go</b>.'},
 lesson:[w('quisiera','I would like',['me gustaria'],["i'd like"]),w('el pan','the bread',['pan'],['bread']),w('el pastel','the cake',['pastel','la torta'],['cake','a cake']),
   w('las galletas','the cookies',['galletas'],['cookies','the biscuits']),w('la ventana','the window',['ventana'],['window']),w('la mesa','the table',['mesa'],['table']),
   w('la caja','the box',['caja'],['box']),w('¿algo más?','anything else?',['algo mas'],['something else','anything more']),w('eso es todo','that\'s all',['nada mas','es todo'],['that is all','nothing else']),
   w('aquí tiene','here you are',['aqui tiene','tome'],['here you go'])],
 scene:{w:900,...town,start:[-40,282],
  items:[road(900),['house',150,236,120,78,'#E8D2B0','#7A4E33','#6E4630'],
   ['crate',340,266,'#C9A06A',1,'box'],['shop',500,240,170,T('PANADERÍA','BAKERY'),'#D84A3A','bread','bakery'],
   ['cafeTable',630,256,'#3F7FBF','table'],['lamp',770,254],['house',860,236,100,74,'#F3E3C3','#B0402E','#6E4630']],
  finale:{walk:[[500,282]],src:[500,214]}},
 outro:'¡Gracias|Thank you / por su compra!|for your purchase!',
 nodes:[
  {t:'say',b:[380,282],n:[520,262],line:'¡Hola!|Hi! / Bienvenido|Welcome / a la panadería.|to the bakery. / ¿Qué desea?|What would you like?',opts:[
    o('Quisiera pan, por favor.','I would like bread, please.',1),
    o('Quisiera un ratón.','I would like a mouse.',0,'"Ratón" means mouse. That\'s the baker!','"Mouse" significa ratón. ¡Ese es el panadero!'),
    o('Aquí tiene.','Here you are.',0,'"Aquí tiene" is for handing something over. First, order.','"Here you are" es para dar algo. Primero pide.')]},
  {t:'listen',b:[380,282],n:[520,262],line:'Tenemos pan,|We have bread, / pastel|cake / y galletas de zanahoria.|and carrot cookies.',opts:[
    m('We have bread, cake and carrot cookies.','Tenemos pan, pastel y galletas de zanahoria.',1),
    m('We have bread, cake and carrot soup.','Tenemos pan, pastel y sopa de zanahoria.',0,'"Galletas" are cookies.','"Cookies" son galletas.'),
    m('We don\'t have bread today.','Hoy no tenemos pan.',0,'He said "tenemos pan": we have bread.','Dijo "we have bread": tenemos pan.')]},
  {t:'act',b:[400,282],n:[520,262],line:'Las galletas|The cookies / están en la ventana.|are in the window.',opts:[
    a('In the window','En la ventana',{ok:1,hot:'bakery',at:[490,298],walk:[[476,280]]}),
    a('On the table','En la mesa',{hot:'table',at:[630,298],walk:[[600,286]],fx:'look',fb:{en:'"La mesa" is the table. He said "la ventana", the window.',es:'"Table" es la mesa. Dijo "window", la ventana.'}}),
    a('In the box','En la caja',{hot:'box',at:[340,298],walk:[[366,288]],fx:'look',fb:{en:'"La caja" is the box. Look in "la ventana", the window.',es:'"Box" es la caja. Busca en "window", la ventana.'}})]},
  {t:'type',b:[476,282],n:[580,264],line:'¡Esas!|Those ones! / ¿Algo más?|Anything else?',
    prompt:{en:'Say no, that\'s all, thank you.',es:'Di que no, que eso es todo, gracias.'},
    say:{es:'No, eso es todo, gracias.',en:'No, that\'s all, thank you.'},
    ans:{es:['no gracias eso es todo','eso es todo gracias','nada mas gracias','no nada mas gracias','eso es todo','no gracias'],en:['no thanks that is all','that is all thank you',"that's all thanks",'no that is all thank you','nothing else thanks','no thank you']}},
  {t:'say',b:[476,282],n:[580,264],line:'Son dos monedas.|That\'s two coins.',opts:[
    o('Aquí tiene.','Here you are.',1),
    o('¿Algo más?','Anything else?',0,'That\'s what the baker asks. You are the customer: pay him.','Eso lo pregunta el panadero. Tú eres el cliente: págale.'),
    o('Quisiera pan.','I would like bread.',0,'You already ordered. Now pay: "aquí tiene".','Ya pediste. Ahora paga: "here you are".')]}
 ]},

/* 2-3 market stall */
{id:'w2l3',diff:'medium',npc:'hedgehog',
 title:T('El puesto del mercado','The Market Stall'),theme:{en:'Buying with numbers',es:'Comprar con números'},
 can:{en:'ask prices, pay the right amount and say how many you want.',es:'preguntar precios, pagar lo justo y decir cuántos quieres.'},
 note:{en:'<b>¿Cuánto cuesta?</b> is for one thing; <b>¿Cuánto cuestan?</b> for several. The verb follows the number of things: <b>la manzana cuesta</b>, <b>las zanahorias cuestan</b>.',
       es:'En inglés: <b>How much is it?</b> para una cosa y <b>How much are they?</b> para varias. También sirve <b>How much does it cost?</b>'},
 lesson:[w('¿qué desea?','what would you like?',['que quiere'],['what do you want','can i help you']),w('quiero comprar','I want to buy',['quisiera comprar'],['i would like to buy']),
   w('¿cuánto cuestan?','how much do they cost?',['cuanto cuesta','cuanto son'],['how much are they','how much is it','how much']),w('la moneda','the coin',['moneda'],['coin']),
   w('cinco','five',['5'],['5']),w('diez','ten',['10'],['10']),w('la manzana','the apple',['manzana'],['apple']),w('solo','only',['solamente','nada mas'],['just'])],
 scene:{w:900,sky:'warm',ground:'town',back:'town',start:[-40,282],fixedDepth:true,
  items:[road(900),['archBanner',250,282,128,T('MERCADO','MARKET'),'#E2681C'],['crate',430,268,'#F2A81D',1],
   ['stallBack',655],['npc'],['stallFront',655],['coinShelf',655],['crate',820,270,'#D84A3A',0]],
  finale:{walk:[[540,282]],src:[700,186]}},
 outro:'¡Gracias|Thank you / por su compra!|for your purchase!',
 nodes:[
  {t:'say',b:[516,282],n:[652,214],line:'¡Bienvenido|Welcome / al mercado!|to the market! / ¿Qué desea?|What would you like?',opts:[
    o('Quiero comprar zanahorias.','I want to buy carrots.',1),
    o('Quiero vender zanahorias.','I want to sell carrots.',0,'"Vender" means to sell. You want to buy: "comprar".','"Sell" significa vender. Tú quieres comprar: "buy".'),
    o('¿Dónde está el mercado?','Where is the market?',0,'You\'re already at the market.','Ya estás en el mercado.')]},
  {t:'type',b:[516,282],n:[652,214],show:'bunch',line:'Tengo|I have / muchas zanahorias.|lots of carrots.',
    prompt:{en:'Ask how much they cost.',es:'Pregunta cuánto cuestan.'},
    say:{es:'¿Cuánto cuestan?',en:'How much do they cost?'},
    ans:{es:['cuanto cuesta','cuanto es','cuanto cuestan las zanahorias','cuanto valen','cuanto vale','cuanto son'],en:['how much does it cost','how much is it','how much are they','how much','how much are the carrots','what do they cost']}},
  {t:'act',b:[516,282],n:[652,214],show:'coins bunch',line:'Cuestan|They cost / cinco monedas.|five coins.',opts:[
    a('3 coins','3 monedas',{hot:'k3',tag:1,at:[598,252],walk:[[570,282]],fx:'look',fb:{en:'"Cinco" is five. "Tres" is three.',es:'"Five" es cinco. "Three" es tres.'}}),
    a('5 coins','5 monedas',{ok:1,hot:'k5',tag:1,at:[652,252],walk:[[624,282]],pay:'k5'}),
    a('10 coins','10 monedas',{hot:'k10',tag:1,at:[708,252],walk:[[680,282]],fx:'look',fb:{en:'"Diez" is ten. He said "cinco", five.',es:'"Ten" es diez. Dijo "five", cinco.'}})]},
  {t:'say',b:[516,282],n:[652,214],show:'bunch',line:'¡Gracias!|Thanks! / ¿Quiere|Would you like / una manzana|an apple / también?|too?',opts:[
    o('No, gracias, solo zanahorias.','No, thanks, only carrots.',1),
    o('Sí, una zanahoria.','Yes, one carrot.',0,'He asked about an apple ("manzana"), not a carrot.','Preguntó por una manzana ("apple"), no una zanahoria.'),
    o('Cuestan cinco.','They cost five.',0,'He\'s the seller. You don\'t set the price!','Él es el vendedor. ¡Tú no pones el precio!')]},
  {t:'type',b:[516,282],n:[652,214],show:'bunch',line:'Muy bien.|Very well. / ¿Cuántas|How many / zanahorias|carrots / quiere?|would you like?',
    prompt:{en:'Ask for ten carrots.',es:'Pide diez zanahorias.'},
    say:{es:'Diez, por favor.',en:'Ten, please.'},
    ans:{es:['diez','diez zanahorias','quiero diez','quiero diez zanahorias','quisiera diez','10','10 por favor'],en:['ten','ten carrots','i want ten','i want ten carrots','10','i would like ten','ten carrots please']}}
 ]},

/* 2-4 the time */
{id:'w2l4',diff:'medium',npc:'squirrel',
 title:T('La torre del reloj','The Clock Tower'),theme:{en:'Telling the time',es:'Decir la hora'},
 can:{en:'ask and tell the time and read opening hours.',es:'preguntar y decir la hora y entender horarios.'},
 note:{en:'Time uses <b>ser</b> and the plural: <b>son las tres</b> (it\'s three). Only one o\'clock is singular: <b>es la una</b>. "At" a time is <b>a las</b>: <b>abre a las cuatro</b>.',
       es:'En inglés la hora es <b>it\'s three o\'clock</b> o <b>it\'s three</b>. Para "a las" se usa <b>at</b>: <b>it opens at four</b>.'},
 lesson:[w('¿qué hora es?','what time is it?',['que hora es','que horas son'],['what is the time',"what's the time"]),w('son las tres','it\'s three o\'clock',['son las 3','las tres'],["it's three",'it is three']),
   w('a las cuatro','at four',['a las 4'],['at 4',"at four o'clock"]),w('abre','it opens',['se abre'],['opens']),w('cierra','it closes',['se cierra'],['closes']),
   w('cerrado','closed',['cerrada'],[]),w('abierto','open',['abierta'],[]),w('esperar','to wait',['espera'],['wait']),w('el banco','the bench',['banco'],['bench']),w('las semillas','the seeds',['semillas'],['seeds'])],
 scene:{w:1000,...town,start:[-40,282],
  items:[road(1000),['house',140,236,120,80,'#F3E3C3','#3F7FBF','#6E4630'],['g','bench',[['bench',380,256]]],['lamp',300,254],
   ['clocktower',520,238,'3:00','tower'],['shop',690,240,150,T('SEMILLAS','SEEDS'),'#3D7A33','flowers','seedshop'],
   ['g','closedsign',[['aboard',600,272,T('CERRADO','CLOSED'),T('ABRE 4:00','OPENS 4:00')]]],
   ['g','opensign',[['aboard',600,272,T('ABIERTO','OPEN'),'']],'hideuntil'],
   ['house',920,236,110,76,'#E8D2B0','#B0402E','#6E4630']],
  finale:{walk:[[672,284]],src:[690,214]}},
 outro:'¡Que tengas|Have / un buen día!|a nice day!',
 nodes:[
  {t:'say',b:[200,282],n:[300,268],line:'¡Conejo!|Conejo! / ¿Qué haces|What are you doing / en el pueblo?|in town?',opts:[
    o('Busco semillas de zanahoria.','I\'m looking for carrot seeds.',1),
    o('Busco el pueblo.','I\'m looking for the town.',0,'You\'re already in the town!','¡Ya estás en el pueblo!'),
    o('Son las semillas.','They are the seeds.',0,'She asked what you are doing. Say what you\'re looking for: "busco…".','Te preguntó qué haces. Di qué buscas: "I\'m looking for…".')]},
  {t:'type',b:[430,282],n:[330,270],line:'La tienda está ahí.|The shop is there. / ¿Qué hora es?|What time is it?',
    prompt:{en:'Look at the clock. Tell her it is three o\'clock.',es:'Mira el reloj. Dile que son las tres.'},
    say:{es:'Son las tres.',en:'It\'s three o\'clock.'},
    ans:{es:['son las tres en punto','las tres','son las 3','ya son las tres'],en:["it's three",'it is three',"it is three o'clock",'three oclock',"it's 3",'it is 3']}},
  {t:'listen',b:[430,282],n:[330,270],line:'La tienda|The shop / abre a las cuatro.|opens at four.',opts:[
    m('The shop opens at four.','La tienda abre a las cuatro.',1),
    m('The shop closes at four.','La tienda cierra a las cuatro.',0,'"Abre" is opens. "Cierra" would be closes.','"Opens" es abre. "Closes" sería cierra.'),
    m('The shop opens at two.','La tienda abre a las dos.',0,'"Cuatro" is four, not two.','"Four" es cuatro, no dos.')]},
  {t:'act',b:[430,282],n:[330,270],line:'Ahora está cerrada.|It\'s closed now. / Espera en el banco.|Wait on the bench.',opts:[
    a('Wait on the bench','Esperar en el banco',{ok:1,hot:'bench',at:[380,298],walk:[[392,272]]}),
    a('Knock on the door','Tocar la puerta',{hot:'seedshop',at:[680,298],walk:[[660,286]],fx:'bonk',fb:{en:'"Está cerrada": it\'s closed. She told you to wait on the bench.',es:'"It\'s closed": está cerrada. Te dijo que esperes en el banco.'}}),
    a('Climb the tower','Subir a la torre',{hot:'tower',at:[520,298],walk:[[506,286]],fx:'bonk',fb:{en:'No climbing! "Espera en el banco": wait on the bench.',es:'¡Nada de trepar! "Wait on the bench": espera en el banco.'}})]},
  {t:'say',b:[560,284],n:[460,272],hide:'closedsign',show:'opensign',line:'¡Ya son las cuatro!|It\'s four now! / La tienda|The shop / está abierta.|is open.',opts:[
    o('¡Qué bien! ¡Gracias!','Great! Thank you!',1),
    o('Está cerrada.','It\'s closed.',0,'Look at the sign: "abierto", open.','Mira el cartel: "open", abierto.'),
    o('Son las tres.','It\'s three o\'clock.',0,'The clock moved on: now it\'s four, "las cuatro".','El reloj avanzó: ahora son las cuatro, "four".')]}
 ]},

/* 2-5 fruit stand */
{id:'w2l5',diff:'medium',npc:'fox',
 title:T('La frutería del zorro','The Fox\'s Fruit Stand'),theme:{en:'Fruit, size and color',es:'Fruta, tamaño y color'},
 can:{en:'describe fruit by color and size and pick the right one.',es:'describir fruta por color y tamaño y elegir la correcta.'},
 note:{en:'Adjectives match the noun: <b>la manzana roja</b>, <b>el plátano amarillo</b>, <b>las uvas verdes</b>. <b>Grande</b> and <b>verde</b> are the same for both genders; only the plural adds -s.',
       es:'En inglés los adjetivos nunca cambian: <b>a red apple</b>, <b>two red apples</b>. Y van antes del sustantivo: <b>a big green apple</b>.'},
 lesson:[w('la manzana','the apple',['manzana'],['apple']),w('la naranja','the orange',['naranja'],['orange']),w('las uvas','the grapes',['uvas'],['grapes']),
   w('grande','big',[],['large']),w('pequeña','small',['pequeño','chica'],['little']),w('maduro','ripe',['madura'],[]),w('vendo','I sell',['yo vendo'],[]),
   w('¿te acuerdas de mí?','do you remember me?',['te acuerdas de mi','me recuerdas'],['remember me']),w('ahora','now',[],['right now'])],
 scene:{w:900,...town,start:[-40,282],
  items:[road(900),['house',140,236,120,80,'#E8D2B0','#3D7A33','#6E4630'],['lamp',250,254],
   ['shop',560,238,250,T('FRUTERÍA','FRUIT SHOP'),'#3D7A33','fruit','fruitshop'],
   ['crate',480,268,'#E8902A',1,'cOrange'],['crate',560,268,'#D84A3A',1,'cRed'],['crate',640,268,'#8DBF4A',1,'cGreen'],
   ['house',820,236,110,74,'#F3E3C3','#B0402E','#6E4630']],
  finale:{walk:[[620,284]],src:[560,252]}},
 outro:'¡Buen provecho,|Enjoy, / conejo!|bunny!',
 nodes:[
  {t:'say',b:[260,284],n:[380,270],line:'¡Conejo!|Conejo! / ¿Te acuerdas de mí?|Do you remember me?',opts:[
    o('¡Sí! Eres Zorro.','Yes! You\'re Fox.',1),
    o('Sí, soy Zorro.','Yes, I\'m Fox.',0,'"Soy" means I am. HE is Fox: "eres Zorro".','"I am" es soy. ÉL es Zorro: "you\'re Fox".'),
    o('No, gracias.','No, thank you.',0,'He asked if you remember him, and you met him at his hedge!','Te preguntó si te acuerdas de él, ¡y lo conociste en su seto!')]},
  {t:'listen',b:[260,284],n:[380,270],line:'Ahora vendo fruta:|Now I sell fruit: / manzanas, naranjas|apples, oranges / y uvas.|and grapes.',opts:[
    m('Now I sell fruit: apples, oranges and grapes.','Ahora vendo fruta: manzanas, naranjas y uvas.',1),
    m('Now I sell carrots and apples.','Ahora vendo zanahorias y manzanas.',0,'No carrots this time: "manzanas, naranjas y uvas".','Esta vez no hay zanahorias: "apples, oranges and grapes".'),
    m('Now I buy fruit: apples and grapes.','Ahora compro fruta: manzanas y uvas.',0,'"Vendo" means I sell, not I buy.','"I sell" es vendo, no compro.')]},
  {t:'type',b:[260,284],n:[380,270],line:'¿Qué quieres?|What do you want?',
    prompt:{en:'Ask for a big apple, please.',es:'Pide una manzana grande, por favor.'},
    say:{es:'Una manzana grande, por favor.',en:'A big apple, please.'},
    ans:{es:['quiero una manzana grande','quiero una manzana grande por favor','quisiera una manzana grande','una manzana grande'],en:['i want a big apple','i would like a big apple','a big apple','one big apple please','a large apple please']}},
  {t:'act',b:[400,284],n:[300,272],line:'Toma una roja.|Take a red one. / Las verdes|The green ones / no están maduras.|aren\'t ripe.',opts:[
    a('Orange crate','Caja naranja',{hot:'cOrange',at:[480,298],walk:[[478,288]],fx:'look',fb:{en:'Those are oranges, "naranjas". He said "una roja", a red one.',es:'Esas son naranjas, "oranges". Dijo "a red one", una roja.'}}),
    a('Red apples','Manzanas rojas',{ok:1,hot:'cRed',at:[560,298],walk:[[548,288]]}),
    a('Green apples','Manzanas verdes',{hot:'cGreen',at:[640,298],walk:[[628,288]],fx:'look',fb:{en:'"Las verdes no están maduras": the green ones aren\'t ripe.',es:'"The green ones aren\'t ripe": las verdes no están maduras.'}})]},
  {t:'say',b:[548,288],n:[410,276],line:'¿Es grande|Is it big / o pequeña?|or small?',opts:[
    o('Es grande.','It\'s big.',1),
    o('Soy grande.','I\'m big.',0,'"Soy" is about you. He asked about the apple: "es grande".','"I\'m" habla de ti. Preguntó por la manzana: "it\'s big".'),
    o('Es pequeño.','It\'s small.',0,'You picked a big one, and "manzana" is feminine: pequeña.','Elegiste una grande, y en español "manzana" es femenina.')]}
 ]},

/* 2-6 cafe */
{id:'w2l6',diff:'medium',npc:'cat',
 title:T('El café de la plaza','The Café on the Square'),theme:{en:'At a café',es:'En un café'},
 can:{en:'get a table, order a drink and ask for the bill.',es:'pedir mesa, pedir una bebida y pedir la cuenta.'},
 note:{en:'Waiters use formal commands: <b>siéntese</b> (sit down), <b>pase</b> (come in). <b>Tomar</b> means "to have" a drink: <b>¿Qué desea tomar?</b> To pay, ask for <b>la cuenta</b>.',
       es:'En un café en inglés: <b>Table for one, please</b>, <b>Can I have…?</b> y para pagar <b>Can I have the check/bill, please?</b>'},
 lesson:[w('¿mesa para uno?','table for one?',['mesa para uno'],['a table for one']),w('siéntese','sit down',['sientese','tome asiento'],['have a seat','please sit']),
   w('la sombrilla','the umbrella',['sombrilla','el parasol'],['umbrella','the parasol']),w('¿qué desea tomar?','what would you like to drink?',['que desea tomar','que quiere tomar'],['what will you have','what would you like']),
   w('el jugo','the juice',['jugo','el zumo'],['juice']),w('la sopa','the soup',['sopa'],['soup']),w('la cuenta','the bill',['cuenta'],['the check','check','bill'])],
 scene:{w:950,...town,start:[-40,284],
  items:[road(950),['shop',250,238,170,T('CAFÉ','CAFÉ'),'#8A5A3B','cups','cafe'],
   ['cafeTable',460,256,'#D84A3A','tRed'],['cafeTable',560,256,'#3D7A33','tGreen'],['cafeTable',660,256,'#3F7FBF','tBlue'],
   ['fountain',860,250],['lamp',390,254]],
  finale:{walk:[[540,288]],src:[560,236]}},
 outro:'¡Vuelva pronto!|Come back soon!',
 nodes:[
  {t:'say',b:[180,284],n:[330,270],line:'Buenas tardes.|Good afternoon. / ¿Mesa para uno?|Table for one?',opts:[
    o('Sí, para uno, por favor.','Yes, for one, please.',1),
    o('Sí, para tres.','Yes, for three.',0,'You\'re by yourself, so "para uno".','Estás solo, así que "for one".'),
    o('No, tengo una mesa.','No, I have a table.',0,'You don\'t have a table yet. Say yes: "sí, para uno".','Todavía no tienes mesa. Di que sí: "yes, for one".')]},
  {t:'act',b:[380,284],n:[300,270],line:'Siéntese|Sit down / en la mesa|at the table / de la sombrilla verde.|with the green umbrella.',opts:[
    a('Red umbrella','Sombrilla roja',{hot:'tRed',at:[460,298],walk:[[432,286]],fx:'look',fb:{en:'That umbrella is red, "roja". He said "verde", green.',es:'Esa sombrilla es roja, "red". Dijo "green", verde.'}}),
    a('Green umbrella','Sombrilla verde',{ok:1,hot:'tGreen',at:[560,298],walk:[[532,286]]}),
    a('Blue umbrella','Sombrilla azul',{hot:'tBlue',at:[660,298],walk:[[632,286]],fx:'look',fb:{en:'That umbrella is blue, "azul". He said "verde", green.',es:'Esa sombrilla es azul, "blue". Dijo "green", verde.'}})]},
  {t:'listen',b:[532,286],n:[610,272],line:'Hoy tenemos|Today we have / jugo de zanahoria|carrot juice / y sopa de verduras.|and vegetable soup.',opts:[
    m('Today we have carrot juice and vegetable soup.','Hoy tenemos jugo de zanahoria y sopa de verduras.',1),
    m('Today we have carrot cake and apple juice.','Hoy tenemos pastel de zanahoria y jugo de manzana.',0,'He said "jugo de zanahoria", carrot juice, and "sopa", soup.','Dijo "carrot juice", jugo de zanahoria, y "soup", sopa.'),
    m('Tomorrow we have soup.','Mañana tenemos sopa.',0,'"Hoy" is today.','"Today" es hoy.')]},
  {t:'type',b:[532,286],n:[610,272],line:'¿Qué desea tomar?|What would you like to drink?',
    prompt:{en:'Order a carrot juice, please.',es:'Pide un jugo de zanahoria, por favor.'},
    say:{es:'Un jugo de zanahoria, por favor.',en:'A carrot juice, please.'},
    ans:{es:['quisiera un jugo de zanahoria','quisiera un jugo de zanahoria por favor','un jugo de zanahoria','quiero un jugo de zanahoria por favor','jugo de zanahoria por favor'],en:["i'd like a carrot juice please",'i would like a carrot juice','a carrot juice','carrot juice please','can i have a carrot juice please','one carrot juice please']}},
  {t:'say',b:[532,286],n:[610,272],line:'Aquí tiene.|Here you are. / ¿Algo más?|Anything else?',opts:[
    o('La cuenta, por favor.','The bill, please.',1),
    o('¿Mesa para uno?','Table for one?',0,'That\'s the waiter\'s question, and you already have a table.','Esa es la pregunta del camarero, y ya tienes mesa.'),
    o('Siéntese, por favor.','Sit down, please.',0,'"Siéntese" is what the waiter says to you!','¡"Sit down" te lo dice el camarero a ti!')]}
 ]},

/* 2-7 clothes */
{id:'w2l7',diff:'medium',npc:'mouse',
 title:T('La tienda de ropa','The Clothes Shop'),theme:{en:'Cheap or expensive',es:'Barato o caro'},
 can:{en:'compare prices and buy something you can afford.',es:'comparar precios y comprar algo que puedes pagar.'},
 note:{en:'To avoid repeating the noun, Spanish drops it and keeps the article: <b>la roja</b> (the red one), <b>la azul</b> (the blue one). <b>Me la llevo</b> means "I\'ll take it" (la = the scarf).',
       es:'En inglés, para no repetir el sustantivo se usa <b>one</b>: <b>the red one</b>, <b>the blue one</b>. Para comprar: <b>I\'ll take it</b>.'},
 lesson:[w('la bufanda','the scarf',['bufanda'],['scarf']),w('la ropa','the clothes',['ropa'],['clothes','clothing']),w('busco','I\'m looking for',['estoy buscando'],['i am looking for']),
   w('caro','expensive',['cara'],['pricey']),w('barato','cheap',['barata'],['inexpensive']),w('la roja','the red one',[],['red one']),w('la azul','the blue one',[],['blue one']),
   w('me la llevo','I\'ll take it',['la compro'],['i will take it',"i'll buy it"]),w('necesita','you need',['necesitas'],['you need it'])],
 scene:{w:900,...town,start:[-40,284],
  items:[road(900),['house',130,236,110,76,'#F3E3C3','#7A5AA8','#6E4630'],
   ['shop',600,238,170,T('ROPA','CLOTHES'),'#3F7FBF','clothes','clothesshop'],
   ['g','rRed',[['rack',350,266,[{id:'sRed',col:'#D84A3A'}]]]],['g','rYellow',[['rack',430,266,[{id:'sYellow',col:'#F2C230'}]]]],['g','rBlue',[['rack',510,266,[{id:'sBlue',col:'#3F7FBF'}]]]],
   ['lamp',690,254],['house',820,236,120,80,'#E8D2B0','#B0402E','#6E4630']],
  finale:{walk:[[560,290]],src:[600,214]}},
 outro:'¡Le queda muy bien!|It looks great on you!',
 nodes:[
  {t:'say',b:[260,288],n:[170,272],line:'Bienvenido|Welcome / a mi tienda.|to my shop. / ¿Busca algo?|Are you looking for something?',opts:[
    o('Busco una bufanda.','I\'m looking for a scarf.',1),
    o('Busco pan.','I\'m looking for bread.',0,'This is a clothes shop. Bread is at the bakery!','Esta es una tienda de ropa. ¡El pan está en la panadería!'),
    o('Es muy caro.','It\'s very expensive.',0,'You haven\'t seen any prices yet.','Todavía no has visto ningún precio.')]},
  {t:'listen',b:[260,288],n:[170,272],line:'Hace frío|It\'s cold / en el bosque.|in the forest. / Necesita una bufanda.|You need a scarf.',opts:[
    m('It\'s cold in the forest. You need a scarf.','Hace frío en el bosque. Necesita una bufanda.',1),
    m('It\'s hot in the forest. You need a hat.','Hace calor en el bosque. Necesita un sombrero.',0,'"Hace frío" is it\'s cold.','"It\'s cold" es hace frío.'),
    m('It\'s cold in the town. Buy bread.','Hace frío en el pueblo. Compre pan.',0,'He said "el bosque", the forest, and "una bufanda", a scarf.','Dijo "the forest", el bosque, y "a scarf", una bufanda.')]},
  {t:'type',b:[270,288],n:[200,272],line:'Tengo tres.|I have three.',
    prompt:{en:'Ask how much the red one costs.',es:'Pregunta cuánto cuesta la roja.'},
    say:{es:'¿Cuánto cuesta la roja?',en:'How much is the red one?'},
    ans:{es:['cuanto cuesta la bufanda roja','cuanto vale la roja','cuanto es la roja','cuanto cuesta la roja por favor'],en:['how much does the red one cost','how much is the red scarf','how much does the red scarf cost','how much is the red one please']}},
  {t:'act',b:[270,288],n:[200,272],line:'La roja cuesta diez,|The red one costs ten, / la amarilla, ocho,|the yellow one, eight, / y la azul, tres.|and the blue one, three. / Usted tiene cinco.|You have five.',opts:[
    a('Red scarf','Bufanda roja',{hot:'rRed',at:[350,300],walk:[[330,288]],fx:'look',fb:{en:'The red one costs "diez", ten. You only have five.',es:'La roja cuesta "ten", diez. Solo tienes cinco.'}}),
    a('Yellow scarf','Bufanda amarilla',{hot:'rYellow',at:[430,300],walk:[[410,288]],fx:'look',fb:{en:'The yellow one costs "ocho", eight. Too expensive.',es:'La amarilla cuesta "eight", ocho. Es muy cara.'}}),
    a('Blue scarf','Bufanda azul',{ok:1,hot:'rBlue',at:[510,300],walk:[[490,288]]})]},
  {t:'say',b:[490,288],n:[580,272],line:'Es barata|It\'s cheap / y bonita.|and pretty. / ¿La quiere?|Do you want it?',opts:[
    o('Sí, me la llevo.','Yes, I\'ll take it.',1),
    o('No, es muy cara.','No, it\'s very expensive.',0,'Three coins is "barata", cheap!','¡Tres monedas es "cheap", barata!'),
    o('Busco una bufanda.','I\'m looking for a scarf.',0,'You found it! Now say you\'ll take it.','¡Ya la encontraste! Ahora di que te la llevas.')]}
 ]},

/* 2-8 BOSS: market contest */
{id:'w2l8',diff:'hard',npc:'hedgehog',
 title:T('El concurso del mercado','The Market Contest'),theme:{en:'Everything from town',es:'Todo lo del pueblo'},
 can:{en:'shop, pay, tell the time and stay polite in a full conversation.',es:'comprar, pagar, decir la hora y ser cortés en una conversación completa.'},
 note:{en:'Shopping Spanish in one breath: <b>usted</b> with sellers, <b>quisiera</b> to order, <b>¿cuánto cuesta?</b> to ask, <b>son las…</b> for time and <b>aquí tiene</b> to pay.',
       es:'Inglés para comprar: <b>I\'d like…</b> para pedir, <b>How much is it?</b> para preguntar, <b>It\'s … o\'clock</b> para la hora y <b>Here you are</b> para pagar.'},
 lesson:[w('el concurso','the contest',['concurso'],['contest','the competition']),w('el premio','the prize',['premio'],['prize']),w('la cesta','the basket',['cesta','la canasta'],['basket']),
   w('la entrada','the entry fee',['entrada'],['entry','the ticket']),w('pague','pay',['pagar'],['please pay']),w('usted gana','you win',['gana usted','ha ganado'],['you won'])],
 scene:{w:950,sky:'warm',ground:'town',back:'town',start:[-40,284],fixedDepth:true,
  items:[road(950),['bunting',0,950,150],['clocktower',150,238,'5:00','tower'],['archBanner',330,282,140,T('CONCURSO','CONTEST'),'#7A5AA8'],
   ['stallBack',655],['npc'],['stallFront',655],['coinShelf',655],['fountain',870,252]],
  finale:{walk:[[560,284]],src:[700,186]}},
 outro:'¡Felicidades!|Congratulations! / ¡Buen viaje!|Have a good trip!',
 nodes:[
  {t:'say',b:[520,284],n:[652,214],line:'Buenas tardes.|Good afternoon. / ¿Cómo está usted?|How are you?',opts:{
    es:[{t:'Muy bien, gracias. ¿Y usted?',ok:1},{t:'Estoy las cinco.',fb:'That mixes in the time. How you are: "muy bien, gracias".'},{t:'Soy muy bien.',fb:'How you are uses "estar", or just "muy bien".'}],
    en:[{t:'Very well, thank you. And you?',ok:1},{t:'I am five o\'clock.',fb:'Eso mezcla la hora. Para cómo estás: "Very well, thank you".'},{t:'I have very well.',fb:'Se dice "I\'m very well" o solo "Very well".'}]}},
  {t:'listen',b:[520,284],n:[652,214],line:'El premio|The prize / es una cesta de zanahorias|is a basket of carrots / para la fiesta.|for the festival.',opts:[
    m('The prize is a basket of carrots for the festival.','El premio es una cesta de zanahorias para la fiesta.',1),
    m('The prize is a carrot cake for the festival.','El premio es un pastel de zanahoria para la fiesta.',0,'"Una cesta" is a basket.','"A basket" es una cesta.'),
    m('The basket costs five coins.','La cesta cuesta cinco monedas.',0,'No price here: "el premio" is the prize.','Aquí no hay precio: "the prize" es el premio.')]},
  {t:'act',b:[520,284],n:[652,214],show:'coins',line:'Primero,|First, / pague la entrada:|pay the entry fee: / tres monedas.|three coins.',opts:[
    a('3 coins','3 monedas',{ok:1,hot:'k3',tag:1,at:[598,252],walk:[[572,284]],pay:'k3'}),
    a('5 coins','5 monedas',{hot:'k5',tag:1,at:[652,252],walk:[[624,284]],fx:'look',fb:{en:'"Tres" is three. Five is "cinco".',es:'"Three" es tres. Cinco es "five".'}}),
    a('10 coins','10 monedas',{hot:'k10',tag:1,at:[708,252],walk:[[680,284]],fx:'look',fb:{en:'"Tres" is three, not ten.',es:'"Three" es tres, no diez.'}})]},
  {t:'type',b:[540,284],n:[652,214],line:'Pregunta uno:|Question one: / ¿qué hora es?|what time is it?',
    prompt:{en:'Read the tower clock and tell him the time.',es:'Mira el reloj de la torre y dile la hora.'},
    say:{es:'Son las cinco.',en:'It\'s five o\'clock.'},
    ans:{es:['son las cinco en punto','las cinco','son las 5'],en:["it's five",'it is five',"it is five o'clock","it's 5",'five oclock']}},
  {t:'type',b:[540,284],n:[652,214],show:'bunch',line:'Pregunta dos:|Question two: / ¿cuántas zanahorias|how many carrots / hay en mi caja?|are in my box?',
    prompt:{en:'Count them and answer.',es:'Cuéntalas y contesta.'},
    say:{es:'Hay cinco.',en:'There are five.'},
    ans:{es:['hay cinco zanahorias','cinco','5','hay 5'],en:['there are five carrots','five','5','there are 5','five carrots']}},
  {t:'say',b:[540,284],n:[652,214],show:'bunch',line:'Pregunta tres:|Question three: / usted está en mi tienda.|you are in my shop. / ¿Qué me dice?|What do you say to me?',opts:{
    es:[{t:'Quisiera zanahorias, por favor.',ok:1},{t:'La cuenta, por favor.',fb:'"La cuenta" is for the café. In a shop, order: quisiera…'},{t:'Siéntese, por favor.',fb:'That\'s what a waiter says. You are the customer.'}],
    en:[{t:'I\'d like some carrots, please.',ok:1},{t:'The bill, please.',fb:'"The bill" es para el café. En una tienda se pide: I\'d like…'},{t:'Sit down, please.',fb:'Eso lo dice el camarero. Tú eres el cliente.'}]}},
  {t:'say',b:[540,284],n:[652,214],show:'bunch',line:'¡Usted gana!|You win! / ¡Felicidades!|Congratulations!',opts:[
    o('¡Muchas gracias!','Thank you very much!',1),
    o('De nada.','You\'re welcome.',0,'He congratulated you. Thank him: "muchas gracias".','Te felicitó. Dale las gracias: "thank you very much".'),
    o('Lo siento.','I\'m sorry.',0,'You won! Nothing to be sorry about.','¡Ganaste! No hay nada que lamentar.')]}
 ]}
]};
