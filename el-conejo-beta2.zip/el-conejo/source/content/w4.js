const {w,o,a,m,T}=require('./lib.js');
const city={sky:'city',ground:'city',back:'city'};
const walkway=(W)=>['sidewalk',W,236,300];
module.exports={
id:4,key:'city',color:'#3F7FBF',
name:T('La Ciudad','The City'),
cast:['pigeon','cat','mouse','squirrel','hen','abuela'],
intro:{en:'The city is loud, tall and full of buses. Somewhere in it, Abuela is getting the Carrot Festival ready. Find her street, her building and her door, and bring every carrot you collected.',
       es:'La ciudad es ruidosa, alta y llena de autobuses. En algún lugar, la Abuela prepara la Fiesta de la Zanahoria. Encuentra su calle, su edificio y su puerta, y lleva todas las zanahorias que juntaste.'},
outro:{en:'The Carrot Festival is a success, and every friend from your trip is there. ¡Felicidades! You finished beta 2.',
       es:'La Fiesta de la Zanahoria es un éxito, y todos los amigos del viaje están allí. Congratulations! Terminaste la beta 2.'},
levels:[

/* 4-1 bus stop */
{id:'w4l1',diff:'easy',npc:'pigeon',
 title:T('La parada de autobús','The Bus Stop'),theme:{en:'Numbers 11 to 50',es:'Números del 11 al 50'},
 can:{en:'understand bus numbers and ask which bus goes where.',es:'entender números de autobús y preguntar qué autobús va adónde.'},
 note:{en:'From 16 to 29 Spanish joins the words: <b>dieciséis</b>, <b>veinte</b>, <b>veintidós</b>. From 31 on they stay separate with <b>y</b>: <b>treinta y uno</b>. Watch out: <b>quince</b> (15) and <b>cincuenta</b> (50) sound close.',
       es:'En inglés, del 13 al 19 terminan en <b>-teen</b> (fifteen) y las decenas en <b>-ty</b> (fifty). Se confunden mucho: <b>fifteen</b> (15) y <b>fifty</b> (50).'},
 lesson:[w('el autobús','the bus',['autobus','el bus'],['bus']),w('la parada','the stop',['parada'],['stop','the bus stop']),w('once','eleven',['11'],['11']),w('doce','twelve',['12'],['12']),
   w('quince','fifteen',['15'],['15']),w('veinte','twenty',['20'],['20']),w('cincuenta','fifty',['50'],['50']),w('¿qué autobús?','which bus?',['que autobus','cual autobus'],['what bus']),
   w('va al centro','goes downtown',['va al centro de la ciudad'],['goes to the center','goes to the city center']),w('el boleto','the ticket',['boleto','el billete'],['ticket'])],
 scene:{w:950,...city,start:[-40,286],
  items:[['road',950,190,236],walkway(950),['building',120,236,110,150,'#E8B98A'],['planter',250,262],
   ['g','bus15',[['bus',560,226,'15','#3D9A5A','',T('CENTRO','DOWNTOWN')]],'hideuntil'],
   ['g','stop12',[['busStop',470,240,'12']]],['g','stop15',[['busStop',560,240,'15']]],['g','stop50',[['busStop',650,240,'50']]],
   ['building',840,236,130,170,'#9DC3E6'],['lamp',740,262]],
  finale:{walk:[[560,288]],src:[600,200]}},
 outro:'¡Buen viaje|Have a good ride / en el quince!|on the fifteen!',
 nodes:[
  {t:'say',b:[220,288],n:[330,270],line:'¡Rrru!|Coo! / ¿Es tu primera vez|Is this your first time / en la ciudad?|in the city?',opts:[
    o('Sí, es mi primera vez.','Yes, it\'s my first time.',1),
    o('Sí, soy la ciudad.','Yes, I\'m the city.',0,'"Soy" means I am. Say "es mi primera vez", it\'s my first time.','"I\'m" es soy. Di "it\'s my first time", es mi primera vez.'),
    o('No, gracias.','No, thank you.',0,'She didn\'t offer anything. She asked if it\'s your first time.','No te ofreció nada. Preguntó si es tu primera vez.')]},
  {t:'type',b:[220,288],n:[330,270],line:'¿Adónde vas?|Where are you going?',
    prompt:{en:'Ask which bus goes downtown.',es:'Pregunta qué autobús va al centro.'},
    say:{es:'¿Qué autobús va al centro?',en:'Which bus goes downtown?'},
    ans:{es:['cual autobus va al centro','que bus va al centro','que autobus va al centro por favor','cual va al centro'],en:['what bus goes downtown','which bus goes to the center','which bus goes to the city center','what bus goes to downtown','which bus goes downtown please']}},
  {t:'listen',b:[220,288],n:[330,270],line:'Toma el autobús|Take bus / número quince.|number fifteen.',opts:[
    m('Take bus number fifteen.','Toma el autobús número quince.',1),
    m('Take bus number fifty.','Toma el autobús número cincuenta.',0,'"Quince" is 15. Fifty is "cincuenta".','"Fifteen" es quince. "Fifty" es cincuenta.'),
    m('Take bus number five.','Toma el autobús número cinco.',0,'"Quince" (15), not "cinco" (5).','"Fifteen" (15), no "five" (5).')]},
  {t:'act',b:[392,290],n:[318,268],line:'La parada|The stop / del quince|for the fifteen / está ahí.|is over there.',opts:[
    a('Stop 12','Parada 12',{hot:'stop12',at:[470,300],walk:[[460,290]],fx:'look',fb:{en:'This is "doce", 12. You want "quince", 15.',es:'Esta es la "twelve", 12. Buscas la "fifteen", 15.'}}),
    a('Stop 15','Parada 15',{ok:1,hot:'stop15',at:[560,300],walk:[[540,290]],show:'bus15'}),
    a('Stop 50','Parada 50',{hot:'stop50',at:[650,300],walk:[[630,290]],fx:'look',fb:{en:'This is "cincuenta", 50. She said "quince", 15.',es:'Esta es la "fifty", 50. Dijo "fifteen", 15.'}})]},
  {t:'say',b:[540,290],n:[460,272],line:'¡Ahí viene!|Here it comes! / El boleto cuesta|The ticket costs / dos monedas.|two coins.',opts:[
    o('Aquí tiene. ¡Gracias!','Here you are. Thank you!',1),
    o('¿Cuánto cuesta?','How much is it?',0,'She just told you: "dos monedas", two coins.','Te lo acaba de decir: "two coins", dos monedas.'),
    o('Doce, por favor.','Twelve, please.',0,'The price is two coins. Pay: "aquí tiene".','El precio es dos monedas. Paga: "here you are".')]}
 ]},

/* 4-2 crossing the street */
{id:'w4l2',diff:'easy',npc:'cat',
 title:T('El paso de cebra','The Crosswalk'),theme:{en:'Waiting and crossing safely',es:'Esperar y cruzar con cuidado'},
 can:{en:'understand safety instructions and say something is dangerous.',es:'entender instrucciones de seguridad y decir que algo es peligroso.'},
 note:{en:'Instructions to a friend use the <b>tú</b> command, which usually looks like "he/she" form: <b>espera</b> (wait), <b>cruza</b> (cross), <b>mira</b> (look). Negative commands change: <b>¡no cruces!</b> (don\'t cross!).',
       es:'En inglés las órdenes usan el verbo solo: <b>wait</b>, <b>cross</b>, <b>look</b>. Para negar se añade <b>don\'t</b>: <b>don\'t cross!</b>'},
 lesson:[w('espera','wait',['espere'],['hold on']),w('la luz','the light',['luz','el semaforo'],['light','the traffic light']),w('roja','red',['rojo'],[]),w('verde','green',[],[]),
   w('cruza','cross',['cruce'],['go across']),w('ahora','now',['ya'],['right now']),w('el paso de cebra','the crosswalk',['paso de cebra','paso peatonal'],['crosswalk','the zebra crossing']),
   w('la calle','the street',['calle'],['street','the road']),w('peligroso','dangerous',['es peligroso'],['unsafe'])],
 scene:{w:950,...city,start:[-40,290],
  items:[walkway(950),['building',140,236,120,160,'#E8B98A',T('HOTEL','HOTEL')],['building',300,236,100,130,'#C9D6E3'],
   ['crossStreet',600,170,'street'],['trafficLight',500,252,'light'],['raw','<rect x="568" y="206" width="64" height="26" rx="6" fill="#D84A3A" stroke="#25311F" stroke-width="1.4"/><rect x="578" y="210" width="20" height="10" rx="2" fill="#CFE8F2"/><circle cx="578" cy="232" r="5" fill="#3E4A44"/><circle cx="622" cy="232" r="5" fill="#3E4A44"/>'],
   ['building',820,236,130,170,'#F2D49B'],['planter',920,266],['streetSign',870,262,T('CALLE SOL','SUN ST')]],
  finale:{walk:[[790,290]],src:[820,230]}},
 outro:'¡Muy bien!|Very good! / Siempre con|Always with / la luz verde.|the green light.',
 nodes:[
  {t:'say',b:[260,290],n:[380,268],line:'¡Alto!|Stop! / ¿Adónde vas,|Where are you going, / conejo?|bunny?',opts:[
    o('Voy a la casa de mi abuela.','I\'m going to my grandma\'s house.',1),
    o('Voy a la luz roja.','I\'m going to the red light.',0,'He asked where you\'re headed: your grandma\'s house.','Te preguntó adónde vas: a casa de tu abuela.'),
    o('Soy la calle.','I am the street.',0,'"Soy" means I am. Use "voy a" for where you are going.','"I am" es soy. Usa "I\'m going to" para adónde vas.')]},
  {t:'listen',b:[260,290],n:[380,268],line:'La luz está roja.|The light is red. / Hay coches.|There are cars.',opts:[
    m('The light is red. There are cars.','La luz está roja. Hay coches.',1),
    m('The light is green. There are no cars.','La luz está verde. No hay coches.',0,'"Roja" is red, and "hay coches" means there are cars.','"Red" es roja, y "there are cars" es hay coches.'),
    m('The street is red. There are buses.','La calle está roja. Hay autobuses.',0,'He said "la luz", the light, and "coches", cars.','Dijo "the light", la luz, y "cars", coches.')]},
  {t:'act',b:[452,292],n:[386,268],line:'¡Espera!|Wait! / Cruza con|Cross with / la luz verde.|the green light.',opts:[
    a('Wait here','Esperar aquí',{ok:1,hot:'light',at:[452,300],walk:[[448,292]],light:'light'}),
    a('Cross now','Cruzar ya',{at:[580,300],walk:[[540,292]],fx:'bonk',fb:{en:'"¡Espera!" The light is red. A car honked at you!',es:'"Wait!": la luz está roja. ¡Un coche te pitó!'}})]},
  {t:'act',b:[448,292],n:[386,268],line:'¡Verde!|Green! / Ahora cruza|Now cross / por el paso de cebra.|on the crosswalk.',opts:[
    a('On the crosswalk','Por el paso de cebra',{ok:1,hot:'street',at:[600,300],walk:[[530,288],[700,288],[740,290]]}),
    a('Cross up there','Cruzar más arriba',{at:[700,300],walk:[[540,262],[586,246]],fx:'bonk',fb:{en:'"Por el paso de cebra": on the crosswalk, the white stripes.',es:'"On the crosswalk": por el paso de cebra, las rayas blancas.'}})]},
  {t:'type',b:[740,290],n:[812,274],line:'¡Perfecto!|Perfect! / ¿Es peligroso|Is it dangerous / cruzar en rojo?|to cross on red?',
    prompt:{en:'Say yes, it\'s very dangerous.',es:'Di que sí, que es muy peligroso.'},
    say:{es:'Sí, es muy peligroso.',en:'Yes, it\'s very dangerous.'},
    ans:{es:['si es peligroso','es muy peligroso','es peligroso','si muy peligroso'],en:['yes it is dangerous','yes it is very dangerous',"it's very dangerous",'it is dangerous',"yes it's dangerous"]}}
 ]},

/* 4-3 directions in the street */
{id:'w4l3',diff:'medium',npc:'mouse',
 title:T('La calle de las tiendas','The Shopping Street'),theme:{en:'Between, next to, across from',es:'Entre, al lado de, enfrente de'},
 can:{en:'ask politely for directions and find a place between two others.',es:'pedir indicaciones con cortesía y encontrar un lugar entre otros dos.'},
 note:{en:'<b>Entre</b> means between: <b>entre el banco y la librería</b>. False friend alert: <b>librería</b> is a bookshop; a library is a <b>biblioteca</b>. And <b>el banco</b> is both a bank and a bench!',
       es:'En inglés, <b>between</b> es entre: <b>between the bank and the bookshop</b>. Falso amigo: <b>library</b> es biblioteca; librería es <b>bookshop</b> o <b>bookstore</b>.'},
 lesson:[w('entre','between',[],['in between']),w('la floristería','the flower shop',['floristeria','la floreria'],['flower shop','the florist']),w('el banco','the bank',['banco'],['bank']),
   w('la librería','the bookshop',['libreria'],['bookstore','the bookstore','bookshop']),w('la farmacia','the pharmacy',['farmacia'],['pharmacy','the drugstore']),
   w('¿me puede decir?','can you tell me?',['me puede decir','puede decirme'],['could you tell me']),w('enfrente de','across from',['frente a'],['opposite']),w('la tienda','the shop',['tienda'],['shop','the store'])],
 scene:{w:900,...city,start:[-40,290],
  items:[walkway(900),['shop',300,238,84,T('FARMACIA','PHARMACY'),'#3D7A33','pills','pharm'],['shop',390,238,84,'','#5FA046','cups','shopA'],
   ['building',480,236,84,120,'#C9D6E3',T('BANCO','BANK'),'bank'],['shop',570,238,84,'','#E07BB0','flowers','shopB'],
   ['shop',660,238,84,T('LIBRERÍA','BOOKSHOP'),'#7A5AA8','books','books'],['building',780,236,110,150,'#E8B98A'],['lamp',200,262]],
  finale:{walk:[[590,292]],src:[570,214]}},
 outro:'¡Que le vaya bien!|All the best!',
 nodes:[
  {t:'say',b:[180,292],n:[300,270],line:'¡Hola!|Hi! / ¿Necesita ayuda?|Do you need help?',opts:[
    o('Sí, busco una floristería.','Yes, I\'m looking for a flower shop.',1),
    o('Sí, soy una floristería.','Yes, I\'m a flower shop.',0,'"Soy" is I am. Use "busco", I\'m looking for.','"I\'m" sola es soy. Usa "I\'m looking for", busco.'),
    o('No, necesito ayuda.','No, I need help.',0,'That\'s a contradiction! If you need help, say "sí".','¡Eso se contradice! Si necesitas ayuda, di "yes".')]},
  {t:'type',b:[180,292],n:[300,270],line:'Hay una|There\'s one / en esta calle.|on this street.',
    prompt:{en:'Ask politely: "Can you tell me where it is?"',es:'Pregunta con cortesía: "¿Me puede decir dónde está?"'},
    say:{es:'¿Me puede decir dónde está?',en:'Can you tell me where it is?'},
    ans:{es:['puede decirme donde esta','me puede decir donde esta por favor','donde esta','me dice donde esta'],en:['could you tell me where it is','can you tell me where it is please','where is it','could you tell me where it is please']}},
  {t:'act',b:[340,292],n:[420,264],line:'Está entre|It\'s between / el banco|the bank / y la librería.|and the bookshop.',opts:[
    a('Green awning','Toldo verde',{hot:'shopA',at:[390,300],walk:[[386,292]],fx:'look',fb:{en:'This shop is between the pharmacy and the bank. She said "entre el banco y la librería".',es:'Esta tienda está entre la farmacia y el banco. Dijo "between the bank and the bookshop".'}}),
    a('The bank','El banco',{hot:'bank',at:[480,300],walk:[[470,292]],fx:'look',fb:{en:'That\'s "el banco" itself. The flower shop is next to it, on the other side.',es:'Ese es el banco. La floristería está a su lado, del otro lado.'}}),
    a('Pink awning','Toldo rosa',{ok:1,hot:'shopB',at:[570,300],walk:[[560,292]]})]},
  {t:'listen',b:[560,292],n:[480,272],line:'¡Esa es!|That\'s it! / Y enfrente|And across the street / hay una biblioteca.|there\'s a library.',opts:[
    m('That\'s it! And across the street there\'s a library.','¡Esa es! Y enfrente hay una biblioteca.',1),
    m('That\'s it! And next door there\'s a bookshop.','¡Esa es! Y al lado hay una librería.',0,'"Biblioteca" is a library, and "enfrente" is across from.','"Library" es biblioteca, y "across" es enfrente.'),
    m('No, it\'s the library.','No, es la biblioteca.',0,'She said "¡esa es!", that\'s it.','Dijo "that\'s it!", ¡esa es!')]}
 ]},

/* 4-4 the park */
{id:'w4l4',diff:'medium',npc:'squirrel',
 title:T('El parque','The Park'),theme:{en:'Family',es:'La familia'},
 can:{en:'talk about your family and say someone\'s name.',es:'hablar de tu familia y decir cómo se llama alguien.'},
 note:{en:'<b>Llamarse</b> changes with the person: <b>me llamo</b> (my name is), <b>te llamas</b> (your name is), <b>se llama</b> (his/her name is). <b>Hermanos</b> can mean brothers or brothers and sisters.',
       es:'En inglés el nombre va con <b>is</b>: <b>my name is</b>, <b>her name is</b>, <b>his name is</b>. Y <b>siblings</b> significa hermanos y hermanas juntos.'},
 lesson:[w('la familia','the family',['familia'],['family']),w('el hermano','the brother',['hermano','mi hermano'],['brother']),w('la hermana','the sister',['hermana','mi hermana'],['sister']),
   w('la mamá','the mom',['mama','la madre'],['mom','mother','the mother']),w('el papá','the dad',['papa','el padre'],['dad','father','the father']),w('la abuela','the grandmother',['abuela'],['grandma','the grandma','grandmother']),
   w('¿tienes hermanos?','do you have siblings?',['tienes hermanos'],['do you have brothers or sisters','do you have any siblings']),w('se llama','her name is',[],['his name is','is called']),w('perdido','lost',['perdida'],[])],
 scene:{w:900,sky:'day',ground:'grass',back:'city',start:[-40,290],
  items:[['path','M-30 290C200 290 500 290 930 290',26,'#E3D2A8'],['g','bench',[['bench',390,258],['critter','squirrel',380,252,0,.9]]],
   ['g','fountainSq',[['fountain',480,252],['critter','squirrel',520,262,1,.9]]],
   ['g','treeSq',[['tree',590,244,1.1],['critter','squirrel',572,262,0,.62]]],
   ['tree',160,240,.9],['flowerbed',260,256,70,'#E2504A'],['bush',720,252,.9],['lamp',800,264],['scatter',44,0,340,200,276,10]],
  finale:{walk:[[530,292]],src:[572,240]}},
 outro:'¡Gracias, amigo!|Thanks, friend! / Saludos a tu abuela.|Say hi to your grandma.',
 nodes:[
  {t:'say',b:[200,292],n:[320,274],line:'¡Conejo!|Conejo! / ¿Qué haces en la ciudad?|What are you doing in the city?',opts:[
    o('Visito a mi abuela.','I\'m visiting my grandma.',1),
    o('Visito mi abuela.','I\'m visiting my grandma.',0,'Visiting a person needs the little word "a": visito a mi abuela.','Para visitar a una persona, en español va "a": visito a mi abuela.'),
    o('Soy tu abuela.','I\'m your grandma.',0,'You\'re not her grandma! Say "visito a mi abuela".','¡No eres su abuela! Di "I\'m visiting my grandma".')]},
  {t:'type',b:[200,292],n:[320,274],line:'¡Qué bien!|How nice! / ¿Tienes hermanos?|Do you have brothers or sisters?',
    prompt:{en:'Say yes, you have a sister.',es:'Di que sí, que tienes una hermana.'},
    say:{es:'Sí, tengo una hermana.',en:'Yes, I have a sister.'},
    ans:{es:['tengo una hermana','si una hermana','si tengo una hermana mayor','si tengo una hermana menor'],en:['i have a sister','yes one sister','yes i have one sister',"yes i've got a sister"]}},
  {t:'listen',b:[200,292],n:[320,274],line:'Yo tengo dos hermanos.|I have two brothers. / Mi hermano pequeño|My little brother / está perdido.|is lost.',opts:[
    m('I have two brothers. My little brother is lost.','Yo tengo dos hermanos. Mi hermano pequeño está perdido.',1),
    m('I have two sisters. My big sister is lost.','Yo tengo dos hermanas. Mi hermana mayor está perdida.',0,'"Hermano" is brother, and "pequeño" is little.','"Brother" es hermano, y "little" es pequeño.'),
    m('My little brother is at home.','Mi hermano pequeño está en casa.',0,'"Perdido" means lost.','"Lost" es perdido.')]},
  {t:'act',b:[300,294],n:[236,274],line:'Mi papá está|My dad is / en el banco.|on the bench. / Mi hermano está|My brother is / debajo del árbol.|under the tree.',opts:[
    a('On the bench','En el banco',{hot:'bench',at:[390,300],walk:[[370,292]],fx:'look',fb:{en:'That\'s her dad: "mi papá está en el banco". Her brother is under the tree.',es:'Ese es su papá: "my dad is on the bench". Su hermano está debajo del árbol.'}}),
    a('By the fountain','Junto a la fuente',{hot:'fountainSq',at:[480,300],walk:[[466,292]],fx:'look',fb:{en:'Nobody mentioned the fountain. Listen for "debajo del árbol", under the tree.',es:'Nadie habló de la fuente. Escucha "under the tree", debajo del árbol.'}}),
    a('Under the tree','Debajo del árbol',{ok:1,hot:'treeSq',at:[590,300],walk:[[530,292]]})]},
  {t:'say',b:[530,292],n:[450,276],line:'¡Gracias!|Thanks! / ¿Cómo se llama|What\'s the name / tu abuela?|of your grandma?',opts:[
    o('Se llama Rosa.','Her name is Rosa.',1),
    o('Me llamo Rosa.','My name is Rosa.',0,'"Me llamo" is about you. For your grandma: "se llama".','"My name is" habla de ti. Para tu abuela: "her name is".'),
    o('Tengo una abuela.','I have a grandma.',0,'She asked her name, not if you have one.','Te preguntó su nombre, no si tienes una.')]}
 ]},

/* 4-5 the florist */
{id:'w4l5',diff:'medium',npc:'hen',
 title:T('La floristería','The Flower Shop'),theme:{en:'Likes: me gusta, le gustan',es:'Gustos: I like, she likes'},
 can:{en:'say what you and other people like.',es:'decir lo que te gusta a ti y a otras personas.'},
 note:{en:'<b>Gustar</b> works backwards: the thing liked is the subject. One thing: <b>me gusta la rosa</b>. Several things: <b>me gustan las rosas</b>. For someone else use <b>le</b>: <b>a la Abuela le gustan los girasoles</b>.',
       es:'En inglés <b>like</b> funciona al revés que gustar: la persona es el sujeto. <b>I like roses</b>, <b>she likes sunflowers</b> (con -s para he/she).'},
 lesson:[w('me gusta','I like',['a mi me gusta'],['i really like']),w('me gustan','I like them',['a mi me gustan'],['i like']),w('le gustan','she likes',['a ella le gustan'],['he likes','she likes them']),
   w('los girasoles','the sunflowers',['girasoles'],['sunflowers']),w('las rosas','the roses',['rosas'],['roses']),w('los tulipanes','the tulips',['tulipanes'],['tulips']),
   w('el ramo','the bouquet',['ramo'],['bouquet','the bunch of flowers']),w('para mi abuela','for my grandma',['para la abuela'],['for my grandmother'])],
 scene:{w:900,...city,start:[-40,290],
  items:[walkway(900),['shop',280,238,170,T('FLORES','FLOWERS'),'#C55A9A','flowers','florist'],
   ['g','bSun',[['flowerStand',460,262,[{id:'',kind:'sun'}]]]],['g','bRose',[['flowerStand',540,262,[{id:'',kind:'rose'}]]]],['g','bTulip',[['flowerStand',620,262,[{id:'',kind:'tulip'}]]]],
   ['building',760,236,130,160,'#C9D6E3'],['planter',860,266]],
  finale:{walk:[[490,292]],src:[460,226]}},
 outro:'¡A su abuela|Your grandma / le va a encantar!|is going to love it!',
 nodes:[
  {t:'say',b:[180,292],n:[300,272],line:'¡Bienvenido!|Welcome! / ¿Le gustan las flores?|Do you like flowers?',opts:[
    o('Sí, me gustan mucho.','Yes, I like them a lot.',1),
    o('Sí, me gusta mucho las flores.','Yes, I like the flowers a lot.',0,'"Las flores" is plural, so the verb is plural too: me gustan.','"Las flores" es plural, así que el verbo también: me gustan.'),
    o('Sí, soy flores.','Yes, I am flowers.',0,'"Soy" is I am. Liking uses "me gustan".','"I am" es soy. Para gustos se usa "me gustan".')]},
  {t:'type',b:[180,292],n:[300,272],line:'¿Qué desea?|What would you like?',
    prompt:{en:'Say you would like flowers for your grandma.',es:'Di que quisieras flores para tu abuela.'},
    say:{es:'Quisiera flores para mi abuela.',en:'I\'d like flowers for my grandma.'},
    ans:{es:['quiero flores para mi abuela','quisiera unas flores para mi abuela','flores para mi abuela','quisiera flores para mi abuela por favor'],en:['i would like flowers for my grandma','i want flowers for my grandma','flowers for my grandma please','i would like some flowers for my grandmother',"i'd like some flowers for my grandma"]}},
  {t:'listen',b:[180,292],n:[300,272],line:'¡La señora Rosa!|Mrs. Rosa! / A ella le gustan|She likes / los girasoles.|sunflowers.',opts:[
    m('Mrs. Rosa! She likes sunflowers.','¡La señora Rosa! A ella le gustan los girasoles.',1),
    m('Mrs. Rosa! She likes roses.','¡La señora Rosa! A ella le gustan las rosas.',0,'"Girasoles" are sunflowers. Roses are "rosas".','"Sunflowers" son girasoles. "Roses" son rosas.'),
    m('Mrs. Rosa doesn\'t like flowers.','A la señora Rosa no le gustan las flores.',0,'There was no "no": "le gustan" means she likes them.','No hubo "no": "she likes" es le gustan.')]},
  {t:'act',b:[380,294],n:[300,272],line:'¿Cuáles quiere?|Which ones do you want?',opts:[
    a('Sunflowers','Girasoles',{ok:1,hot:'bSun',at:[460,300],walk:[[440,294]]}),
    a('Roses','Rosas',{hot:'bRose',at:[540,300],walk:[[520,294]],fx:'look',fb:{en:'Those are "rosas". Abuela likes "los girasoles", sunflowers.',es:'Esas son "roses", rosas. A la Abuela le gustan los girasoles, "sunflowers".'}}),
    a('Tulips','Tulipanes',{hot:'bTulip',at:[620,300],walk:[[600,294]],fx:'look',fb:{en:'Those are "tulipanes", tulips. She said "girasoles".',es:'Esos son "tulips", tulipanes. Dijo "sunflowers", girasoles.'}})]},
  {t:'say',b:[440,294],n:[360,272],line:'Aquí tiene su ramo.|Here is your bouquet. / ¿Le gusta?|Do you like it?',opts:[
    o('Sí, me gusta mucho. ¡Gracias!','Yes, I like it a lot. Thank you!',1),
    o('Sí, le gustan.','Yes, she likes them.',0,'She asked if YOU like it: "me gusta".','Te preguntó si TE gusta a ti: "I like it".'),
    o('No, me gustan.','No, I like them.',0,'"No" and then "me gustan" don\'t match. Say "sí, me gusta".','"No" y luego "I like them" no encajan. Di "yes, I like it".')]}
 ]},

/* 4-6 the apartment building */
{id:'w4l6',diff:'medium',npc:'cat',
 title:T('El edificio de la Abuela','Abuela\'s Building'),theme:{en:'Floors and ordinal numbers',es:'Pisos y números ordinales'},
 can:{en:'ask for someone at a building and understand which floor and door.',es:'preguntar por alguien en un edificio y entender el piso y la puerta.'},
 note:{en:'Ordinals: <b>primero, segundo, tercero, cuarto</b>. Before a masculine noun, primero and tercero drop the -o: <b>el tercer piso</b>. When the object is a person, Spanish adds <b>a</b>: <b>busco a mi abuela</b>.',
       es:'Ordinales en inglés: <b>first, second, third, fourth</b>. Para pisos: <b>on the third floor</b>. Para buscar a alguien no hace falta "a": <b>I\'m looking for my grandma</b>.'},
 lesson:[w('busco a','I\'m looking for',['estoy buscando a'],['i am looking for']),w('vive','she lives',['ella vive'],['lives','he lives']),w('el piso','the floor',['piso','la planta'],['floor']),
   w('primero','first',['primer'],[]),w('segundo','second',[],[]),w('el tercer piso','the third floor',['tercer piso','el tercero'],['third floor']),w('la entrada','the entrance',['entrada'],['entrance','the door']),
   w('el ascensor','the elevator',['ascensor','el elevador'],['elevator','the lift']),w('la escalera','the stairs',['escalera','las escaleras'],['stairs','the staircase'])],
 scene:{w:950,...city,start:[-40,292],
  items:[walkway(950),['building',140,236,120,160,'#9DC3E6'],['planter',300,266],
   ['apartment',560,240,[{id:'dA',label:'A',col:'#C0563F'},{id:'dB',label:'B',col:'#3F7FBF'},{id:'dC',label:'C',col:'#3D7A33'}]],
   ['lamp',760,264],['building',860,236,130,170,'#F2D49B']],
  finale:{walk:[[560,290]],src:[560,200]}},
 outro:'¡Sube, sube!|Go up, go up! / ¡Tu abuela te espera!|Your grandma is waiting!',
 nodes:[
  {t:'say',b:[200,292],n:[370,262],line:'Buenas tardes.|Good afternoon. / ¿A quién busca?|Who are you looking for?',opts:[
    o('Busco a mi abuela.','I\'m looking for my grandma.',1),
    o('Busco mi abuela.','I\'m looking for my grandma.',0,'When you look for a person, add "a": busco a mi abuela.','Cuando buscas a una persona, en español va "a": busco a mi abuela.'),
    o('Soy mi abuela.','I am my grandma.',0,'You\'re her grandson, not her! Use "busco a".','¡Eres su nieto, no ella! Usa "I\'m looking for".')]},
  {t:'listen',b:[200,292],n:[370,262],line:'Ah, la señora Rosa.|Ah, Mrs. Rosa. / Vive en|She lives on / el tercer piso.|the third floor.',opts:[
    m('Ah, Mrs. Rosa. She lives on the third floor.','Ah, la señora Rosa. Vive en el tercer piso.',1),
    m('Ah, Mrs. Rosa. She lives on the first floor.','Ah, la señora Rosa. Vive en el primer piso.',0,'"Tercer" is third. First is "primer".','"Third" es tercer. "First" es primer.'),
    m('Mrs. Rosa isn\'t home.','La señora Rosa no está en casa.',0,'He said where she lives: "vive en el tercer piso".','Dijo dónde vive: "she lives on the third floor".')]},
  {t:'type',b:[200,292],n:[370,262],line:'Hay tres entradas.|There are three entrances.',
    prompt:{en:'Ask which entrance it is.',es:'Pregunta qué entrada es.'},
    say:{es:'¿Qué entrada es?',en:'Which entrance is it?'},
    ans:{es:['cual es la entrada','cual entrada es','que entrada','por cual entrada'],en:['which entrance','which one is it','what entrance is it','which entrance do i use']}},
  {t:'act',b:[430,294],n:[370,262],line:'La de la puerta azul.|The one with the blue door.',opts:[
    a('Door A','Puerta A',{hot:'dA',at:[470,300],walk:[[466,294]],fx:'bonk',fb:{en:'Door A is red, "roja". He said "la puerta azul", the blue door.',es:'La puerta A es roja, "red". Dijo "the blue door", la puerta azul.'}}),
    a('Door B','Puerta B',{ok:1,hot:'dB',at:[560,300],walk:[[550,292]]}),
    a('Door C','Puerta C',{hot:'dC',at:[650,300],walk:[[640,294]],fx:'bonk',fb:{en:'Door C is green, "verde". He said "azul", blue.',es:'La puerta C es verde, "green". Dijo "blue", azul.'}})]},
  {t:'say',b:[550,292],n:[470,270],line:'El ascensor|The elevator / está roto.|is broken. / Sube por la escalera.|Go up the stairs.',opts:[
    o('Vale, subo por la escalera.','Okay, I\'ll go up the stairs.',1),
    o('Voy en el ascensor.','I\'ll take the elevator.',0,'"Está roto": the elevator is broken!','"It\'s broken": ¡el ascensor está roto!'),
    o('Bajo al primer piso.','I\'ll go down to the first floor.',0,'She lives on the third floor. Go up: "subo".','Vive en el tercer piso. Sube: "I\'ll go up".')]}
 ]},

/* 4-7 Abuela's home */
{id:'w4l7',diff:'hard',npc:'abuela',
 title:T('La casa de la Abuela','Abuela\'s Home'),theme:{en:'Rooms and requests',es:'Habitaciones y peticiones'},
 can:{en:'follow requests at home and talk about a trip.',es:'seguir peticiones en casa y hablar de un viaje.'},
 note:{en:'<b>Pon</b> (put) and <b>abre</b> (open) are friendly commands. To talk about the trip that\'s finished, use the past: <b>fue largo</b> (it was long), <b>fue divertido</b> (it was fun).',
       es:'En inglés las peticiones suenan más amables con <b>please</b> o <b>could you…?</b>: <b>Could you open the door?</b> Y el pasado de "is" es <b>was</b>: <b>it was long</b>.'},
 lesson:[w('¡cuánto tiempo!','long time no see!',['cuanto tiempo'],['it has been a long time',"it's been a long time"]),w('el viaje','the trip',['viaje'],['trip','the journey']),
   w('fue largo','it was long',[],['was long']),w('divertido','fun',['divertida'],['fun','funny']),w('la cocina','the kitchen',['cocina'],['kitchen']),
   w('pon','put',['ponga'],['place']),w('el sofá','the sofa',['sofa'],['sofa','the couch']),w('el balcón','the balcony',['balcon'],['balcony']),w('abre','open',['abra'],[])],
 scene:{w:850,sky:'indoor',start:[-40,292],
  items:[['window',90,170,70,64],['stove',160,234],['fridge',224,234],['kitchenTable',420,264,'ktable'],
   ['g','win2',[['window',530,170,70,64]]],['rug',540,286,120],['sofa',540,252,'#5E8FC7','sofa'],
   ['balconyDoor',650,234,'balcony'],['plant',740,262],['frame',740,120],['shelf',400,120]],
  finale:{walk:[[460,292]],src:[420,226]}},
 outro:'¡Mi conejito!|My little bunny! / ¡Qué buen nieto!|What a good grandson!',
 nodes:[
  {t:'say',b:[160,292],n:[300,276],line:'¡Mi conejito!|My little bunny! / ¡Cuánto tiempo!|Long time no see!',opts:[
    o('¡Hola, Abuela! ¡Qué alegría!','Hi, Grandma! How wonderful!',1),
    o('Mucho gusto, señora.','Nice to meet you, ma\'am.',0,'She\'s your grandma! "Mucho gusto" is for people you just met.','¡Es tu abuela! "Nice to meet you" es para alguien que acabas de conocer.'),
    o('¿Cómo se llama?','What\'s your name?',0,'You know your own grandma\'s name: Rosa!','¡Sabes el nombre de tu abuela: Rosa!')]},
  {t:'type',b:[160,292],n:[300,276],line:'¿Cómo fue|How was / el viaje?|the trip?',
    prompt:{en:'Say it was long but fun.',es:'Di que fue largo pero divertido.'},
    say:{es:'Fue largo pero divertido.',en:'It was long but fun.'},
    ans:{es:['fue largo pero muy divertido','fue largo y divertido','largo pero divertido','fue muy largo pero divertido'],en:['it was long but very fun','long but fun','it was long and fun','it was a long trip but fun']}},
  {t:'act',b:[370,294],n:[300,276],line:'Pon las zanahorias|Put the carrots / en la cocina,|in the kitchen, / encima de la mesa.|on the table.',opts:[
    a('On the table','Encima de la mesa',{ok:1,hot:'ktable',at:[420,300],walk:[[460,294]]}),
    a('On the sofa','En el sofá',{hot:'sofa',at:[540,300],walk:[[520,294]],fx:'look',fb:{en:'"La mesa" is the table, in "la cocina", the kitchen.',es:'"The table" es la mesa, en "the kitchen", la cocina.'}}),
    a('On the balcony','En el balcón',{hot:'balcony',at:[650,300],walk:[[630,294]],fx:'look',fb:{en:'She said "en la cocina", in the kitchen.',es:'Dijo "in the kitchen", en la cocina.'}})]},
  {t:'listen',b:[460,294],n:[340,280],line:'Mañana es|Tomorrow is / la Fiesta.|the Festival. / ¡Vamos a cocinar!|Let\'s cook!',opts:[
    m('Tomorrow is the Festival. Let\'s cook!','Mañana es la Fiesta. ¡Vamos a cocinar!',1),
    m('Today is the Festival. Let\'s dance!','Hoy es la Fiesta. ¡Vamos a bailar!',0,'"Mañana" is tomorrow, and "cocinar" is to cook.','"Tomorrow" es mañana, y "cook" es cocinar.'),
    m('Tomorrow we go home.','Mañana vamos a casa.',0,'She mentioned "la Fiesta" and cooking.','Mencionó "the Festival" y cocinar.')]},
  {t:'act',b:[460,294],n:[340,280],line:'Hace calor.|It\'s hot. / Abre la puerta|Open the door / del balcón,|to the balcony, / por favor.|please.',opts:[
    a('The window','La ventana',{hot:'win2',at:[520,300],walk:[[530,294]],fx:'look',fb:{en:'That\'s "la ventana", the window. She said "la puerta del balcón".',es:'Esa es la ventana, "the window". Dijo "the balcony door", la puerta del balcón.'}}),
    a('Balcony door','Puerta del balcón',{ok:1,hot:'balcony',at:[650,300],walk:[[616,294]]})]}
 ]},

/* 4-8 BOSS: the Carrot Festival */
{id:'w4l8',diff:'hard',npc:'abuela',
 title:T('La Fiesta de la Zanahoria','The Carrot Festival'),theme:{en:'Everything you learned',es:'Todo lo que aprendiste'},
 can:{en:'hold a long, friendly conversation using everything from your trip.',es:'mantener una conversación larga y amable con todo lo de tu viaje.'},
 note:{en:'From <b>hola</b> to <b>me gustan los girasoles</b>: greetings, ser and estar, numbers, shopping, directions, feelings, comparisons and likes. That\'s a real A1 foundation in Spanish.',
       es:'De <b>hello</b> a <b>she likes sunflowers</b>: saludos, I am, números, compras, indicaciones, sensaciones, comparaciones y gustos. Esa es una base real de nivel A1 en inglés.'},
 lesson:[w('todos','everyone',['todo el mundo'],['everybody','all']),w('los amigos','the friends',['amigos'],['friends']),w('vino','came',['vino de'],['he came','she came']),
   w('la música','the music',['musica'],['music']),w('el escenario','the stage',['escenario'],['stage']),w('te quiero','I love you',['te amo'],['love you'])],
 scene:{w:1100,sky:'evening',ground:'city',back:'city',start:[-40,292],
  items:[walkway(1100),['bunting',0,1100,120],
   ['critter','turtle',150,272],['critter','hedgehog',220,262],['critter','mole',290,272],['critter','owl',250,150,0,.9],['critter','cat',350,260],
   ['cafeTable',440,256,'#E2681C','smalltable'],['stage',580,240,180,T('FIESTA','FESTIVAL')],['kitchenTable',730,264,'bigtable'],['balloons',660,210],
   ['critter','fox',830,262,1],['critter','frog',890,274,1],['critter','hen',950,264,1],['critter','goat',1020,264,1],['critter','pigeon',800,232,1,.9],['critter','squirrel',1070,272,1],['critter','mouse',1000,234,1]],
  finale:{walk:[[700,292]],src:[580,170]}},
 outro:'¡Viva la Fiesta|Long live the Carrot / de la Zanahoria!|Festival!',
 nodes:[
  {t:'say',b:[400,292],n:[520,270],line:'¡Mira cuántos amigos!|Look how many friends! / ¿Los conoces?|Do you know them?',opts:[
    o('¡Sí! Son mis amigos del viaje.','Yes! They\'re my friends from the trip.',1),
    o('Sí, son las zanahorias.','Yes, they\'re the carrots.',0,'They are animals, your friends! Not carrots.','¡Son animales, tus amigos! No zanahorias.'),
    o('No, soy un conejo.','No, I\'m a bunny.',0,'She asked if you know them, and you do: they\'re your friends.','Te preguntó si los conoces, y sí: son tus amigos.')]},
  {t:'listen',b:[400,292],n:[520,270],line:'Tortuga vino del jardín,|Turtle came from the garden, / Erizo, del mercado|Hedgehog, from the market / y Búho, del bosque.|and Owl, from the forest.',opts:[
    m('Turtle came from the garden, Hedgehog from the market and Owl from the forest.','Tortuga vino del jardín, Erizo del mercado y Búho del bosque.',1),
    m('Turtle came from the market, Hedgehog from the forest and Owl from the garden.','Tortuga vino del mercado, Erizo del bosque y Búho del jardín.',0,'Match them up again: Tortuga → jardín, Erizo → mercado, Búho → bosque.','Vuelve a emparejar: Turtle → garden, Hedgehog → market, Owl → forest.'),
    m('Everyone came from the city.','Todos vinieron de la ciudad.',0,'Each friend came from a different place.','Cada amigo vino de un lugar distinto.')]},
  {t:'type',b:[400,292],n:[520,270],line:'¿Cuántas zanahorias|How many carrots / tienes?|do you have?',
    prompt:{en:'Say you have twenty carrots.',es:'Di que tienes veinte zanahorias.'},
    say:{es:'Tengo veinte zanahorias.',en:'I have twenty carrots.'},
    ans:{es:['tengo veinte','veinte zanahorias','veinte','tengo 20 zanahorias','20'],en:['i have twenty','twenty carrots','twenty',"i've got twenty carrots",'i have 20 carrots','20']}},
  {t:'act',b:[480,294],n:[540,268],line:'Pon las zanahorias|Put the carrots / en la mesa grande,|on the big table, / al lado del escenario.|next to the stage.',opts:[
    a('Small table','Mesa pequeña',{hot:'smalltable',at:[440,300],walk:[[440,294]],fx:'look',fb:{en:'That one is "pequeña", small. She said "la mesa grande".',es:'Esa es "small", pequeña. Dijo "the big table", la mesa grande.'}}),
    a('On the stage','En el escenario',{at:[585,300],walk:[[580,292]],fx:'look',fb:{en:'"Al lado del escenario" means next to the stage, not on it.',es:'"Next to the stage" es al lado del escenario, no encima.'}}),
    a('Big table','Mesa grande',{ok:1,hot:'bigtable',at:[730,300],walk:[[700,294]]})]},
  {t:'say',b:[700,294],n:[620,270],line:'¿Qué te gusta más|What do you like most / de la fiesta?|about the festival?',opts:{
    es:[{t:'Me gusta la música.',ok:1},{t:'Me gustan la música.',fb:'"La música" is one thing, so the verb is singular: me gusta.'},{t:'Le gusta la música.',fb:'"Le gusta" is about someone else. About you: me gusta.'}],
    en:[{t:'I like the music.',ok:1},{t:'Me like the music.',fb:'En inglés el sujeto es "I": "I like the music".'},{t:'She likes the music.',fb:'"She likes" habla de otra persona. Sobre ti: "I like".'}]}},
  {t:'type',b:[700,294],n:[620,270],line:'¡Di algo|Say something / a todos!|to everyone!',
    prompt:{en:'Say: thank you, everyone!',es:'Di: ¡gracias a todos!'},
    say:{es:'¡Gracias a todos!',en:'Thank you, everyone!'},
    ans:{es:['muchas gracias a todos','gracias a todos amigos','gracias amigos','muchas gracias amigos'],en:['thanks everyone','thank you all','thank you everybody','thanks everybody','thank you friends','thank you everyone']}},
  {t:'say',b:[700,294],n:[620,270],line:'¡Te quiero,|I love you, / conejito!|little bunny!',opts:[
    o('¡Yo también te quiero, Abuela!','I love you too, Grandma!',1),
    o('¡Mucho gusto, Abuela!','Nice to meet you, Grandma!',0,'You\'ve known her forever! Tell her you love her too.','¡La conoces de siempre! Dile que tú también la quieres.'),
    o('¿Adónde vas?','Where are you going?',0,'She\'s not going anywhere. Answer "yo también te quiero".','No se va a ninguna parte. Contesta "I love you too".')]}
 ]}
]};
