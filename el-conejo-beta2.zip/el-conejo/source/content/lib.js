// helpers for writing levels
// a phrase for the lesson: Spanish, English, other accepted Spanish, other accepted English
const w=(es,en,altEs=[],altEn=[])=>({es,en,alt:{es:altEs,en:altEn}});
// a line of dialogue for a choice; fb is the feedback when it is the wrong pick (en: for English speakers, es: for Spanish speakers)
const o=(es,en,ok,fbEn,fbEs)=>Object.assign({es,en},ok?{ok:1}:{},fbEn?{fb:{en:fbEn,es:fbEs}}:{});
// a place or action the bunny can choose in the scene; the label is in the player's own language
const a=(en,es,props)=>Object.assign({en,es,lab:{en,es}},props);
// a meaning to pick after listening (shown in the player's own language)
const m=(en,es,ok,fbEn,fbEs)=>Object.assign({en,es},ok?{ok:1}:{},fbEn?{fb:{en:fbEn,es:fbEs}}:{});
const T=(es,en)=>({es,en});
module.exports={w,o,a,m,T};
