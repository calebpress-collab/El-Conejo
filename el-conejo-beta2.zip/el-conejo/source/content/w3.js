const {w,o,a,m,T}=require('./lib.js');
const forest={sky:'forest',ground:'forest',back:'pines'};
module.exports={
id:3,key:'forest',color:'#3E7A47',
name:T('Bosque y Colinas','Forest and Hills'),
cast:['owl','fox','squirrel','frog','goat','hedgehog'],
intro:{en:'Beyond the town, the road disappears into the forest. You will need directions, a warm fire and a little courage. Listen closely: in the woods, one wrong turn ends in mud.',
       es:'Después del pueblo, el camino se pierde en el bosque. Necesitarás indicaciones, un fuego caliente y un poco de valor. Escucha bien: en el bosque, un giro equivocado termina en el lodo.'},
outro:{en:'From the mountain pass you can see the city lights. Abuela\'s festival is down there, waiting for you.',
       es:'Desde el paso de la montaña se ven las luces de la ciudad. La fiesta de la Abuela está allá abajo, esperándote.'},
levels:[

/* 3-1 the forest edge */
{id:'w3l1',diff:'easy',npc:'owl',
 title:T('La orilla del bosque','The Edge of the Forest'),theme:{en:'Where are you going?',es:'¿Adónde vas?'},
 can:{en:'say where you are going and understand a warning.',es:'decir adónde vas y entender un aviso.'},
 note:{en:'<b>Voy a</b> + place means "I\'m going to". <b>A + el</b> joins into <b>al</b>: <b>voy al bosque</b>, but <b>voy a la ciudad</b>. Broken things are a state, so they take <b>estar</b>: <b>está roto</b>.',
       es:'En inglés, ir a un lugar es <b>I\'m going to</b> + lugar: <b>I\'m going to the city</b>. Pero a casa es sin "to": <b>I\'m going home</b>.'},
 lesson:[w('¿adónde vas?','where are you going?',['a donde vas','adonde vas'],['where are you headed']),w('voy a','I\'m going to',['yo voy a'],['i am going to']),
   w('la ciudad','the city',['ciudad'],['city']),w('lejos','far',['muy lejos'],['far away']),w('cerca','near',['cerquita'],['close','nearby']),
   w('el puente','the bridge',['puente'],['bridge']),w('está roto','it\'s broken',['esta roto'],['it is broken']),w('el bosque','the forest',['bosque'],['forest','the woods']),
   w('la casa','home',['casa','mi casa'],['house','the house'])],
 scene:{w:900,...forest,start:[-40,280],
  items:[['path','M-30 280C200 280 330 280 420 278S500 250 530 220',22],['path','M420 278C480 276 560 262 596 252',16],
   ['burrow',90,262],['tree',230,236,.9],['sign',360,250,T('CASA','HOME'),-1,'homesign'],
   ['trail',506,214,'trail'],['brokenBridge',655,'bridge'],['pine',780,236,1.1],['pine',840,250,1],
   ['scatter',31,140,330,214,296,10],['scatter',32,720,900,262,298,6]],
  finale:{walk:[[536,224]],src:[600,186]}},
 outro:'¡Ten cuidado|Be careful / en el bosque!|in the forest!',
 nodes:[
  {t:'say',b:[230,282],n:[330,176],line:'¿Adónde vas,|Where are you going, / conejo?|bunny?',opts:[
    o('Voy a la ciudad.','I\'m going to the city.',1),
    o('Vengo de la ciudad.','I come from the city.',0,'"Vengo de" means "I come from". You haven\'t been there yet!','"I come from" es "vengo de". ¡Todavía no has ido!'),
    o('Soy la ciudad.','I am the city.',0,'"Soy" means "I am". You\'re a bunny, not a city!','"I am" es "soy". ¡Eres un conejo, no una ciudad!')]},
  {t:'listen',b:[230,282],n:[330,176],line:'La ciudad|The city / está muy lejos,|is very far, / detrás de las colinas.|behind the hills.',opts:[
    m('The city is very far, behind the hills.','La ciudad está muy lejos, detrás de las colinas.',1),
    m('The city is very near, next to the hills.','La ciudad está muy cerca, al lado de las colinas.',0,'"Lejos" is far. "Cerca" would be near.','"Far" es lejos. "Near" sería cerca.'),
    m('The forest is very far.','El bosque está muy lejos.',0,'He was talking about "la ciudad", the city.','Hablaba de "the city", la ciudad.')]},
  {t:'act',b:[430,284],n:[400,150],line:'El puente|The bridge / está roto.|is broken. / Ve por el bosque.|Go through the forest.',opts:[
    a('Back home','Volver a casa',{hot:'homesign',at:[360,298],walk:[[380,284]],fx:'look',fb:{en:'He gave you another way: "por el bosque", through the forest.',es:'Te dio otro camino: "through the forest", por el bosque.'}}),
    a('Into the forest','Por el bosque',{ok:1,hot:'trail',at:[530,298],walk:[[480,268],[518,236],[532,224]]}),
    a('Cross the bridge','Cruzar el puente',{hot:'bridge',at:[630,298],walk:[[540,270],[606,256]],fx:'fall',hit:'plank',fb:{en:'"Está roto" means it\'s broken. The plank gave way!',es:'"It\'s broken" significa que está roto. ¡La tabla se cayó!'}})]},
  {t:'type',b:[532,224],n:[620,170],line:'¡Bien!|Good! / El bosque es grande.|The forest is big.',
    prompt:{en:'Ask if the city is far.',es:'Pregunta si la ciudad está lejos.'},
    say:{es:'¿Está lejos la ciudad?',en:'Is the city far?'},
    ans:{es:['la ciudad esta lejos','esta lejos','esta muy lejos','la ciudad esta muy lejos','esta lejos la ciudad'],en:['is it far','is the city far away','is it far away','is the city very far']}},
  {t:'say',b:[532,224],n:[620,170],line:'Sí, está lejos.|Yes, it\'s far. / Toma una zanahoria|Take a carrot / para el camino.|for the road.',opts:[
    o('¡Gracias, Búho!','Thank you, Owl!',1),
    o('Está cerca.','It\'s near.',0,'He just said "está lejos", it\'s far.','Acaba de decir "it\'s far", está lejos.'),
    o('Voy a casa.','I\'m going home.',0,'You\'re going to the city, not home!','¡Vas a la ciudad, no a casa!')]}
 ]},

/* 3-2 the fork */
{id:'w3l2',diff:'easy',npc:'fox',
 title:T('La piedra grande','The Big Rock'),theme:{en:'Left, right, straight',es:'Izquierda, derecha, recto'},
 can:{en:'follow and give simple directions.',es:'seguir y dar indicaciones sencillas.'},
 note:{en:'Directions use commands: <b>gira</b> (turn), <b>sigue</b> (keep going). Turning is <b>a la izquierda</b> or <b>a la derecha</b>; straight ahead is <b>recto</b> or <b>todo recto</b>. Careful: <b>derecho</b> can also mean straight in Latin America.',
       es:'En inglés: <b>turn left</b>, <b>turn right</b>, <b>go straight</b> o <b>go straight ahead</b>. Ojo: <b>right</b> también significa "correcto".'},
 lesson:[w('izquierda','left',['a la izquierda'],['to the left']),w('derecha','right',['a la derecha'],['to the right']),w('recto','straight',['todo recto','derecho'],['straight ahead']),
   w('gira','turn',['dobla','gire'],[]),w('sigue','keep going',['siga','continua'],['go on','continue']),w('la piedra grande','the big rock',['piedra grande'],['big rock','the big stone']),
   w('¿por dónde?','which way?',['por donde','por donde es'],['which way is it']),w('el lodo','the mud',['lodo','el barro'],['mud']),w('las zarzas','the brambles',['zarzas'],['brambles','the thorns'])],
 scene:{w:900,...forest,start:[-40,282],
  items:[['tint',0,900,'#1F4A2A',.1],['path','M-30 282C150 282 300 282 440 280',22],['path','M440 280C470 270 520 236 566 212',16],['path','M440 280C520 281 580 281 620 280',18],['path','M440 280C480 288 520 294 548 296',14],
   ['pine',150,236,1.1],['pine',210,226,.9],['rock',454,250,1.4,'bigrock'],
   ['g','pathL',[['pine',538,208,.9],['pine',604,208,.95],['raw','<path d="M556 206Q572 184 588 206Z" fill="#1E3B24"/>']]],
   ['bramble',642,272,'bramble'],['mud',556,296,'mud'],['pine',760,240,1.1],['pine',830,232,1],
   ['scatter',33,0,400,214,298,12]],
  finale:{walk:[[574,208]],src:[620,190]}},
 outro:'¡Buen viaje,|Have a good trip, / conejo!|bunny!',
 nodes:[
  {t:'say',b:[230,282],n:[340,268],line:'¡Conejo!|Conejo! / ¿Adónde vas ahora?|Where are you going now?',opts:[
    o('Voy a la ciudad.','I\'m going to the city.',1),
    o('Voy a la izquierda.','I\'m going to the left.',0,'He asked where you\'re heading: the city.','Te preguntó adónde vas: a la ciudad.'),
    o('Soy un zorro.','I\'m a fox.',0,'He is the fox! You\'re the bunny.','¡Él es el zorro! Tú eres el conejo.')]},
  {t:'type',b:[230,282],n:[340,268],line:'¿La ciudad?|The city? / Hay tres caminos.|There are three paths.',
    prompt:{en:'Ask him which way it is.',es:'Pregúntale por dónde es.'},
    say:{es:'¿Por dónde es?',en:'Which way is it?'},
    ans:{es:['por donde','por donde es la ciudad','por donde voy','cual es el camino'],en:['which way','which way is the city','which way do i go','which path is it']}},
  {t:'listen',b:[230,282],n:[340,268],line:'En la piedra grande,|At the big rock, / gira a la izquierda.|turn left.',opts:[
    m('At the big rock, turn left.','En la piedra grande, gira a la izquierda.',1),
    m('At the big rock, turn right.','En la piedra grande, gira a la derecha.',0,'"Izquierda" is left. Right is "derecha".','"Left" es izquierda. "Right" es derecha.'),
    m('At the big tree, go straight.','En el árbol grande, sigue recto.',0,'He said "la piedra", the rock, and "gira", turn.','Dijo "the rock", la piedra, y "turn", gira.')]},
  {t:'act',b:[430,288],n:[380,258],line:'¡Recuerda!|Remember! / A la izquierda.|To the left. / No sigas recto.|Don\'t go straight.',opts:[
    a('Turn left','Girar a la izquierda',{ok:1,hot:'pathL',at:[584,246],walk:[[470,276],[520,240],[570,210]]}),
    a('Straight on','Seguir recto',{hot:'bramble',at:[650,298],walk:[[600,284]],fx:'bonk',fb:{en:'"No sigas recto": don\'t go straight. Those are brambles!',es:'"Don\'t go straight": no sigas recto. ¡Son zarzas!'}}),
    a('Turn right','Girar a la derecha',{hot:'mud',at:[500,300],walk:[[540,294]],fx:'splash',fb:{en:'"Izquierda" is left. Right is "derecha", and that way is all mud!',es:'"Left" es izquierda. "Right" es derecha, ¡y por ahí hay lodo!'}})]},
  {t:'say',b:[570,210],n:[512,262],line:'¡Eso es!|That\'s it! / Sigue recto|Keep going straight / hasta las colinas.|until the hills.',opts:[
    o('¡Gracias por la ayuda!','Thanks for the help!',1),
    o('Gira a la derecha.','Turn right.',0,'He is giving directions, not you.','Él da las indicaciones, no tú.'),
    o('¿Por dónde es?','Which way is it?',0,'He just told you: "sigue recto", keep going straight.','Te lo acaba de decir: "keep going straight", sigue recto.')]}
 ]},

/* 3-3 the clearing */
{id:'w3l3',diff:'medium',npc:'squirrel',
 title:T('El claro del bosque','The Clearing'),theme:{en:'Feelings with tener',es:'Sensaciones: I\'m cold, I\'m hungry'},
 can:{en:'say you are cold, hungry or sleepy, and say when it stops.',es:'decir que tienes frío, hambre o sueño, y cuándo se te pasa.'},
 note:{en:'For body feelings Spanish says "I have": <b>tengo frío</b> (I\'m cold), <b>tengo hambre</b> (I\'m hungry), <b>tengo sueño</b> (I\'m sleepy). <b>Estoy frío</b> would mean your body is cold to the touch! And it\'s <b>mucha hambre</b>, because hambre is feminine.',
       es:'En inglés, estas sensaciones van con <b>I am</b>, no con "have": <b>I\'m cold</b>, <b>I\'m hungry</b>, <b>I\'m sleepy</b>. Nunca "I have cold".'},
 lesson:[w('tengo frío','I\'m cold',['tengo mucho frio'],['i am cold']),w('tengo calor','I\'m hot',['tengo mucho calor'],['i am hot','i am warm']),w('tengo hambre','I\'m hungry',['tengo mucha hambre'],['i am hungry']),
   w('tengo sueño','I\'m sleepy',['tengo mucho sueno'],['i am sleepy','i am tired']),w('¿todavía?','still?',['todavia'],[]),w('ya no','not anymore',[],['no longer','not any more']),
   w('siéntate','sit down',['sientate'],['have a seat']),w('el fuego','the fire',['fuego','la fogata'],['fire','the campfire']),w('el tronco','the log',['tronco'],['log','the stump'])],
 scene:{w:900,...forest,start:[-40,284],
  items:[['raw','<path d="M380 0L330 300H760L700 0Z" fill="#FFF6C9" opacity=".25"/>'],['path','M-30 284C200 284 400 284 520 284',22],
   ['pine',120,236,1.1],['pine',190,226,.9],['g','stump',[['stump',466,258]]],['campfire',560,262,'fire'],['stream',640,655,40,80,'brook'],
   ['pine',760,238,1.1],['pine',830,228,.9],['scatter',35,0,360,214,298,12]],
  finale:{walk:[[524,288]],src:[500,246]}},
 outro:'¡Buenas noches,|Good night, / conejo!|bunny!',
 nodes:[
  {t:'say',b:[230,284],n:[340,268],line:'¡Conejo!|Conejo! / Tienes la nariz roja.|Your nose is red. / ¿Cómo estás?|How are you?',opts:{
    es:[{t:'Tengo frío.',ok:1},{t:'Soy frío.',fb:'Feeling cold uses "tener": tengo frío.'},{t:'Estoy frío.',fb:'"Estoy frío" means your body is cold to the touch. For feeling cold, say "tengo frío".'}],
    en:[{t:'I\'m cold.',ok:1},{t:'I have cold.',fb:'En inglés se dice "I\'m cold", no "I have cold".'},{t:'I am cool.',fb:'"I am cool" significa "soy genial". Para el frío: "I\'m cold".'}]}},
  {t:'type',b:[230,284],n:[340,268],line:'¡Pobrecito!|Poor thing! / ¿Y tienes hambre?|And are you hungry?',
    prompt:{en:'Say yes, you are very hungry.',es:'Di que sí, que tienes mucha hambre.'},
    say:{es:'Sí, tengo mucha hambre.',en:'Yes, I\'m very hungry.'},
    ans:{es:['si tengo hambre','tengo mucha hambre','tengo hambre','si mucha hambre'],en:['yes i am very hungry',"yes i'm hungry",'yes i am hungry',"i'm very hungry",'i am very hungry','yes very hungry']}},
  {t:'act',b:[390,288],n:[500,250],line:'Siéntate|Sit down / cerca del fuego.|near the fire. / ¡No en el agua!|Not in the water!',opts:[
    a('On the log','En el tronco',{hot:'stump',at:[466,298],walk:[[450,290]],fx:'look',fb:{en:'The log is far from the fire. She said "cerca del fuego", near the fire.',es:'El tronco está lejos del fuego. Dijo "near the fire", cerca del fuego.'}}),
    a('Near the fire','Cerca del fuego',{ok:1,hot:'fire',at:[560,298],walk:[[524,288]]}),
    a('By the water','Junto al agua',{hot:'brook',at:[650,298],walk:[[612,288]],fx:'splash',fb:{en:'"¡No en el agua!" Not in the water!',es:'"Not in the water!": ¡no en el agua!'}})]},
  {t:'listen',b:[524,288],n:[470,250],line:'Come una zanahoria.|Eat a carrot. / Después, duerme:|Then sleep: / tienes sueño.|you\'re sleepy.',opts:[
    m('Eat a carrot. Then sleep: you\'re sleepy.','Come una zanahoria. Después, duerme: tienes sueño.',1),
    m('Eat a carrot. Then go: you\'re late.','Come una zanahoria. Después, vete: llegas tarde.',0,'"Duerme" is sleep, and "tienes sueño" is you\'re sleepy.','"Sleep" es duerme, y "you\'re sleepy" es tienes sueño.'),
    m('Don\'t eat now: you\'re not hungry.','No comas ahora: no tienes hambre.',0,'She said "come", eat!','Dijo "eat", ¡come!')]},
  {t:'say',b:[524,288],n:[470,250],line:'¿Todavía|Are you still / tienes frío?|cold?',opts:{
    es:[{t:'No, ya no tengo frío.',ok:1},{t:'Sí, tengo calor.',fb:'"Tengo calor" means I\'m hot, so the answer would be no, not yes.'},{t:'No, ya no soy frío.',fb:'Cold feelings use "tener": ya no tengo frío.'}],
    en:[{t:'No, I\'m not cold anymore.',ok:1},{t:'Yes, I\'m hot.',fb:'"I\'m hot" es tengo calor: entonces la respuesta sería no, no sí.'},{t:'No, I don\'t have cold anymore.',fb:'Se dice "I\'m not cold anymore", nunca "have cold".'}]}}
 ]},

/* 3-4 stepping stones */
{id:'w3l4',diff:'medium',npc:'frog',
 title:T('Las piedras del río','The Stepping Stones'),theme:{en:'First, then, after that',es:'Primero, después, luego'},
 can:{en:'follow steps in order and describe how something is.',es:'seguir pasos en orden y describir cómo está algo.'},
 note:{en:'Sequence words: <b>primero</b> (first), <b>después</b> (then/after), <b>luego</b> (later, next). <b>Agua</b> is feminine but takes <b>el</b> because it starts with a stressed a: <b>el agua está fría</b>.',
       es:'En inglés: <b>first</b>, <b>then</b>, <b>after that</b>, <b>finally</b>. Y para el estado de algo se usa <b>is</b>: <b>the water is cold</b>.'},
 lesson:[w('cruzar','to cross',['cruza'],['cross']),w('el río','the river',['rio'],['river']),w('primero','first',['primeramente'],['first of all']),w('después','then',['despues','luego'],['after that','afterwards']),
   w('salta','jump',['salte','brinca'],['hop']),w('la piedra mediana','the medium stone',['piedra mediana'],['medium stone','the middle-sized stone']),w('pequeña','small',['chiquita'],['little']),
   w('la orilla','the bank',['orilla'],['bank','the shore','the riverbank']),w('el agua está fría','the water is cold',['el agua esta helada','esta fria'],["the water's cold"])],
 scene:{w:950,...forest,start:[-40,282],
  items:[['path','M-30 282C200 282 380 282 490 282',22],['path','M690 276C760 276 860 276 980 276',22],
   ['pine',100,236,1.1],['pine',300,226,.9],['stream',590,590,70,180,'river'],
   ['stones',[[535,272,20,'sBig'],[547,294,11,'sSmall1'],[598,282,16,'sMed'],[612,256,10,'sSmall2'],[650,272,14]]],
   ['reeds',486,262],['reeds',700,256],['patch',820,232,930,[232,252],{0:{836:'c34'}}],['pine',780,230,.9],
   ['scatter',34,0,460,214,298,14]],
  finale:{walk:[[796,280]],pull:'c34',src:[836,214]}},
 outro:'¡Croac!|Ribbit! / ¡Saltas muy bien!|You jump really well!',
 nodes:[
  {t:'say',b:[240,282],n:[360,272],line:'¡Hola otra vez!|Hello again! / ¿Quieres cruzar|Do you want to cross / el río?|the river?',opts:[
    o('Sí, quiero cruzar.','Yes, I want to cross.',1),
    o('Sí, soy el río.','Yes, I am the river.',0,'"Soy" means I am. Say what you want: "quiero cruzar".','"I am" es soy. Di lo que quieres: "I want to cross".'),
    o('No, tengo calor.','No, I\'m hot.',0,'You need to cross to reach the city. Say yes!','Tienes que cruzar para llegar a la ciudad. ¡Di que sí!')]},
  {t:'listen',b:[240,282],n:[360,272],line:'Primero,|First, / salta a la piedra grande.|jump to the big stone. / Después,|Then, / a la mediana.|to the medium one.',opts:[
    m('First, jump to the big stone. Then, to the medium one.','Primero, salta a la piedra grande. Después, a la mediana.',1),
    m('First, jump to the small stone. Then, to the big one.','Primero, salta a la piedra pequeña. Después, a la grande.',0,'"Primero" goes with "la piedra grande", the big stone.','"First" va con "the big stone", la piedra grande.'),
    m('First, swim. Then, jump.','Primero, nada. Después, salta.',0,'Nobody is swimming! Listen for "salta", jump.','¡Nadie nada! Escucha "jump", salta.')]},
  {t:'act',b:[470,284],n:[730,272],line:'Primero,|First, / la piedra grande.|the big stone.',opts:[
    a('Big stone','Piedra grande',{ok:1,hot:'sBig',at:[520,300],walk:[[535,270]]}),
    a('Small stone','Piedra pequeña',{hot:'sSmall1',at:[580,300],walk:[[547,292]],fx:'splash',fb:{en:'That one is "pequeña", small. First comes "la grande".',es:'Esa es "small", pequeña. Primero va "the big one", la grande.'}})]},
  {t:'act',b:[535,270],n:[730,274],line:'¡Bien!|Good! / Después,|Then, / la mediana.|the medium one. / ¡No la pequeña!|Not the small one!',opts:[
    a('Medium stone','Piedra mediana',{ok:1,hot:'sMed',at:[598,300],walk:[[598,280]]}),
    a('Small stone','Piedra pequeña',{hot:'sSmall2',at:[612,246],walk:[[612,254]],fx:'splash',fb:{en:'"¡No la pequeña!" Not the small one!',es:'"Not the small one!": ¡no la pequeña!'}})]},
  {t:'type',b:[712,278],via:[[650,270]],n:[770,276],line:'¡Lo lograste!|You did it! / ¿Cómo está el agua?|How is the water?',
    prompt:{en:'Say the water is cold.',es:'Di que el agua está fría.'},
    say:{es:'El agua está fría.',en:'The water is cold.'},
    ans:{es:['esta fria','el agua esta muy fria','esta muy fria','el agua esta helada','esta helada'],en:["it's cold",'it is cold','the water is very cold',"it's very cold","the water's cold"]}}
 ]},

/* 3-5 the cave */
{id:'w3l5',diff:'medium',npc:'owl',
 title:T('La cueva','The Cave'),theme:{en:'What you need',es:'Lo que necesitas'},
 can:{en:'say what you need and ask permission to go in.',es:'decir lo que necesitas y pedir permiso para entrar.'},
 note:{en:'<b>Necesitar</b> + thing: <b>necesitas la linterna</b> (you need the lantern). In a list of things you don\'t want, Spanish uses <b>ni</b>: <b>no la cuerda ni el palo</b> (not the rope or the stick).',
       es:'En inglés: <b>you need</b> + cosa: <b>you need the lantern</b>. Para "ni… ni" se usa <b>or</b> después de <b>not</b>: <b>not the rope or the stick</b>.'},
 lesson:[w('la cueva','the cave',['cueva'],['cave']),w('oscura','dark',['oscuro'],[]),w('necesitas','you need',['necesita'],['you need it']),w('la linterna','the lantern',['linterna'],['lantern','the flashlight']),
   w('la cuerda','the rope',['cuerda'],['rope']),w('el palo','the stick',['palo'],['stick']),w('dentro','inside',['adentro'],['in there']),w('despacio','slowly',[],['slow']),w('con cuidado','carefully',['cuidado'],['careful','with care'])],
 scene:{w:900,...forest,start:[-40,284],
  items:[['path','M-30 284C200 284 400 284 560 280S660 262 690 252',22],['pine',100,236,1.1],['pine',190,226,.9],
   ['lantern',392,276,'lantern'],['rope',486,280,'rope'],['stick',578,278,'stick'],['cave',690,250,'cave'],['pine',800,238,1.1],['pine',860,250,.9],
   ['scatter',36,0,360,214,298,12]],
  finale:{walk:[[690,252]],src:[690,216]}},
 outro:'¡Muy bien,|Very good, / valiente!|brave one!',
 nodes:[
  {t:'say',b:[240,286],n:[330,170],line:'¡Hola de nuevo!|Hello again! / Esta es la cueva|This is the cave / de las zanahorias.|of the carrots.',opts:[
    o('¿Puedo entrar?','Can I go in?',1),
    o('Tengo calor.','I\'m hot.',0,'He is telling you about the cave. Ask if you can go in.','Te habla de la cueva. Pregunta si puedes entrar.'),
    o('Es una zanahoria.','It\'s a carrot.',0,'It\'s a cave full of carrots, not a carrot!','¡Es una cueva llena de zanahorias, no una zanahoria!')]},
  {t:'listen',b:[240,286],n:[330,170],line:'Sí, pero|Yes, but / está muy oscura.|it\'s very dark. / Necesitas luz.|You need light.',opts:[
    m('Yes, but it\'s very dark. You need light.','Sí, pero está muy oscura. Necesitas luz.',1),
    m('No, it\'s very dark. Go home.','No, está muy oscura. Vete a casa.',0,'He said "sí", yes, but you need light.','Dijo "yes", sí, pero necesitas luz.'),
    m('Yes, it\'s very sunny inside.','Sí, hay mucho sol dentro.',0,'"Oscura" means dark.','"Dark" significa oscura.')]},
  {t:'act',b:[330,288],n:[330,170],line:'Toma la linterna.|Take the lantern. / No la cuerda|Not the rope / ni el palo.|or the stick.',opts:[
    a('The lantern','La linterna',{ok:1,hot:'lantern',at:[392,298],walk:[[372,290]],hide:'lantern'}),
    a('The rope','La cuerda',{hot:'rope',at:[486,298],walk:[[466,290]],fx:'look',fb:{en:'"No la cuerda": not the rope. Take "la linterna", the lantern.',es:'"Not the rope": no la cuerda. Toma "the lantern", la linterna.'}}),
    a('The stick','El palo',{hot:'stick',at:[578,298],walk:[[556,290]],fx:'look',fb:{en:'"Ni el palo": not the stick either. Take the lantern.',es:'"Or the stick": tampoco el palo. Toma la linterna.'}})]},
  {t:'type',b:[400,288],n:[460,160],line:'¡Muy bien!|Very good! / Ahora tienes luz.|Now you have light.',
    prompt:{en:'Ask him if there are carrots inside.',es:'Pregúntale si hay zanahorias dentro.'},
    say:{es:'¿Hay zanahorias dentro?',en:'Are there carrots inside?'},
    ans:{es:['hay zanahorias adentro','hay zanahorias en la cueva','hay zanahorias dentro de la cueva','hay zanahorias ahi'],en:['are there any carrots inside','are there carrots in the cave','are there carrots in there','are there any carrots in there']}},
  {t:'act',b:[480,288],n:[460,160],line:'Sí, al fondo.|Yes, at the back. / Entra despacio|Go in slowly / y con cuidado.|and carefully.',opts:[
    a('Wait outside','Esperar fuera',{hot:'stick',at:[420,298],walk:[[430,290]],fx:'sleep',fb:{en:'He said "entra", go in, but slowly.',es:'Dijo "go in", entra, pero despacio.'}}),
    a('Run inside','Entrar corriendo',{at:[600,226],walk:[[620,272]],fx:'bonk',fb:{en:'"Despacio y con cuidado": slowly and carefully! You bumped the rock.',es:'"Slowly and carefully": ¡despacio y con cuidado! Chocaste con la roca.'}}),
    a('Walk in slowly','Entrar despacio',{ok:1,hot:'cave',at:[690,298],walk:[[600,282],[660,268],[690,254]]})]}
 ]},

/* 3-6 the hill */
{id:'w3l6',diff:'hard',npc:'goat',
 title:T('La colina','The Hill'),theme:{en:'Why? Because. Today and tomorrow',es:'¿Por qué? Porque. Hoy y mañana'},
 can:{en:'give reasons and understand plans for today and tomorrow.',es:'dar razones y entender planes para hoy y mañana.'},
 note:{en:'<b>¿Por qué?</b> (two words, accent) asks why; <b>porque</b> (one word) answers because. To talk about the future, use <b>ir a</b> + verb: <b>va a llover</b> (it\'s going to rain).',
       es:'En inglés, <b>why?</b> pregunta y <b>because</b> responde. Para el futuro cercano: <b>going to</b> + verbo: <b>it\'s going to rain</b>.'},
 lesson:[w('¿cómo estás?','how are you?',['como estas','que tal'],['how are you doing']),w('estoy cansado','I\'m tired',['estoy cansada'],['i am tired']),
   w('¿por qué?','why?',['por que'],[]),w('porque','because',[],['cause']),w('yo como','I eat',['como'],[]),w('hoy','today',[],[]),w('mañana','tomorrow',['manana'],[]),
   w('va a llover','it\'s going to rain',['llovera'],['it will rain','it is going to rain']),w('arriba','at the top',['en la cima'],['up there']),w('sube','climb',['suba'],['go up'])],
 scene:{w:1200,sky:'cool',ground:'meadow',back:'hills',sun:980,start:[-40,282],
  items:[['bigHill',380],['path','M-30 282C200 282 340 280 440 272',22],['path','M440 272C560 252 660 232 800 216S940 202 1000 200',12],
   ['reeds',150,272],['sign',470,262,T('ABAJO','DOWN'),-1,'downsign'],['g','tent',[['tent',630,239,-8.5]]],
   ['g','summitPath',[['raw','<path d="M680 230L940 200" stroke="transparent" stroke-width="30"/>']]],
   ['bedRow',1036,1150,202,[1052,1080,1108,1136],{1052:'c36'}],['bedRow',1036,1150,224,[1054,1082,1110,1138]],['flag',1170,190],
   ['scatter',37,0,380,200,272,16]],
  finale:{walk:[[1006,201]],pull:'c36',src:[1052,174]}},
 outro:'¡Las zanahorias|The carrots / son tuyas!|are yours!',
 nodes:[
  {t:'say',b:[150,282],n:[262,280],line:'¡Hola!|Hi! / Pareces cansado.|You look tired. / ¿Cómo estás?|How are you?',opts:{
    es:[{t:'Estoy cansado y tengo hambre.',ok:1},{t:'Soy cansado y estoy hambre.',fb:'Use "estoy" for how you feel right now, and "tengo hambre" for hunger.'},{t:'Estoy embarazado.',fb:'Careful! "Embarazado" means pregnant, not embarrassed.'}],
    en:[{t:'I\'m tired and I\'m hungry.',ok:1},{t:'I am tired and I have hunger.',fb:'En inglés no se dice "have hunger". Se dice "I\'m hungry".'},{t:'I have tired and hungry.',fb:'Para cómo te sientes, usa "I am" (estoy), no "I have".'}]}},
  {t:'type',b:[150,282],n:[262,280],line:'Para subir,|To climb up, / responde:|answer: / ¿Qué comes|What do you eat / todos los días?|every day?',
    prompt:{en:'Answer the goat.',es:'Responde a la cabra.'},
    say:{es:'Como zanahorias.',en:'I eat carrots.'},
    ans:{es:['yo como zanahorias','zanahorias','como zanahorias todos los dias','yo como zanahorias todos los dias'],en:['carrots','i eat carrots every day','i eat carrots everyday']}},
  {t:'say',b:[150,282],n:[262,280],line:'¿Por qué|Why / quieres subir|do you want to climb / la colina?|the hill?',opts:{
    es:[{t:'Porque tengo hambre.',ok:1},{t:'¿Por qué tengo hambre?',fb:'That\'s a question. "Porque" (one word, no accent) means "because".'},{t:'Porque soy hambre.',fb:'"Soy hambre" means "I am hunger". Hunger uses "tengo".'}],
    en:[{t:'Because I\'m hungry.',ok:1},{t:'Why I\'m hungry?',fb:'Eso es una pregunta. "Because" significa "porque".'},{t:'Because I have hungry.',fb:'En inglés se dice "I\'m hungry", no "I have hungry".'}]}},
  {t:'act',b:[560,250],via:[[400,280],[470,268]],n:[500,292],line:'Las zanahorias|The carrots / están arriba,|are at the top, / pero mañana|but tomorrow / va a llover.|it\'s going to rain. / Sube hoy.|Climb today.',opts:[
    a('Go back down','Bajar la colina',{hot:'downsign',at:[470,298],walk:[[480,266]],fx:'look',fb:{en:'"Arriba" means at the top. The carrots are up there!',es:'"At the top" significa arriba. ¡Las zanahorias están allá!'}}),
    a('Wait for tomorrow','Esperar a mañana',{hot:'tent',at:[630,270],walk:[[616,240]],fx:'sleep',fb:{en:'"Mañana va a llover": tomorrow it\'s going to rain. She said "hoy", today.',es:'"Tomorrow it\'s going to rain": mañana va a llover. Dijo "today", hoy.'}}),
    a('Climb today','Subir hoy',{ok:1,hot:'summitPath',at:[760,230],walk:[[680,234],[800,217],[930,204]]})]},
  {t:'type',b:[930,204],n:[860,212],line:'¡Muy bien!|Very good! / ¿Cómo te sientes|How do you feel / ahora?|now?',
    prompt:{en:'Tell her you are happy.',es:'Dile que estás feliz.'},
    say:{es:'Estoy feliz.',en:'I\'m happy.'},
    ans:{es:['estoy muy feliz','estoy contento','estoy contenta','me siento feliz','feliz'],en:['i am very happy','i am so happy','i feel happy','happy','i am happy']}}
 ]},

/* 3-7 the windmill */
{id:'w3l7',diff:'medium',npc:'hedgehog',
 title:T('El molino','The Windmill'),theme:{en:'Comparing: more than, the most',es:'Comparar: más que, el más'},
 can:{en:'compare two things and pick the biggest, longest or shortest.',es:'comparar dos cosas y elegir la más grande, larga o corta.'},
 note:{en:'Compare with <b>más</b> + adjective + <b>que</b>: <b>más rápido que la tortuga</b>. For "the most", add the article: <b>el camino más corto</b> (the shortest path). Never use <b>de</b> after más in a comparison of two things.',
       es:'En inglés, las palabras cortas suman <b>-er</b> y <b>-est</b>: <b>faster than</b>, <b>the shortest</b>. Las largas usan <b>more</b> y <b>the most</b>: <b>more beautiful</b>.'},
 lesson:[w('más rápido que','faster than',['mas rapido que'],['quicker than']),w('lento','slow',['lenta'],[]),w('largo','long',['larga'],[]),w('corto','short',['corta'],[]),
   w('el más corto','the shortest',['el mas corto'],['the shortest one']),w('alto','tall',['alta'],['high']),w('el molino','the windmill',['molino'],['windmill','the mill']),
   w('¿cuál?','which?',['cual'],['which one']),w('mucho más','much more',['mucho mas'],['a lot more'])],
 scene:{w:1000,sky:'day',ground:'meadow',back:'hills',sun:150,start:[-40,284],
  items:[['path','M-30 284C200 284 360 284 440 282',22],
   ['g','pathR',[['path','M440 282C470 252 520 226 600 220S740 224 790 232',12],['flowerbed',520,238,50,'#D84A3A']]],
   ['g','pathY',[['path','M440 282C520 268 600 262 680 256S760 246 790 238',12],['flowerbed',560,266,50,'#F2C230']]],
   ['g','pathB',[['path','M440 282C560 292 680 292 790 246',12],['flowerbed',540,300,50,'#3F7FBF']]],
   ['tree',160,238,1],['windmill',810,228,'mill'],['bed',870,236,980,264],['bedRow',872,978,254,[888,920,952],{920:'c37'}],
   ['scatter',37,0,400,214,298,14]],
  finale:{walk:[[860,262]],pull:'c37',src:[920,232]}},
 outro:'¡Eres muy rápido!|You\'re very fast!',
 nodes:[
  {t:'say',b:[220,286],n:[340,270],line:'¡Conejo!|Conejo! / ¿Eres más rápido|Are you faster / que la tortuga?|than the turtle?',opts:[
    o('Sí, soy más rápido que la tortuga.','Yes, I\'m faster than the turtle.',1),
    o('Sí, soy más lento que la tortuga.','Yes, I\'m slower than the turtle.',0,'"Lento" means slow. A bunny is faster!','"Slow" es lento. ¡Un conejo es más rápido!'),
    o('Sí, soy más rápido de la tortuga.','Yes, I\'m faster of the turtle.',0,'Comparisons use "que", not "de": más rápido que.','Para comparar se usa "que", no "de": más rápido que.')]},
  {t:'listen',b:[220,286],n:[340,270],line:'El molino es|The windmill is / más alto que los árboles.|taller than the trees. / Allí hay zanahorias.|There are carrots there.',opts:[
    m('The windmill is taller than the trees. There are carrots there.','El molino es más alto que los árboles. Allí hay zanahorias.',1),
    m('The trees are taller than the windmill.','Los árboles son más altos que el molino.',0,'"El molino es más alto": the windmill is the taller one.','"The windmill is taller": el molino es más alto.'),
    m('The windmill is small. There are no carrots.','El molino es pequeño. No hay zanahorias.',0,'He said "más alto", taller, and "hay zanahorias".','Dijo "taller", más alto, y "there are carrots".')]},
  {t:'type',b:[220,286],n:[340,270],line:'Hay tres caminos|There are three paths / al molino.|to the windmill.',
    prompt:{en:'Ask which path is the shortest.',es:'Pregunta cuál es el camino más corto.'},
    say:{es:'¿Cuál es el camino más corto?',en:'Which is the shortest path?'},
    ans:{es:['cual es el mas corto','cual camino es el mas corto','cual es el camino mas corto por favor'],en:['which path is the shortest','which one is the shortest','which is the shortest','which is the shortest way','which way is the shortest']}},
  {t:'act',b:[420,288],n:[350,272],line:'El rojo es largo.|The red one is long. / El amarillo es|The yellow one is / más corto.|shorter. / El azul es|The blue one is / el más corto.|the shortest.',opts:[
    a('Red flowers','Flores rojas',{hot:'pathR',at:[480,300],walk:[[470,262],[520,240]],fx:'sleep',fb:{en:'"El rojo es largo": the red one is long. You\'re worn out!',es:'"The red one is long": el rojo es largo. ¡Estás agotado!'}}),
    a('Yellow flowers','Flores amarillas',{hot:'pathY',at:[570,300],walk:[[520,272],[570,270]],fx:'look',fb:{en:'Yellow is "más corto", shorter, but blue is "el más corto", the shortest.',es:'El amarillo es "shorter", más corto, pero el azul es "the shortest", el más corto.'}}),
    a('Blue flowers','Flores azules',{ok:1,hot:'pathB',at:[660,300],walk:[[520,290],[660,292],[760,262],[790,250]]})]},
  {t:'say',b:[790,250],n:[700,276],line:'¡Qué rápido!|How fast! / ¿El molino es|Is the windmill / más grande|bigger / que tu casa?|than your house?',opts:[
    o('Sí, es mucho más grande.','Yes, it\'s much bigger.',1),
    o('Sí, es más pequeño.','Yes, it\'s smaller.',0,'Look at it! The windmill is huge, not "más pequeño".','¡Míralo! El molino es enorme, no "smaller".'),
    o('Sí, es más grande de mi casa.','Yes, it\'s bigger of my house.',0,'Comparisons use "que": más grande que mi casa.','Para comparar se usa "que": más grande que mi casa.')]}
 ]},

/* 3-8 BOSS: the mountain pass */
{id:'w3l8',diff:'hard',npc:'owl',
 title:T('El paso de la montaña','The Mountain Pass'),theme:{en:'Everything from the forest and hills',es:'Todo lo del bosque y las colinas'},
 can:{en:'explain how you feel and why, follow two-step directions and say what you have.',es:'explicar cómo te sientes y por qué, seguir indicaciones de dos pasos y decir lo que tienes.'},
 note:{en:'You combined <b>estar</b> + feeling, <b>porque</b>, comparisons, <b>primero/después</b> and directions. That\'s enough Spanish to find your way almost anywhere.',
       es:'Combinaste <b>I\'m</b> + estado, <b>because</b>, comparaciones, <b>first/then</b> e indicaciones. Con eso puedes orientarte casi en cualquier lugar.'},
 lesson:[w('la montaña','the mountain',['montana'],['mountain']),w('el paso','the pass',['paso'],['pass','the mountain pass']),w('al otro lado','on the other side',['del otro lado'],['across']),
   w('el valle','the valley',['valle'],['valley']),w('tengo una bufanda','I have a scarf',['tengo bufanda'],['i have got a scarf']),w('hasta pronto','see you soon',['nos vemos pronto'],['see you later'])],
 scene:{w:1100,sky:'cool',ground:'meadow',back:'mountains',sun:180,start:[-40,282],
  items:[['cityFar',900,1100],['path','M-30 282C200 282 380 278 450 262S500 250 512 248',20],['stream',560,566,50,110,'creek'],
   ['footbridge',560,248,104,'smallbridge'],['log',504,624,294,'log'],
   ['path','M612 248C640 250 660 256 680 262',16],['path','M680 262C700 242 730 216 768 196',14],['path','M680 262C730 282 800 294 880 294S1000 290 1130 288',18],
   ['rock',780,262,1.3,'wall'],['g','cliff',[['rock',800,196,.8],['raw','<path d="M760 186L790 150L830 186Z" fill="#F3F5F7" stroke="#25311F" stroke-width="1.4"/>']]],
   ['pine',120,240,1],['pine',200,230,.85],['pine',380,236,.9],['scatter',38,0,340,214,298,12]],
  finale:{walk:[[880,292]],src:[820,200]}},
 outro:'¡La Abuela|Abuela / te espera!|is waiting for you!',
 nodes:[
  {t:'say',b:[220,284],n:[320,170],line:'¡Llegaste al paso!|You reached the pass! / ¿Cómo estás?|How are you?',opts:{
    es:[{t:'Estoy cansado, pero feliz.',ok:1},{t:'Soy cansado, pero feliz.',fb:'How you feel right now uses "estar": estoy cansado.'},{t:'Tengo cansado.',fb:'Tired takes "estar": estoy cansado. "Tengo" is for hambre, frío, sueño.'}],
    en:[{t:'I\'m tired, but happy.',ok:1},{t:'I have tired, but happy.',fb:'Se dice "I\'m tired", nunca "I have tired".'},{t:'I\'m tiring, but happy.',fb:'"Tiring" significa que cansa a otros. Tú estás "tired".'}]}},
  {t:'type',b:[220,284],n:[320,170],line:'¿Por qué|Why / estás cansado?|are you tired?',
    prompt:{en:'Say: because the mountain is very tall.',es:'Di: porque la montaña es muy alta.'},
    say:{es:'Porque la montaña es muy alta.',en:'Because the mountain is very tall.'},
    ans:{es:['porque la montana es alta','la montana es muy alta','porque la montana es muy grande'],en:['because the mountain is tall','because the mountain is very high','because the mountain is so tall','the mountain is very tall']}},
  {t:'listen',b:[220,284],n:[320,170],line:'Mira:|Look: / la ciudad está|the city is / al otro lado del valle.|on the other side of the valley.',opts:[
    m('Look: the city is on the other side of the valley.','Mira: la ciudad está al otro lado del valle.',1),
    m('Look: the city is inside the mountain.','Mira: la ciudad está dentro de la montaña.',0,'"Al otro lado" is on the other side.','"On the other side" es al otro lado.'),
    m('Look: the valley is behind you.','Mira: el valle está detrás de ti.',0,'He was pointing out "la ciudad", the city.','Señalaba "the city", la ciudad.')]},
  {t:'act',b:[456,264],n:[400,170],line:'Primero,|First, / cruza el puente pequeño.|cross the little bridge.',opts:[
    a('Turn back','Volver',{at:[380,298],walk:[[390,282]],fx:'look',fb:{en:'"Cruza" means cross. Keep going over the little bridge.',es:'"Cross" significa cruza. Sigue por el puente pequeño.'}}),
    a('The little bridge','El puente pequeño',{ok:1,hot:'smallbridge',at:[560,232],walk:[[512,250],[560,242],[612,248]]}),
    a('The log','El tronco',{hot:'log',at:[564,300],walk:[[508,292],[548,292]],fx:'splash',fb:{en:'That\'s "el tronco", the log, and it\'s slippery. He said "el puente pequeño".',es:'Ese es el tronco, "the log", y resbala. Dijo "the little bridge", el puente pequeño.'}})]},
  {t:'act',b:[650,256],n:[600,160],line:'Después,|Then, / gira a la derecha,|turn right, / hacia la ciudad.|toward the city.',opts:[
    a('Turn left','A la izquierda',{hot:'cliff',at:[740,210],walk:[[700,236],[732,214]],fx:'bonk',fb:{en:'Left goes up to the snow. He said "a la derecha", right.',es:'La izquierda sube a la nieve. Dijo "right", a la derecha.'}}),
    a('Straight on','Recto',{hot:'wall',at:[790,262],walk:[[730,264]],fx:'bonk',fb:{en:'There\'s a rock wall straight ahead. He said "gira a la derecha".',es:'Recto hay una roca. Dijo "turn right", gira a la derecha.'}}),
    a('Turn right','A la derecha',{ok:1,at:[800,300],walk:[[700,274],[780,292]]})]},
  {t:'type',b:[780,292],n:[720,190],line:'Esta noche|Tonight / hace frío.|it\'s cold. / ¿Qué tienes?|What do you have?',
    prompt:{en:'Say you have a scarf.',es:'Di que tienes una bufanda.'},
    say:{es:'Tengo una bufanda.',en:'I have a scarf.'},
    ans:{es:['tengo una bufanda azul','yo tengo una bufanda','una bufanda','tengo mi bufanda'],en:['i have a blue scarf',"i've got a scarf",'a scarf','i have my scarf']}},
  {t:'say',b:[780,292],n:[720,190],line:'¡Muy bien!|Very good! / La Abuela te espera.|Abuela is waiting for you.',opts:[
    o('¡Gracias, Búho! ¡Hasta pronto!','Thank you, Owl! See you soon!',1),
    o('¡Bienvenido!','Welcome!',0,'You are the one leaving. Say goodbye: "¡hasta pronto!".','Tú eres el que se va. Despídete: "see you soon!".'),
    o('Tengo sueño.','I\'m sleepy.',0,'He said goodbye. Thank him and say "¡hasta pronto!".','Se despidió. Dale las gracias y di "see you soon!".')]}
 ]}
]};
