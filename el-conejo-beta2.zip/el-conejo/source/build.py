import json,subprocess,shutil,os,sys
os.chdir(os.path.dirname(os.path.abspath(__file__)))
src=lambda f:open('src/'+f,encoding='utf-8').read()
js=''.join(src(f)+'\n' for f in ['core.js','art.js','art2.js','art3.js','scene.js','play.js','screens.js'])
html=src('head.html')+'<style>\n'+src('style.css')+'\n</style>\n<div id="app"></div>\n<script>\n'+js+'</script>\n'
os.makedirs('dist/content',exist_ok=True)
open('dist/index.html','w',encoding='utf-8').write(html)
# content is authored as JS (content/wN.js exports one world) and written out as JSON
for n in [1,2,3,4]:
    f=f'content/w{n}.js'
    if not os.path.exists(f):continue
    out=subprocess.run(['node','-e',f"process.stdout.write(JSON.stringify(require('./{f}')))"],capture_output=True,text=True)
    if out.returncode:print(out.stderr);sys.exit(1)
    open(f'dist/content/w{n}.json','w',encoding='utf-8').write(out.stdout)
print('built',len(html))
