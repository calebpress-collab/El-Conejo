/* ============ PLAY ============ */
let play=null;
const BUNNY_SPEED=150;
function nodeOpts(n){
  if(!n.opts)return [];
  if(n.t==='listen')return n.opts.map(o=>({...o,text:o[nat()],fb:o.fb&&o.fb[nat()]}));
  if(Array.isArray(n.opts)){
    return n.t==='act'
      ? n.opts.map(o=>({...o,text:o[nat()],fb:o.fb&&o.fb[nat()],lab:o.lab[nat()]}))
      : n.opts.map(o=>({text:o[tgt()],gloss:o[nat()],ok:!!o.ok,fb:o.fb&&o.fb[nat()]}));
  }
  return n.opts[tgt()].map(o=>({text:o.t,gloss:'',ok:!!o.ok,fb:o.fb}));
}
const words=s=>s.trim().split(/\s+/).length;
function parTime(l){
  let s=0;
  l.nodes.forEach(n=>{
    s+=6+0.5*words(parseLine(n.line).map(c=>c[tgt()]).join(' '));
    if(n.t==='type')s+=14;
    else s+=0.35*nodeOpts(n).reduce((a,o)=>a+words(o.text),0);
  });
  return Math.round(s*1.6);
}
function wait(ms){const id=screenId;return new Promise(r=>setTimeout(()=>{if(id===screenId)r();},ms));}

/* --- characters --- */
function makeEnt(el){return {el,x:0,y:0};}
function place(E,x,y){E.x=x;E.y=y;E.el.style.transition='none';E.el.style.transform=`translate(${x}px,${y}px)`;}
function faceTo(E,dir){const f=E.el.querySelector('.flip');if(!f||!dir)return;const base=E.base===undefined?1:E.base;if(!base)return;f.style.transform=dir!==base?'scaleX(-1)':'';}
// whoever stands nearer the viewer is drawn on top (the market hedgehog stays behind the counter)
function depth(){
  if(play.l.scene.fixedDepth)return;
  const svg=$('#world svg'), want=[play.B,play.N].sort((a,b)=>a.zy-b.zy).map(e=>e.el);
  const kids=[...svg.children].filter(c=>c.classList.contains('ent'));
  if(kids[0]===want[0]&&kids[1]===want[1])return;
  want.forEach(el=>svg.appendChild(el));
  want.forEach(el=>getComputedStyle(el).transform);   // commit the start position so the walk animates from it
}
function routeTime(E,pts,speed){let x=E.x,y=E.y,d=0;for(const [px,py] of pts){d+=Math.hypot(px-x,py-y);x=px;y=py;}return d/speed*1000;}
async function walk(E,pts,speed,turn=true){
  for(const [px,py] of pts){
    const d=Math.hypot(px-E.x,py-E.y);if(d<1)continue;
    const ms=d/speed*1000;
    if(turn&&Math.abs(px-E.x)>2)faceTo(E,px>E.x?1:-1);
    getComputedStyle(E.el).transform;   // make sure the move starts from where the character really is
    if(play&&E===play.B)sfx('hop');
    E.el.classList.add('walking');
    E.el.style.transition=`transform ${ms}ms linear, opacity .6s`;
    E.el.style.transform=`translate(${px}px,${py}px)`;
    E.x=px;E.y=py;
    await wait(ms);
  }
  E.el.classList.remove('walking');
}
function react(E,cls,ms=1300){const r=E.el.querySelector('.react');r.classList.remove('happy','confused','shake','big','sit');void r.getBoundingClientRect();r.classList.add(cls);later(()=>r.classList.remove(cls),ms);}
function mood(m){const b=play.B.el;b.classList.remove('is-happy','is-sad');if(m)b.classList.add('is-'+m);}
function fx(E,txt,color='#B04C12'){const f=E.el.querySelector('.fxt');f.textContent=txt;f.setAttribute('fill',color);f.classList.remove('go');void f.getBoundingClientRect();f.classList.add('go');}

/* --- camera: pans, and zooms for walking into new places --- */
function layout(){
  if(!play)return;
  const st=$('#stage');if(!st)return;
  const H=st.clientHeight, s=H/300, w=$('#world');
  play.scale=s;play.vw=st.clientWidth;play.vh=H;
  w.style.width=play.l.scene.w*s+'px';w.style.height=H+'px';
  camTo(play.camX,0,play.z||1,play.camY||150);
}
function camTo(x,ms,z=1,y=150){
  play.camX=x;play.camY=y;play.z=z;const w=$('#world');if(!w)return;
  const s=play.scale, W=play.l.scene.w*s*z, H=300*s*z;
  let tx=play.vw/2-x*s*z;tx=Math.min(0,Math.max(play.vw-W,tx));
  let ty=play.vh/2-y*s*z;ty=Math.min(0,Math.max(play.vh-H,ty));
  play.tx=tx;play.ty=ty;
  w.style.transition=ms?`transform ${ms}ms ease-in-out`:'none';
  w.style.transform=`translate(${tx}px,${ty}px) scale(${z})`;
}
function fitCam(x,reg){
  if(!reg)return {x,z:1,y:150};
  const vis=play.vw/play.scale, z=Math.max(1,vis/(reg[1]-reg[0])), half=vis/z/2;
  return {x:Math.max(reg[0]+half,Math.min(reg[1]-half,x)),z,y:300-150/z};
}
const toScreen=(x,y)=>[play.tx+x*play.scale*play.z, play.ty+y*play.scale*play.z];
async function iris(open,x,y,ms=550){
  const ir=$('#iris'), [sx,sy]=toScreen(x,y), big=Math.hypot(play.vw,play.vh)*1.1;
  ir.style.left=sx+'px';ir.style.top=sy+'px';
  ir.style.transition='none';ir.style.setProperty('--r',(open?0:big)+'px');void ir.offsetWidth;
  ir.style.transition=`width ${ms}ms ease-in-out,height ${ms}ms ease-in-out`;ir.style.setProperty('--r',(open?big:0)+'px');
  ir.hidden=false;
  await wait(ms);
  if(open)ir.hidden=true;
}
window.addEventListener('resize',()=>{if(play&&$('#world')){layout();placeBubbles();}});

/* --- bubbles: one speaker at a time, floating over whoever is talking --- */
function placeBubble(el,E,head,O,oHead){
  if(!el||el.hidden||!play||!play.scale)return;
  const vw=play.vw, [sx,sy0]=toScreen(E.x,E.y-head);
  let sy=sy0;
  const bw=el.offsetWidth, bh=el.offsetHeight;
  const left=Math.max(8,Math.min(vw-bw-8,sx-bw/2));
  const [ox,oy]=toScreen(O.x,O.y-oHead);
  if(ox>left-20&&ox<left+bw+20)sy=Math.min(sy,oy);
  el.style.left=left+'px';
  el.style.top=Math.max(6,sy-bh-12)+'px';
  el.style.setProperty('--tail',Math.max(18,Math.min(bw-18,sx-left))+'px');
}
function placeBubbles(){if(!play||!play.B)return;const nh=play.l._npc.head||46;placeBubble($('#bb'),play.B,74,play.N,nh);placeBubble($('#nb'),play.N,nh,play.B,74);const wu=$('#wui');if(wu&&wu.querySelector('.place:not(.dim)'))avoidLabels();}
function pop(el){el.style.animation='none';void el.offsetWidth;el.style.animation='';}
function bunnySays(text){
  $('#nb').hidden=true;
  const bb=$('#bb');bb.hidden=false;
  bb.innerHTML=`<span class="who">${t('you')}</span>${esc(text)}`;
  placeBubbles();pop(bb);
}
function bunnyQuiet(){$('#bb').hidden=true;}
function npcQuiet(){$('#nb').hidden=true;}
function npcLine(line,key){
  const tap=!play.hard, nb=$('#nb'), chunks=parseLine(line);
  $('#bb').hidden=true;nb.hidden=false;nb.classList.remove('confused');
  nb.innerHTML=`<span class="who">${esc(play.l._npc[tgt()])}${speakBtn(chunks.map(c=>c[tgt()]).join(' '))}</span><span class="line">${chunks.map((c,j)=>tap
    ?`<button class="chunk tap" data-k="${key}-c${j}" data-g="${esc(c[nat()])}">${esc(c[tgt()])}</button>`
    :`<span class="chunk">${esc(c[tgt()])}</span>`).join('')}</span>`;
  wireSpeak(nb);
  nb.querySelectorAll('.chunk.tap').forEach(b=>b.onclick=()=>{
    const g=b.querySelector('.gloss');
    if(g)g.hidden=!g.hidden;
    else{b.insertAdjacentHTML('beforeend',`<span class="gloss">${esc(b.dataset.g)}</span>`);if(tapCounts(b.firstChild.textContent))play.reveals.add(b.dataset.k);hud();}
    placeBubbles();
  });
  placeBubbles();pop(nb);
}
function npcPlain(text){
  $('#bb').hidden=true;
  const nb=$('#nb');nb.hidden=false;nb.classList.add('confused');
  nb.innerHTML=`<span class="who">${esc(play.l._npc[tgt()])}</span>${esc(text)}`;
  placeBubbles();pop(nb);
}

/* --- the answer box under the stage --- */
function yoursHtml(label,text){return `<div class="yours"><span class="yl">${label}</span><span class="yt">${esc(text)}</span></div>`;}
// replace the question with "your choice/response" and the verdict right under it
function showVerdict(label,text,fbHtml){
  const ctl=$('#controls');
  ctl.innerHTML=yoursHtml(label,text)+`<div id="fb">${fbHtml}</div>`;
}
const enterHint=k=>`<span class="keyhint"><kbd>Enter</kbd> ${t(k)}</span>`;

/* --- level --- */
function startLevel(id,hardMode=false){
  const l=levelById(id);l._npc=NPCS[l.npc];
  const hard=hardMode||l.boss||l.diff==='hard';
  const lessonWords=l.lesson.map(it=>norm(it[tgt()])).filter(w=>w.length>2);
  const opts=l.nodes.map(n=>n.t==='act'?nodeOpts(n):shuffle(nodeOpts(n)));
  play={id,l,hard,hardMode,noHints:hardMode||l.boss,lessonWords,hints:0,idx:0,hearts:MAX_LIVES,first:0,wrong:false,busy:true,enter:null,reveals:new Set(),elapsed:0,opts,par:parTime(l),camX:l.nodes[0].b[0],z:1,
    tried:new Set(),
    revealable:l.nodes.reduce((a,n,i)=>a+parseLine(n.line).length+(n.t==='say'?opts[i].length:0),0)+parseLine(l.outro).length};
  const n=l.nodes.length;
  const dots=Array.from({length:n},(_,i)=>`<span class="dot" data-d="${i}" style="--p:${i/n}"></span>`).join('');
  const npcG=`<g class="ent npc${l._npc.fly?' fly':''}" id="npc"><ellipse class="cshadow" cx="0" cy="1" rx="${l._npc.sh||20}" ry="4" fill="#1E3B24" opacity="${l._npc.fly?0:.17}"/><g class="react"><g class="flip"><g class="bob">${NPC_ART[l._npc.art]}</g></g></g><text class="fxt" y="-54" text-anchor="middle"></text></g>`;
  const bunG=`<g class="ent bunny" id="bunny"><ellipse class="cshadow" cx="-3" cy="1" rx="24" ry="4.5" fill="#1E3B24" opacity=".17"/><g class="react"><g class="flip"><g class="bob">${bunnyBody}</g></g></g><text class="fxt" y="-80" text-anchor="middle"></text></g>`;
  const art=buildScene(l,npcG,bunG);
  show(`<div class="wrap play-wrap">
    <div class="hud"><button class="quit" id="quit" aria-label="${t('quit')}">✕</button>
      <span class="lvl">${l.world}-${l.num}</span><span class="chip ${l.boss?'hard':l.diff}">${l.boss?t('boss'):t(l.diff)}</span>${hardMode?`<span class="chip hard">${t('hardMode')}</span>`:''}<span class="spacer"></span><button class="quit snd" id="snd" aria-label="${t('sound')}">${save.sound?'♪':'<s>♪</s>'}</button>
      <span class="hearts" id="hearts" aria-label="${t('lives')}"></span>${hard?'':`<span class="trcount" id="trc"></span>`}<span class="clock" id="clock">0:00</span></div>
    <div class="track"><div class="path"></div>${dots}${carrotSvg('mini-carrot')}</div>
    <div class="stage" id="stage">
      <div class="world" id="world"><svg viewBox="0 0 ${l.scene.w} 300" aria-hidden="true">${art}</svg><div class="wui" id="wui"></div></div>
      <div class="iris" id="iris" hidden></div>
      <div class="talk" id="talk"><div class="bub bub-b" id="bb" hidden></div><div class="bub bub-n" id="nb" hidden></div></div>
    </div>
    <div class="panel controls" id="controls"></div>
  </div>`);
  $('#quit').onclick=()=>{play=null;renderMap();};
  $('#snd').onclick=()=>{save.sound=!save.sound;persist();$('#snd').innerHTML=save.sound?'♪':'<s>♪</s>';};
  keyHandler=e=>{if(e.key==='Enter'&&play&&play.enter){e.preventDefault();play.enter();}};
  cleanDecor($('#world svg'));
  play.B=makeEnt($('#bunny'));play.N=makeEnt($('#npc'));play.N.base=l._npc.faces||0;
  place(play.B,...l.scene.start);place(play.N,...l.nodes[0].n);
  layout();
  hud();
  let last=Date.now();
  timer=setInterval(()=>{const now=Date.now();if(!play.busy)play.elapsed+=(now-last)/1000;last=now;const c=$('#clock');if(c)c.textContent=fmt(play.elapsed);},200);
  setupNode();
}
function hud(lostOne){
  const h=$('#hearts');
  h.innerHTML=Array.from({length:MAX_LIVES},(_,i)=>i<play.hearts?'♥':`<span class="gone ${lostOne&&i===play.hearts?'lost':''}">♥</span>`).join('');
  const trc=$('#trc');if(trc)trc.textContent=`${play.reveals.size+play.hints} ${t('tr')}`;
}
function frameCam(n,opts){
  // an act frames the bunny and every choice; the speaker is included only when it all still fits
  if(n.t!=='act')return (Math.min(n.b[0],n.n[0])+Math.max(n.b[0],n.n[0]))/2;
  const vis=play.vw/play.scale, core=[n.b[0]-10,...opts.map(o=>o.at[0])], all=[...core,n.n[0]];
  const xs=Math.max(...all)-Math.min(...all)+76<=vis?all:core;
  return (Math.min(...xs)+Math.max(...xs))/2;
}
async function setupNode(){
  const p=play, n=p.l.nodes[p.idx], opts=p.opts[p.idx];
  p.wrong=false;p.misses=0;p.busy=true;p.enter=null;p.tried=new Set();mood(null);p.reg=n.reg||null;
  $('#wui').innerHTML='';
  $('#controls').innerHTML=`<p class="ask muted">…</p>`;
  const cam=frameCam(n,opts);
  if(n.from){
    // arriving somewhere new: start zoomed in where the bunny comes out, open the iris, then pull back
    bunnyQuiet();npcQuiet();
    place(p.B,...n.from);p.B.el.style.opacity='1';
    const zx=p.reg?Math.max(p.reg[0]+p.vw/p.scale/4.4,n.from[0]):n.from[0];
    camTo(zx,0,2.2,n.from[1]-30);
    await iris(true,n.from[0],n.from[1]-30,600);
  }
  p.B.el.style.opacity='1';
  const bRoute=[...(n.via||[]),n.b];
  // if the bunny has to pass the other animal, the animal first steps into its own lane (front or back)
  const crossing=Math.sign(p.B.x-p.N.x)!==Math.sign(n.b[0]-n.n[0]);
  const nRoute=crossing?[[p.N.x,n.n[1]],n.n]:[n.n];
  const tB=routeTime(p.B,bRoute,BUNNY_SPEED)+(crossing?400:0), tN=routeTime(p.N,nRoute,p.l._npc.speed);
  p.B.zy=n.b[1];p.N.zy=n.n[1];depth();
  if(tB>30||tN>30){bunnyQuiet();npcQuiet();}
  const c=fitCam(cam,p.reg), camMs=Math.max(n.from?1300:700,tB), t0=Date.now();
  camTo(c.x,camMs,c.z,c.y);
  // heading the same way: whoever is behind sets off later, so nobody walks through the other
  const dir=Math.sign(n.b[0]-p.B.x)||Math.sign(n.n[0]-p.N.x);
  const npcAhead=dir*(p.N.x-p.B.x)>0;
  const tBw=routeTime(p.B,bRoute,BUNNY_SPEED);
  const delayB=!crossing&&npcAhead&&tN>tBw?tN-tBw:0, delayN=!crossing&&!npcAhead&&tBw>tN?tBw-tN:0;
  (async()=>{if(delayN)await wait(delayN);walk(p.N,nRoute,p.l._npc.speed);})();
  if(crossing)await wait(400);
  if(delayB)await wait(delayB);
  await walk(p.B,bRoute,BUNNY_SPEED);
  const doneN=Math.max(tN+delayN,0)-(tBw+delayB+(crossing?400:0));
  if(doneN>0)await wait(doneN);
  const rest=camMs-(Date.now()-t0);if(rest>0)await wait(rest);
  faceTo(p.B,n.n[0]<n.b[0]?-1:1);faceTo(p.N,n.b[0]<n.n[0]?-1:1);
  if(n.hide)n.hide.split(' ').forEach(id=>{const g=document.getElementById(id);if(g)g.classList.add('gone');});
  if(n.show)n.show.split(' ').forEach(id=>{const g=document.getElementById(id);if(g)g.classList.add('shown');});
  if(n.t==='listen'&&canSpeak)npcListen(n.line);else npcLine(n.line,p.idx);
  renderControls();
}
// the question for the current step (also used to try again after a wrong answer)
function renderControls(){
  const p=play, n=p.l.nodes[p.idx], opts=p.opts[p.idx], ctl=$('#controls'), tap=!p.hard;
  p.enter=null;
  if(n.t==='say'){
    ctl.innerHTML=`<div class="askrow"><p class="ask">${t('youSay')}</p>${hintBtn()}</div><div class="opts">${opts.map((o,i)=>`<div class="opt">
      <button class="choice${p.tried.has(i)?' wrongpick':''}" data-i="${i}" ${p.tried.has(i)?'disabled':''}><span>${esc(o.text)}</span><span class="gloss" hidden>${esc(o.gloss||'')}</span></button>
      ${tap&&o.gloss?`<button class="trbtn" data-tr="${i}" aria-label="${t('translate')}">A⇄</button>`:''}</div>`).join('')}</div>`;
    ctl.querySelectorAll('.choice').forEach(b=>b.onclick=()=>chooseSay(+b.dataset.i));
    wireHint();
    ctl.querySelectorAll('[data-tr]').forEach(b=>b.onclick=()=>{
      const g=ctl.querySelector(`.choice[data-i="${b.dataset.tr}"] .gloss`);
      g.hidden=!g.hidden;b.classList.add('used');
      p.reveals.add(`${p.idx}-o${b.dataset.tr}`);hud();
    });
  }else if(n.t==='listen'){
    ctl.innerHTML=`<p class="ask">${t('listenStep')}</p><div class="choices">${opts.map((o,i)=>`<button class="choice${p.tried.has(i)?' wrongpick':''}" data-i="${i}" ${p.tried.has(i)?'disabled':''}>${esc(o.text)}</button>`).join('')}</div>`;
    ctl.querySelectorAll('.choice').forEach(b=>b.onclick=()=>chooseListen(+b.dataset.i));
  }else if(n.t==='act'){
    const W=p.l.scene.w;
    $('#wui').innerHTML=opts.map((o,i)=>`<button class="place${o.tag?' tag':''}${p.tried.has(i)?' wrong':''}" data-i="${i}" ${p.tried.has(i)?'disabled':''} style="left:${o.at[0]/W*100}%;top:${o.at[1]/3}%"><span>${esc(o.lab)}</span></button>`).join('');
    $('#wui').querySelectorAll('.place').forEach(b=>b.onclick=()=>chooseAct(+b.dataset.i));
    opts.forEach((o,i)=>{const g=o.hot&&document.getElementById(o.hot);if(g&&!p.tried.has(i)){g.classList.add('hot');g.onclick=()=>chooseAct(i);}});
    ctl.innerHTML=`<p class="ask">${t('whatDo')}</p><p class="muted">${t('tapPlace')}</p>`;
    fitLabels();avoidLabels();
  }else{
    ctl.innerHTML=`<div class="askrow"><p class="ask">${t('yourReply')}</p>${hintBtn()}</div><p class="prompt-native">${esc(n.prompt[nat()])}</p><p class="typehint" id="th" hidden></p>
      <div class="typebox"><input id="ti" autocomplete="off" autocapitalize="off" spellcheck="false" aria-label="${t('yourReply')}"><button class="btn leaf" id="send">${t('say')}</button></div>
      ${accentKeys()}`;
    const inp=$('#ti');inp.focus({preventScroll:true});wireAccents(inp);
    $('#send').onclick=()=>submitType();
    wireHint();
    p.enter=submitType;
  }
  p.busy=false;
}
function credit(){if(!play.wrong)play.first++;}
// after a wrong answer: lose a life, then wait for "Try again"
function wrongVerdict(label,text,msg,restore,answer){
  const p=play;sfx('bad');
  p.wrong=true;p.hearts--;hud(true);p.misses=(p.misses||0)+1;
  const dead=p.hearts<=0;
  const reveal=p.misses>=2&&answer?`<span class="ans">${t('theAnswer')} <b>${esc(answer)}</b></span>`:'';
  showVerdict(label,text,`<div class="fb bad"><b>${t('notQuite')}</b><span>${msg}</span>${reveal}${dead?'':`<div class="row"><button class="btn small" id="again">${t('tryAgain')}</button>${enterHint('pressEnterGo')}</div>`}</div>`);
  if(dead){p.busy=true;p.enter=null;later(renderLost,1900);return;}
  let gone=false;
  const go=()=>{if(gone||p.busy)return;gone=true;restore&&restore();renderControls();};
  $('#again').onclick=go;
  p.armed=go;
}
function chooseSay(i){
  const p=play;if(p.busy)return;
  p.busy=true;
  const o=p.opts[p.idx][i], n=p.l.nodes[p.idx];
  bunnySays(o.text);react(p.B,'happy',450);
  if(o.ok){
    credit();sfx('ok');
    showVerdict(t('yourChoice'),o.text,`<div class="fb good"><b>${t('nice')}</b></div>`);
    later(()=>{react(p.N,'happy');fx(p.N,'♪','#3D7A33');mood('happy');},500);
    later(advance,1500);
  }else{
    p.tried.add(i);
    later(()=>{npcPlain(pick(CONFUSED[tgt()]));react(p.N,'confused');fx(p.N,'?');mood('sad');},550);
    wrongVerdict(t('yourChoice'),o.text,esc(o.fb||t('notUnderstood')),()=>{npcLine(n.line,p.idx);mood(null);},p.opts[p.idx].find(x=>x.ok).text);
    p.enter=null;
    later(()=>{p.busy=false;p.enter=p.armed;},900);
  }
}
function submitType(){
  const p=play;if(p.busy)return;
  const n=p.l.nodes[p.idx], inp=$('#ti'), v=inp.value.trim();
  if(!v){inp.focus();return;}
  p.busy=true;p.enter=null;
  const g=grade(v,[n.say[tgt()],...n.ans[tgt()]]);
  bunnySays(v);react(p.B,'happy',450);
  if(g.ok){
    credit();sfx('ok');
    later(()=>{react(p.N,'happy');fx(p.N,'♪','#3D7A33');mood('happy');},500);
    if(g.kind==='exact'){
      showVerdict(t('yourResponse'),v,`<div class="fb good"><b>${t('nice')}</b></div>`);
      later(advance,1500);
    }else{
      showVerdict(t('yourResponse'),v,`<div class="fb good"><b>${t('correct')}</b><span class="ans">${gradeNote(g)}</span><div class="row"><button class="btn small" id="c">${t('cont')}</button>${enterHint('pressEnterGo')}</div></div>`);
      let gone=false;const go=()=>{if(gone)return;gone=true;advance();};
      $('#c').onclick=go;
      later(()=>{p.enter=go;},500);
    }
  }else{
    later(()=>{npcPlain(pick(CONFUSED[tgt()]));react(p.N,'confused');fx(p.N,'?');mood('sad');},550);
    wrongVerdict(t('yourResponse'),v,`${t('notUnderstood')}<br><span class="hint">${hintFor(v,[n.say[tgt()],...n.ans[tgt()]])}</span>`,()=>{npcLine(n.line,p.idx);mood(null);},n.say[tgt()]);
    later(()=>{p.busy=false;p.enter=p.armed;},900);
  }
}
async function chooseAct(i){
  const p=play, n=p.l.nodes[p.idx], o=p.opts[p.idx][i];
  if(p.busy||p.tried.has(i))return;
  p.busy=true;p.enter=null;bunnyQuiet();
  const btn=$(`#wui .place[data-i="${i}"]`);
  $('#wui').querySelectorAll('.place').forEach(x=>{if(x!==btn)x.classList.add('dim');});
  document.querySelectorAll('.hot').forEach(g=>{g.classList.remove('hot');g.onclick=null;});
  $('#controls').innerHTML=yoursHtml(t('yourChoice'),o.lab)+`<div id="fb"></div>`;
  const end=o.walk[o.walk.length-1][0], half=p.vw/p.scale/2;
  if(o.ok&&!o.fade&&Math.abs(end-p.camX)>half-40)camTo(end,routeTime(p.B,o.walk,BUNNY_SPEED));
  await walk(p.B,o.walk,BUNNY_SPEED);
  if(o.ok){
    btn&&btn.classList.add('right');
    credit();sfx('ok');mood('happy');react(p.B,'happy');fx(p.B,'✦','#F2A81D');react(p.N,'happy');
    setFb(`<div class="fb good"><b>${t('nice')}</b></div>`);
    if(o.reveal){const r=document.getElementById(o.reveal);if(r)r.classList.add('out');}
    if(o.pay){const k=document.getElementById(o.pay);if(k)k.style.transform=o.payTo||'translate(86px,-30px)';sfx('coin');}
    if(o.light){const g=document.getElementById(o.light);if(g){g.classList.remove('red');g.classList.add('green');}}
    if(o.hide){o.hide.split(' ').forEach(id=>{const g=document.getElementById(id);if(g)g.classList.add('gone');});}
    if(o.show){o.show.split(' ').forEach(id=>{const g=document.getElementById(id);if(g)g.classList.add('shown');});}
    await wait(1000);
    if(o.fade){
      // walk into the new place: the camera follows the bunny in, and an iris closes on it
      $('#wui').innerHTML='';npcQuiet();
      const [ex,ey]=o.walk[o.walk.length-1];
      camTo(ex,1100,2.2,ey-30);
      p.B.el.style.opacity='0.15';
      await wait(900);
      await iris(false,ex,ey-30,500);
    }
    advance();
  }else{
    p.tried.add(i);
    btn&&btn.classList.add('wrong');
    if(o.fx==='bonk'){react(p.B,'big',700);await wait(380);fx(p.B,'!');}
    else if(o.fx==='fall'){const pl=document.getElementById(o.hit);if(pl)pl.classList.add('drop');react(p.B,'big',700);fx(p.B,'!');}
    else if(o.fx==='splash'){sfx('splash');react(p.B,'shake');fx(p.B,'💦','#6FB7D9');}
    else if(o.fx==='sleep'){react(p.B,'sit',1400);fx(p.B,'z z','#5C6A52');}
    else{react(p.B,'confused');fx(p.B,'?');}
    mood('sad');
    npcPlain(NOT_THAT[tgt()]);react(p.N,'shake');
    wrongVerdict(t('yourChoice'),o.lab,esc(o.fb||''),()=>{faceTo(p.B,1);mood(null);npcLine(n.line,p.idx);},p.opts[p.idx].find(x=>x.ok).lab);
    if(p.hearts<=0)return;
    await wait(1100);
    const back=[...o.walk].reverse().slice(1).concat([n.b]);
    await walk(p.B,back,BUNNY_SPEED);
    faceTo(p.B,n.n[0]<n.b[0]?-1:1);
    $('#wui').querySelectorAll('.place').forEach(x=>x.classList.remove('dim'));
    p.busy=false;p.enter=p.armed;
  }
}
// keep every label on screen and stop neighbours from touching
function fitLabels(){
  const st=$('#stage').getBoundingClientRect(), z=play.z||1, bs=[...$('#wui').querySelectorAll('.place')];
  bs.forEach(b=>{b.style.removeProperty('--nx');b.style.removeProperty('--lift');});
  bs.forEach(b=>{const r=b.getBoundingClientRect();let dx=0;if(r.left<st.left+4)dx=st.left+4-r.left;else if(r.right>st.right-4)dx=st.right-4-r.right;if(dx)b.style.setProperty('--nx',(dx/z)+'px');});
  const placed=[];
  bs.sort((a,b)=>a.getBoundingClientRect().left-b.getBoundingClientRect().left).forEach(b=>{
    let lift=0;
    for(let k=0;k<4;k++){
      const r=b.getBoundingClientRect(), hit=placed.find(q=>r.left<q.right+3&&q.left<r.right+3&&r.top<q.bottom+3&&q.top<r.bottom+3);
      if(!hit)break;
      lift+=(r.bottom-hit.top+4)/z;b.style.setProperty('--lift',lift+'px');
    }
    placed.push(b.getBoundingClientRect());
  });
}
// the speech bubble slides sideways if it would hide a choice; if no spot is free, it lets taps through to the labels
function avoidLabels(){
  const nb=$('#nb');if(!nb||nb.hidden)return;
  nb.classList.remove('thin');
  const st=$('#stage').getBoundingClientRect(), ls=[...$('#wui').querySelectorAll('.place')].map(b=>b.getBoundingClientRect());
  const hits=()=>{const r=nb.getBoundingClientRect();return ls.some(q=>r.left<q.right+2&&q.left<r.right+2&&r.top<q.bottom+2&&q.top<r.bottom+2);};
  if(!hits())return;
  const left0=parseFloat(nb.style.left)||0, w=nb.offsetWidth, sx=left0+parseFloat(getComputedStyle(nb).getPropertyValue('--tail')||30);
  for(const L of [8,st.width-w-8]){nb.style.left=L+'px';nb.style.setProperty('--tail',Math.max(18,Math.min(w-18,sx-L))+'px');if(!hits())return;}
  nb.style.left=left0+'px';nb.style.setProperty('--tail',Math.max(18,Math.min(w-18,sx-left0))+'px');
  nb.classList.add('thin');
}
function setFb(html){const f=$('#fb');if(f)f.innerHTML=html;}
function advance(){
  play.enter=null;play.idx++;
  document.querySelectorAll('.track .dot').forEach(d=>{if(+d.dataset.d<play.idx)d.classList.add('passed');});
  if(play.idx>=play.l.nodes.length)return finale();
  setupNode();
}
function spawnPrize(from,to){
  const svg=$('#world svg'), g=document.createElementNS('http://www.w3.org/2000/svg','g');
  g.setAttribute('transform',`translate(${from[0]} ${from[1]})`);
  const v=`--dx:${to[0]-from[0]}px;--dy:${to[1]-from[1]}px`;
  const rays=Array.from({length:12},(_,i)=>{const a=i*Math.PI/6,r1=12,r2=i%2?26:32;return `<path d="M${(Math.cos(a)*r1).toFixed(1)} ${(Math.sin(a)*r1).toFixed(1)}L${(Math.cos(a)*r2).toFixed(1)} ${(Math.sin(a)*r2).toFixed(1)}" stroke="${i%3?'#F2A81D':'#E2681C'}" stroke-width="3.5" stroke-linecap="round"/>`;}).join('');
  const dots=Array.from({length:8},(_,i)=>{const a=i*Math.PI/4+.4;return `<circle cx="${(Math.cos(a)*20).toFixed(1)}" cy="${(Math.sin(a)*20).toFixed(1)}" r="3" fill="${['#E2681C','#3D7A33','#F2A81D','#D84A3A'][i%4]}"/>`;}).join('');
  g.innerHTML=`<g class="pz-b" style="${v}">${rays}${dots}<circle r="34" fill="none"/></g>
    <g class="pz-c" style="${v}"><path d="M0 -10C-6 -20 -11 -24 -12 -32C-5 -29 -1 -23 0 -17C1 -26 6 -31 11 -34C9 -25 5 -17 1 -10Z" fill="#3D7A33" ${K1}/><path d="M-9 -10Q0 -15 9 -10Q8 8 1 26Q0 27 -1 26Q-8 8 -9 -10Z" fill="#E2681C" ${K}/><path d="M-5 -2h5M1 6h4M-3 13h3" stroke="#B04C12" stroke-width="1.6" stroke-linecap="round"/><path d="M-5 -8q-1 8 1 14" stroke="#fff" stroke-width="2" opacity=".6" fill="none" stroke-linecap="round"/></g>`;
  svg.appendChild(g);
}
async function finale(){
  const p=play, f=p.l.scene.finale;p.busy=true;
  $('#controls').innerHTML=`<div class="fb good"><b>${t('reached')}</b></div>`;
  $('#wui').innerHTML='';
  npcLine(p.l.outro,'o');react(p.N,'happy');
  const last=f.walk[f.walk.length-1];
  const c=fitCam(Math.max(p.camX,last[0]-30),p.reg);
  camTo(c.x,routeTime(p.B,f.walk,BUNNY_SPEED),c.z,c.y);
  await walk(p.B,f.walk,BUNNY_SPEED);
  faceTo(p.B,f.src[0]>=p.B.x?1:-1);placeBubbles();
  // only now do the carrots come up out of the ground
  if(f.crops){const c=document.getElementById(f.crops);if(c)c.classList.add('up');await wait(900);}
  if(f.pull){const c=document.getElementById(f.pull);if(c)c.classList.add('pulled');await wait(650);if(c)c.style.opacity='0';}
  mood('happy');react(p.B,'happy');npcQuiet();
  spawnPrize(f.src,[p.B.x,p.B.y-132]);later(()=>sfx('pop'),1900);
  await wait(2200);
  bunnySays(tgt()==='es'?'¡Zanahorias!':'Carrots!');fx(p.B,'♥','#B8362A');
  await wait(1600);
  renderResults();
}
function renderLost(){
  const id=play.id;
  show(`<div class="wrap"><div class="panel center">
    <div class="hero-art" style="width:120px;transform:rotate(-8deg)">${bunnySvg()}</div>
    <h2>${t('lost')}</h2><p class="muted">${t('lostBody')}</p>
    <div class="row" style="justify-content:center"><button class="btn primary" id="again">${t('retry')}</button><button class="btn" id="map">${t('map')}</button></div>
  </div></div>`);
  $('#again').onclick=()=>startLevel(id);
  $('#map').onclick=()=>renderMap();
}
