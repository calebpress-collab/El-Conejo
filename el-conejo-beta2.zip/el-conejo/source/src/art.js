/* ============ ART ============ */
const bunnySvg=()=>`<svg class="bunny" viewBox="0 0 64 64" aria-hidden="true">
<g><ellipse class="fur" cx="23" cy="17" rx="6" ry="15" transform="rotate(-10 23 17)"/><ellipse class="pink" cx="23" cy="18" rx="2.6" ry="10" transform="rotate(-10 23 18)"/></g>
<g class="ear-r"><ellipse class="fur" cx="41" cy="17" rx="6" ry="15" transform="rotate(12 41 17)"/><ellipse class="pink" cx="41" cy="18" rx="2.6" ry="10" transform="rotate(12 41 18)"/></g>
<ellipse class="fur" cx="32" cy="42" rx="18" ry="16"/>
<g class="eyes-open"><circle class="inkf" cx="25.5" cy="39" r="2.4"/><circle class="inkf" cx="38.5" cy="39" r="2.4"/><circle cx="26.3" cy="38.2" r=".8" fill="#fff"/><circle cx="39.3" cy="38.2" r=".8" fill="#fff"/></g>
<g class="eyes-happy"><path class="inks" d="M23 40q2.5-3 5 0M36 40q2.5-3 5 0"/></g>
<path class="sweat" d="M48 30q3 4 0 6q-3-2 0-6z" fill="#8FD0EE" stroke="#25311F" stroke-width="1.2"/>
<circle class="pink" cx="21" cy="46" r="3"/><circle class="pink" cx="43" cy="46" r="3"/>
<path class="inkf" d="M29.5 44.5h5l-2.5 2.6z"/><path d="M32 47v2.5M32 49.5c-1.5 1.4-3.3 1.4-4.5.3M32 49.5c1.5 1.4 3.3 1.4 4.5.3" fill="none" stroke="#25311F" stroke-width="1.5" stroke-linecap="round"/></svg>`;
const carrotSvg=(cls='carrot')=>`<svg class="${cls}" viewBox="0 0 40 72" aria-hidden="true">
<path class="carrot-leaf" d="M20 18 C14 10 10 6 8 1 C14 3 18 8 20 14 C21 6 24 2 28 0 C27 7 24 12 21 18 Z"/>
<path class="carrot-body" d="M8 20 Q20 14 32 20 Q30 44 21 70 Q19 71 18 69 Q10 44 8 20 Z"/>
<path class="carrot-line" d="M12 30h6M22 38h6M13 46h5M21 54h4"/></svg>`;
const starPath='M12 2.5l2.9 6.1 6.6.8-4.9 4.6 1.3 6.6L12 17.3 6.1 20.6l1.3-6.6L2.5 9.4l6.6-.8z';
const stars=(n,cls='stars')=>`<span class="${cls}" aria-label="${n}/3">${[1,2,3].map(i=>`<svg viewBox="0 0 24 24" class="${i<=n?'on':''}"><path class="${i<=n?'star-on':'star-off'}" d="${starPath}"/></svg>`).join('')}</span>`;
/* ============ WORLDS ============
   Each world is drawn in one SVG, 300 units tall. Ids on groups are what choices point at. */
const K='stroke="#25311F" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"';
const K1='stroke="#25311F" stroke-width="1.4" stroke-linejoin="round" stroke-linecap="round"';
let ZN=[];
const Z={
  rect:(x,y,w,h)=>ZN.push(`<rect x="${x}" y="${y}" width="${w}" height="${h}"/>`),
  ell:(cx,cy,rx,ry)=>ZN.push(`<ellipse cx="${cx}" cy="${cy}" rx="${rx}" ry="${ry}"/>`),
  d:(d)=>ZN.push(`<path d="${d}"/>`),
  line:(d,w)=>ZN.push(`<path d="${d}" fill="none" stroke="#000" stroke-width="${w}" stroke-linecap="round"/>`)
};
// remove any flower or grass tuft whose footprint touches a path, water or an object
function cleanDecor(svg){
  const zones=[...svg.querySelectorAll('.ng > *')];if(!zones.length)return;
  const pt=svg.createSVGPoint();
  svg.querySelectorAll('.dec').forEach(el=>{
    const [x,y,hw,h]=el.dataset.b.split(',').map(Number);
    const pts=[[x,y],[x-hw,y],[x+hw,y],[x,y-h],[x-hw,y-h*.6],[x+hw,y-h*.6]];
    const hit=pts.some(([px,py])=>{pt.x=px;pt.y=py;return zones.some(z=>{try{return z.getAttribute('stroke')?z.isPointInStroke(pt):z.isPointInFill(pt);}catch(e){return false;}});});
    if(hit)el.remove();
  });
}
function rng(seed){return ()=>{seed|=0;seed=seed+0x6D2B79F5|0;let t=Math.imul(seed^seed>>>15,1|seed);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};}
const G={
  sky:(id,a,b,ga='#A9D27F',gb='#86B95C')=>`<defs><linearGradient id="sk${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${a}"/><stop offset="1" stop-color="${b}"/></linearGradient><linearGradient id="gd${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${ga}"/><stop offset="1" stop-color="${gb}"/></linearGradient></defs>`,
  base:(id,W,hor=176)=>`<rect width="${W}" height="300" fill="url(#sk${id})"/>`,
  ground:(id,W,hor=176)=>`<rect y="${hor}" width="${W}" height="${300-hor}" fill="url(#gd${id})"/><path d="M0 ${hor}H${W}" stroke="#79A852" stroke-width="3"/>`,
  sun:(x,y)=>`<circle cx="${x}" cy="${y}" r="34" fill="#FFE9A3" opacity=".5"/><circle cx="${x}" cy="${y}" r="24" fill="#FFD45C"/>`,
  cloud:(x,y,s=1,c='#fff')=>`<g transform="translate(${x} ${y}) scale(${s})"><g class="drift" style="animation-duration:${8+((x*7)%9)}s"><path d="M14 36a12 12 0 0 1 2-23 16 16 0 0 1 30-6 14 14 0 0 1 26 6 12 12 0 0 1 6 23z" fill="${c}"/></g></g>`,
  hills:(W,y,amp,c,step=220,ph=0)=>{let d=`M0 300V${y}`;for(let x=0;x<W+step;x+=step){const up=((x/step+ph)%2)?amp:-amp;d+=` Q${x+step/2} ${y+up} ${x+step} ${y}`;}return `<path d="${d}V300Z" fill="${c}"/>`;},
  tree:(x,y,s=1,id='',cls='')=>{const C=[[0,-74,26],[-20,-62,19],[20,-62,19],[-12,-90,17],[13,-89,17]];return `<g ${id?`id="${id}"`:''} class="${cls}">${G.shadow(x,y,30*s)}<g transform="translate(${x} ${y}) scale(${s})"><path d="M-15 0Q-8 -3 -7 -14L-6 -50H6L7 -14Q8 -3 15 0Z" fill="#8A5A3B" ${K}/><path d="M-1 -10V-38M3 -20V-44" stroke="#6E4630" stroke-width="1.3" stroke-linecap="round"/>${C.map(([cx,cy,r])=>`<circle cx="${cx}" cy="${cy}" r="${r}" fill="#5FA046" stroke="#25311F" stroke-width="4"/>`).join('')}${C.map(([cx,cy,r])=>`<circle cx="${cx}" cy="${cy}" r="${r}" fill="#5FA046"/>`).join('')}<circle cx="-14" cy="-92" r="7" fill="#7DBA5E"/><circle cx="-24" cy="-66" r="6" fill="#7DBA5E"/><circle cx="6" cy="-80" r="5" fill="#7DBA5E"/></g></g>`;},
  smalltree:(x,y,s=1,c='#86B46A')=>`<g transform="translate(${x} ${y}) scale(${s})"><rect x="-3" y="-22" width="6" height="22" fill="#8A6A4E"/><circle cx="0" cy="-30" r="15" fill="${c}"/></g>`,
  pine:(x,y,s=1,c='#2F6B3A',k=true)=>`<g transform="translate(${x} ${y}) scale(${s})"><rect x="-4" y="-12" width="8" height="12" fill="#6B4A33"/><path d="M-22 -10L0 -50L22 -10ZM-18 -32L0 -72L18 -32ZM-13 -54L0 -90L13 -54Z" fill="${c}" ${k?K:''}/></g>`,
  bush:(x,y,s=1,c='#6FAE52')=>{const C=[[-18,-10,11],[-4,-18,13],[12,-15,12],[22,-7,9],[-26,-4,7],[2,-6,13]];return `${G.shadow(x,y,32*s)}<g transform="translate(${x} ${y}) scale(${s})">${C.map(([cx,cy,r])=>`<circle cx="${cx}" cy="${cy}" r="${r}" fill="${c}" stroke="#25311F" stroke-width="4"/>`).join('')}${C.map(([cx,cy,r])=>`<circle cx="${cx}" cy="${cy}" r="${r}" fill="${c}"/>`).join('')}<path d="M-31 0H31" stroke="${c}" stroke-width="3"/><circle cx="-8" cy="-12" r="2.3" fill="#E2504A"/><circle cx="12" cy="-8" r="2.3" fill="#E2504A"/><circle cx="2" cy="-20" r="2.3" fill="#E2504A"/></g>`;},
  rock:(x,y,s=1,id='',cls='')=>`<g ${id?`id="${id}"`:''} class="${cls}">${G.shadow(x,y,34*s)}<g transform="translate(${x} ${y}) scale(${s})"><path d="M-30 0Q-34 -26 -10 -34Q12 -44 26 -26Q36 -12 30 0Z" fill="#ABB1A1" ${K}/><path d="M-22 -12Q-20 -26 -6 -30" stroke="#C9CDC0" stroke-width="4" stroke-linecap="round" fill="none"/><path d="M8 -26l5 7-2 6" ${K1} fill="none" opacity=".55"/></g></g>`,
  shadow:(x,y,rx,ry)=>`<ellipse cx="${x}" cy="${y+1}" rx="${rx}" ry="${ry||Math.max(3,rx*.2)}" fill="#1E3B24" opacity=".16"/>`,
  stump:(x,y)=>`${G.shadow(x,y,26)}<g transform="translate(${x} ${y})"><path d="M-24 0Q-16 -2 -15 -8V-32H15V-8Q16 -2 24 0Q14 2 0 1Q-14 2 -24 0Z" fill="#8A5A3B" ${K}/><path d="M-8 -6V-28M6 -10V-30M-2 -2V-18" stroke="#6E4630" stroke-width="1.4" stroke-linecap="round"/><ellipse cx="0" cy="-32" rx="15" ry="5" fill="#D9B27C" ${K1}/><ellipse cx="0" cy="-32" rx="9" ry="3" fill="none" stroke="#B88A57" stroke-width="1"/><ellipse cx="0" cy="-32" rx="4" ry="1.4" fill="none" stroke="#B88A57" stroke-width="1"/><path d="M2 -32l7 -2" stroke="#8A5A3B" stroke-width="1"/></g>`,
  burrow:(x,y)=>`<g transform="translate(${x} ${y})"><path d="M-54 0Q-46 -48 0 -50Q46 -48 54 0Z" fill="#9FC57A" ${K}/><path d="M-30 -36q3-6 6 0M18 -40q3-6 6 0M34 -22q3-6 6 0" stroke="#5E8F3E" stroke-width="1.6" fill="none"/><ellipse cx="0" cy="2" rx="30" ry="6" fill="#A27B5A"/><path d="M-19 0Q-19 -27 0 -27Q19 -27 19 0Z" fill="#3A2C22" ${K1}/><path d="M-12 0Q-12 -18 0 -18Q12 -18 12 0Z" fill="#241A13"/><circle cx="-22" cy="3" r="2" fill="#8B6446"/><circle cx="20" cy="4" r="2.4" fill="#8B6446"/></g>`,
  tent:(x,y,ang=0)=>`<g transform="rotate(${ang} ${x} ${y})">${G.shadow(x,y,40)}<path d="M${x-30} ${y}L${x-44} ${y+3}M${x+30} ${y}L${x+44} ${y+3}" stroke="#8A6440" stroke-width="2" stroke-linecap="round"/><path d="M${x} ${y-48}L${x-44} ${y+3}M${x} ${y-48}L${x+44} ${y+3}" stroke="#5C6A52" stroke-width=".9"/><path d="M${x-30} ${y}L${x} ${y-48}L${x+30} ${y}Z" fill="#F2A64B" ${K}/><path d="M${x} ${y-48}L${x-11} ${y}H${x+11}Z" fill="#B76A1E" ${K1}/><path d="M${x} ${y-48}L${x+11} ${y}L${x+17} ${y-14}Z" fill="#F7C27C" ${K1}/><circle cx="${x}" cy="${y-49}" r="2" fill="#5C6A52"/></g>`,
  pad:(x,y,r=11,f=0)=>`<ellipse cx="${x}" cy="${y}" rx="${r}" ry="${(r*.38).toFixed(1)}" fill="#5FA046" ${K1}/><path d="M${x} ${y}L${x+r+1} ${y-r*.16}L${x+r+1} ${y+r*.16}Z" fill="#6FB7D9"/><path d="M${x} ${y}L${x+r*.8} ${y-r*.14}M${x} ${y}L${x+r*.8} ${y+r*.14}" stroke="#25311F" stroke-width="1"/>${f?`<circle cx="${x-r*.3}" cy="${y-2}" r="3" fill="#F5B7B1" ${K1}/>`:''}`,
  reeds:(x,y)=>`<g transform="translate(${x} ${y})"><path d="M0 0Q-2 -16 -4 -30M5 0Q6 -14 9 -26M-6 0Q-10 -10 -14 -18" stroke="#4E8A3A" stroke-width="2" fill="none" stroke-linecap="round"/><rect x="-6.5" y="-36" width="5" height="11" rx="2.5" fill="#7A563A" ${K1}/><rect x="6.5" y="-32" width="5" height="10" rx="2.5" fill="#7A563A" ${K1}/></g>`,
  tuft:(x,y,s=1)=>`<g class="dec" data-b="${x.toFixed(1)},${y.toFixed(1)},${(9*s).toFixed(1)},${(14*s).toFixed(1)}" transform="translate(${x} ${y}) scale(${s})"><path d="M-9 0q2-9 4-12q1 7 3 12q2-12 6-14q-2 8 3 14z" fill="#6E9F49"/></g>`,
  flower:(x,y,c)=>`<g class="dec" data-b="${x.toFixed(1)},${y.toFixed(1)},6,22" transform="translate(${x} ${y})"><g class="sway" style="animation-delay:-${(x%7)/2}s"><path d="M0 0V-12" stroke="#4E8A3A" stroke-width="1.6"/><g fill="${c}" ${K1}><circle cx="0" cy="-18" r="3.2"/><circle cx="-4" cy="-14" r="3.2"/><circle cx="4" cy="-14" r="3.2"/><circle cx="0" cy="-11.5" r="3"/></g><circle cx="0" cy="-14.5" r="2" fill="#FFD45C"/></g></g>`,
  scatter:(seed,x1,x2,y1,y2,n,avoid=[])=>{const r=rng(seed);let s='';const cols=['#F5B7B1','#FFFFFF','#C9B3F2','#FFD45C'];const placed=[];for(let i=0;i<n;i++){const x=x1+r()*(x2-x1),y=y1+r()*(y2-y1);if(avoid.some(([a,b])=>x>a&&x<b))continue;if(placed.some(([px,py])=>Math.abs(px-x)<20&&Math.abs(py-y)<26))continue;placed.push([x,y]);s+=r()<.45?G.flower(x,y,cols[i%4]):G.tuft(x,y,.8+r()*.5);}return s;},
  path:(d,w=24,c='#DCC594')=>(Z.line(d,w+14),'')+`<path d="${d}" fill="none" stroke="#C3A874" stroke-width="${w+4}" stroke-linecap="round"/><path d="${d}" fill="none" stroke="${c}" stroke-width="${w}" stroke-linecap="round"/>`,
  // a row of carrots planted in a tilled strip; ids names the ones the game pulls
  bed:(x1,y1,x2,y2)=>`<path d="M${x1+8} ${y1}H${x2-8}Q${x2} ${y1} ${x2+4} ${y1+10}L${x2+8} ${y2-6}Q${x2+8} ${y2} ${x2} ${y2}H${x1}Q${x1-8} ${y2} ${x1-8} ${y2-6}L${x1-4} ${y1+10}Q${x1} ${y1} ${x1+8} ${y1}Z" fill="#B08B62" stroke="#8B6446" stroke-width="2"/>`,
  bedRow:(x1,x2,y,xs,ids={})=>{
    // carrots are clipped at the soil line, so only leaves and shoulders show until one is pulled up
    const cid='cl'+x1+'_'+y;
    let s=`<clipPath id="${cid}"><rect x="${x1-20}" y="${y-80}" width="${x2-x1+40}" height="${80+2}"/></clipPath><g clip-path="url(#${cid})">`+xs.map(x=>G.carrot(x,y+3,ids[x]||'')).join('')+'</g>';
    // a mounded row of tilled soil: rounded top, darker furrow line underneath, a few clods
    s+=`<path d="M${x1} ${y+9}Q${x1} ${y-1} ${x1+10} ${y-1}H${x2-10}Q${x2} ${y-1} ${x2} ${y+9}Q${(x1+x2)/2} ${y+13} ${x1} ${y+9}Z" fill="#7A563A" ${K1}/>`;
    s+=`<path d="M${x1+6} ${y+2}Q${(x1+x2)/2} ${y-1} ${x2-6} ${y+2}" stroke="#94704F" stroke-width="2" fill="none" stroke-linecap="round"/>`;
    for(let x=x1+11;x<x2-8;x+=15)s+=`<ellipse cx="${x}" cy="${y+6+(x%3)}" rx="2" ry="1.2" fill="#5E412B"/>`;
    return s;
  },
  carrot:(x,y,id,d=0)=>{const fr=[-38,-16,4,22,40].map((a,i)=>{const L=i%2?17:21,r=a*Math.PI/180,ex=Math.sin(r)*L,ey=-Math.cos(r)*L-6;const lf=[.45,.7,.95].map(t=>{const px=ex*t,py=-6+(ey+6)*t;return `<ellipse cx="${(px+Math.cos(r)*2.6).toFixed(1)}" cy="${(py+Math.sin(r)*2.6).toFixed(1)}" rx="2.6" ry="1.5" transform="rotate(${a} ${(px+Math.cos(r)*2.6).toFixed(1)} ${(py+Math.sin(r)*2.6).toFixed(1)})" fill="#4E9A3E"/><ellipse cx="${(px-Math.cos(r)*2.6).toFixed(1)}" cy="${(py-Math.sin(r)*2.6).toFixed(1)}" rx="2.6" ry="1.5" transform="rotate(${a} ${(px-Math.cos(r)*2.6).toFixed(1)} ${(py-Math.sin(r)*2.6).toFixed(1)})" fill="#3D7A33"/>`;}).join('');return `<path d="M0 -6Q${(ex*.4).toFixed(1)} ${(-6+(ey+6)*.5).toFixed(1)} ${ex.toFixed(1)} ${ey.toFixed(1)}" stroke="#3D7A33" stroke-width="1.4" fill="none" stroke-linecap="round"/>${lf}`;}).join('');return `<g ${id?`id="${id}"`:''} class="crt" style="transition-delay:${d}ms"><g transform="translate(${x} ${y})">${fr}<path d="M-7 -6Q0 -10 7 -6Q6 8 1 22Q0 23 -1 22Q-6 8 -7 -6Z" fill="#E2681C" ${K1}/><path d="M-4 2h4M1 8h3M-2 14h2" stroke="#B04C12" stroke-width="1.4"/><path d="M-4 -5q0 6 1 10" stroke="#F4A06A" stroke-width="1.6" fill="none" stroke-linecap="round"/></g></g>`;},
  pickets:(x1,x2,y,skip=[])=>{let s='';for(let x=x1;x<=x2;x+=13){if(skip.some(([a,b])=>x>a&&x<b))continue;s+=`<path d="M${x-4} ${y}V${y-30}l4-6 4 6V${y}z" fill="#F3EBDD" ${K1}/>`;}return s;},
  post:(x,y,h=44)=>`<rect x="${x-4.5}" y="${y-h}" width="9" height="${h}" fill="#EFE5D3" ${K1}/><path d="M${x-6} ${y-h}h12l-2 -4h-8z" fill="#EFE5D3" ${K1}/>`,
  rails:(x1,x2,y)=>`<rect x="${x1-6}" y="${y-24}" width="${x2-x1+12}" height="5" fill="#E4D8C2" ${K1}/><rect x="${x1-6}" y="${y-11}" width="${x2-x1+12}" height="5" fill="#E4D8C2" ${K1}/>`,
  sign:(x,y,txt,dir=1,id='')=>(Z.rect(x-32,y-50,64,52),'')+`<g ${id?`id="${id}"`:''}><g transform="translate(${x} ${y})"><rect x="-3" y="-40" width="6" height="40" fill="#8A5A3B" ${K1}/><path d="${dir>0?'M-26 -46H18L28 -38L18 -30H-26Z':'M26 -46H-18L-28 -38L-18 -30H26Z'}" fill="#E9C893" ${K}/><text x="${dir>0?-3:3}" y="-34" text-anchor="middle" font-family="Fredoka,sans-serif" font-weight="600" font-size="${txt.length<3?15:10}" fill="#25311F">${txt}</text></g></g>`
};

/* the other animals; side views face right, feet at 0,0 */
const NPC_ART={
 turtle:`<g class="leg-b"><ellipse cx="-12" cy="-4" rx="5" ry="5" fill="#8CC56B" ${K}/></g><path d="M-22 -8l-7 3 6 2z" fill="#8CC56B" ${K1}/>
  <path d="M-21 -7Q-20 -33 1 -33Q21 -32 23 -7Z" fill="#5E8F3E" ${K}/><path d="M-10 -8l3-12h12l4 12M-7 -20l-6-6M14 -20l5-6M-4 -20l2-10h8l2 10" fill="none" stroke="#3F6B2A" stroke-width="1.6" stroke-linejoin="round"/>
  <ellipse cx="1" cy="-8" rx="23" ry="4" fill="#C9A86A" ${K}/>
  <g class="leg-f"><ellipse cx="13" cy="-4" rx="5" ry="5" fill="#8CC56B" ${K}/></g>
  <path d="M18 -10Q22 -18 28 -20" stroke="#25311F" stroke-width="11.5" stroke-linecap="round" fill="none"/><path d="M18 -10Q22 -18 28 -20" stroke="#8CC56B" stroke-width="8" stroke-linecap="round" fill="none"/>
  <circle cx="30" cy="-21" r="8" fill="#8CC56B" ${K}/><circle class="eye-o" cx="32.5" cy="-23" r="1.9" fill="#25311F"/><path d="M31 -17q3 2 6-1" fill="none" stroke="#25311F" stroke-width="1.3" stroke-linecap="round"/><circle cx="29" cy="-18.5" r="1.8" fill="#F5B7B1"/>`,
 hedgehog:`<g class="leg-b"><ellipse cx="-9" cy="-3" rx="5" ry="3.5" fill="#6B4A33" ${K1}/></g>
  <path d="M-24 -10L-30 -16L-23 -20L-29 -27L-20 -28L-22 -36L-13 -33L-11 -42L-4 -36L1 -44L6 -36L11 -41L12 -32L4 -18Z" fill="#7A5638" ${K}/>
  <ellipse cx="2" cy="-14" rx="18" ry="12" fill="#E8C9A0" ${K}/>
  <path d="M-22 -12Q-18 -34 4 -34Q8 -24 4 -14Q-6 -6 -22 -12Z" fill="#7A5638" ${K}/>
  <path d="M16 -18Q26 -16 28 -12Q22 -9 16 -9Z" fill="#E8C9A0" ${K}/><circle cx="28.5" cy="-12.5" r="2.4" fill="#25311F"/>
  <circle class="eye-o" cx="14" cy="-19" r="2" fill="#25311F"/><circle cx="12" cy="-13" r="2.2" fill="#F5B7B1"/>
  <g class="leg-f"><ellipse cx="10" cy="-3" rx="5" ry="3.5" fill="#6B4A33" ${K1}/></g>`,
 fox:`<path d="M-16 -16Q-38 -22 -40 -40Q-30 -30 -20 -26Q-26 -18 -16 -16Z" fill="#E8772E" ${K}/><path d="M-40 -40Q-38 -30 -31 -28L-34 -36Z" fill="#fff"/>
  <g class="leg-b"><rect x="-13" y="-14" width="6" height="14" rx="3" fill="#5A3A2A" ${K1}/></g>
  <ellipse cx="-2" cy="-18" rx="17" ry="10" fill="#E8772E" ${K}/><path d="M6 -12Q10 -22 14 -24L14 -12Z" fill="#fff"/>
  <g class="leg-f"><rect x="7" y="-14" width="6" height="14" rx="3" fill="#5A3A2A" ${K1}/></g>
  <path d="M11 -40L14 -50L19 -41M18 -41L24 -49L25 -38" fill="#E8772E" ${K}/>
  <path d="M8 -32Q10 -42 20 -40Q28 -36 36 -30Q30 -24 22 -24Q10 -24 8 -32Z" fill="#E8772E" ${K}/><path d="M22 -24Q30 -25 36 -30Q30 -27 22 -27Z" fill="#fff"/>
  <circle cx="36" cy="-30" r="2.2" fill="#25311F"/><path class="eye-o" d="M21 -34q2-2 4 0" fill="none" stroke="#25311F" stroke-width="2" stroke-linecap="round"/>`,
 owl:`<ellipse cx="-14" cy="-20" rx="6" ry="12" fill="#7B5236" ${K} transform="rotate(12 -14 -20)"/><ellipse cx="14" cy="-20" rx="6" ry="12" fill="#7B5236" ${K} transform="rotate(-12 14 -20)"/>
  <ellipse cx="0" cy="-20" rx="15" ry="19" fill="#9A6B44" ${K}/><ellipse cx="0" cy="-14" rx="9" ry="11" fill="#E9D3B0"/><path d="M-5 -14l2 2 2-2 2 2 2-2M-4 -8l2 2 2-2 2 2" fill="none" stroke="#B89870" stroke-width="1.2"/>
  <path d="M-13 -34L-12 -44L-5 -36M13 -34L12 -44L5 -36" fill="#9A6B44" ${K}/>
  <circle cx="-6" cy="-28" r="6" fill="#fff" ${K1}/><circle cx="6" cy="-28" r="6" fill="#fff" ${K1}/><g class="eye-o"><circle cx="-5" cy="-28" r="2.8" fill="#25311F"/><circle cx="7" cy="-28" r="2.8" fill="#25311F"/></g>
  <path d="M-2.5 -23L2.5 -23L0 -18Z" fill="#F2A64B" ${K1}/><path d="M-6 0v-3M-4 0v-3M4 0v-3M6 0v-3" stroke="#F2A64B" stroke-width="2" stroke-linecap="round"/>`,
 frog:`<ellipse cx="-14" cy="-3" rx="8" ry="3.5" fill="#5FA046" ${K1}/><ellipse cx="14" cy="-3" rx="8" ry="3.5" fill="#5FA046" ${K1}/>
  <ellipse cx="0" cy="-12" rx="18" ry="12" fill="#6CB34F" ${K}/><ellipse cx="0" cy="-8" rx="11" ry="7" fill="#D6EBB0"/>
  <circle cx="-9" cy="-24" r="6.5" fill="#6CB34F" ${K}/><circle cx="9" cy="-24" r="6.5" fill="#6CB34F" ${K}/>
  <g class="eye-o"><circle cx="-9" cy="-25" r="3.8" fill="#fff"/><circle cx="9" cy="-25" r="3.8" fill="#fff"/><circle cx="-8.5" cy="-25" r="2" fill="#25311F"/><circle cx="9.5" cy="-25" r="2" fill="#25311F"/></g>
  <path d="M-8 -15q8 6 16 0" fill="none" stroke="#25311F" stroke-width="1.6" stroke-linecap="round"/><circle cx="-12" cy="-14" r="2" fill="#F5B7B1"/><circle cx="12" cy="-14" r="2" fill="#F5B7B1"/>`
};

/* full-body bunny, side view, feet at 0,0, facing right */
const bunnyBody=`<g class="leg-b"><ellipse cx="-12" cy="-12" rx="10" ry="9" fill="#fff" ${K}/><ellipse cx="-4" cy="-3" rx="10" ry="3.6" fill="#fff" ${K}/></g>
<circle cx="-22" cy="-22" r="6" fill="#fff" ${K}/>
<ellipse cx="-3" cy="-21" rx="18" ry="14" fill="#fff" ${K}/>
<g class="leg-f"><rect x="5" y="-16" width="7" height="14" rx="3.5" fill="#fff" ${K}/><ellipse cx="11" cy="-2.6" rx="6" ry="3" fill="#fff" ${K}/></g>
<g class="ears"><g transform="rotate(-20 6 -48)"><ellipse cx="6" cy="-60" rx="4.8" ry="13" fill="#fff" ${K}/><ellipse cx="6" cy="-60" rx="2" ry="9" fill="#F5B7B1"/></g><g transform="rotate(4 12 -48)"><ellipse cx="13" cy="-61" rx="4.8" ry="13" fill="#fff" ${K}/><ellipse cx="13" cy="-61" rx="2" ry="9" fill="#F5B7B1"/></g></g>
<circle cx="13" cy="-38" r="12.5" fill="#fff" ${K}/>
<g class="eye-o"><circle cx="18" cy="-40" r="2.3" fill="#25311F"/><circle cx="18.7" cy="-40.8" r=".8" fill="#fff"/></g>
<path class="eye-h" d="M15.5 -39.5q2.5-3 5 0" fill="none" stroke="#25311F" stroke-width="1.8" stroke-linecap="round"/>
<circle cx="15" cy="-33" r="2.8" fill="#F5B7B1"/><circle cx="25" cy="-36" r="1.9" fill="#E58E8A"/>
<path d="M22 -33l6 1M22 -35l6-2" stroke="#25311F" stroke-width=".9"/>
<path class="sweat" d="M2 -50q3 4 0 6q-3-2 0-6z" fill="#8FD0EE" stroke="#25311F" stroke-width="1"/>`;