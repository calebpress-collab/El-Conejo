/* ============ PLAY EXTRAS: hints, listening, free taps ============ */
// a tap only counts as a translation when the chunk holds a word from this level's lesson
function tapCounts(text){const n=' '+norm(text)+' ';return play.lessonWords.some(w=>n.includes(' '+w+' ')||(w.includes(' ')&&n.includes(w)));}
function hintBtn(){return play.noHints?'':`<button class="btn small hintb" id="hint" type="button">${t('hintBtn')}</button>`;}
function wireHint(){
  const b=$('#hint');if(!b)return;
  const p=play, n=p.l.nodes[p.idx];
  b.onclick=()=>{
    if(p.busy)return;
    p.hints++;hud();sfx('click');
    if(n.t==='say'){
      // remove one wrong line
      const opts=p.opts[p.idx], i=opts.findIndex((o,j)=>!o.ok&&!p.tried.has(j));
      if(i>=0){p.tried.add(i);const c=$(`#controls .choice[data-i="${i}"]`);if(c){c.disabled=true;c.classList.add('struck');}}
      if(opts.filter((o,j)=>!o.ok&&!p.tried.has(j)).length===0)b.disabled=true;
    }else{
      // first time: the first letter of every word; second time: the whole first word too
      const ans=n.say[tgt()].replace(/[¿?¡!.,]/g,'').split(' ');
      p.hintStep=(p.hintStep||0)+1;
      const th=$('#th');th.hidden=false;
      th.textContent=p.hintStep===1?ans.map(w=>w[0]+'…').join(' '):ans.map((w,i)=>i===0?w:w[0]+'…').join(' ');
      if(p.hintStep>=2)b.disabled=true;
    }
  };
}
// the line is heard, not read: the bubble shows a play button until the player answers
function npcListen(line){
  const nb=$('#nb'), text=parseLine(line).map(c=>c[tgt()]).join(' ');
  $('#bb').hidden=true;nb.hidden=false;nb.classList.remove('confused');
  nb.innerHTML=`<span class="who">${esc(play.l._npc[tgt()])}</span><span class="listenrow"><button class="speak big" data-speak="${esc(text)}" aria-label="${t('hearAgain')}">${speakerIcon}</button><button class="speak slowb" data-slow="${esc(text)}" aria-label="${t('slow')}">${slowIcon}</button><span class="muted">${t('hearAgain')}</span></span>`;
  wireSpeak(nb);placeBubbles();pop(nb);
  later(()=>speak(text),350);
}
function chooseListen(i){
  const p=play;if(p.busy)return;
  p.busy=true;
  const o=p.opts[p.idx][i], n=p.l.nodes[p.idx];
  const heard=parseLine(n.line).map(c=>c[tgt()]).join(' ');
  if(o.ok){
    credit();sfx('ok');npcLine(n.line,p.idx);
    showVerdict(t('yourChoice'),o.text,`<div class="fb good"><b>${t('nice')}</b><span class="ans">${t('heardLine')} <b>${esc(heard)}</b></span></div>`);
    later(()=>{react(p.N,'happy');fx(p.N,'♪','#3D7A33');mood('happy');},400);
    later(advance,2200);
  }else{
    p.tried.add(i);
    later(()=>{react(p.N,'confused');fx(p.N,'?');mood('sad');},300);
    wrongVerdict(t('yourChoice'),o.text,esc(o.fb||t('notUnderstood')),()=>{if(canSpeak)npcListen(n.line);else npcLine(n.line,p.idx);mood(null);},p.misses>=1?heard:null);
    p.enter=null;
    later(()=>{p.busy=false;p.enter=p.armed;},900);
  }
}

/* ============ TITLE ============ */
function renderTitle(){
  show(`<div class="wrap title-screen">
    <div class="hero-art">${bunnySvg()}${carrotSvg()}</div>
    <h1>El <span>Conejo</span></h1>
    <p class="muted">Help the bunny bring carrots to the festival. Ayuda al conejo a llevar zanahorias a la fiesta.</p>
    <div class="lang-pick">
      <button class="lang-card" data-t="es"><small>I speak English</small><b>Learn Spanish</b></button>
      <button class="lang-card" data-t="en"><small>Hablo español</small><b>Aprender inglés</b></button>
    </div></div>`);
  app.querySelectorAll('[data-t]').forEach(b=>b.onclick=()=>{save.target=b.dataset.t;persist();sfx('click');renderMap();});
}

/* ============ OVERWORLD MAP ============ */
function worldBanner(W){
  const k='wb'+W.id, w=400;
  const houses=Array.from({length:7},(_,i)=>{const x=20+i*56,h=22+(i*13)%14,c=['#F3E3C3','#E8D2B0','#F2D49B'][i%3];return `<rect x="${x}" y="${78-h}" width="40" height="${h}" fill="${c}" stroke="#25311F" stroke-width="1.4"/><path d="M${x-4} ${78-h}L${x+20} ${62-h}L${x+44} ${78-h}Z" fill="#B0402E" stroke="#25311F" stroke-width="1.4"/><rect x="${x+15}" y="${66}" width="10" height="12" fill="#6E4630"/>`;}).join('');
  const towers=Array.from({length:9},(_,i)=>{const x=8+i*44,h=30+(i*17)%34;return `<rect x="${x}" y="${78-h}" width="34" height="${h}" fill="${['#9DC3E6','#C9D6E3','#E8B98A'][i%3]}" stroke="#25311F" stroke-width="1.4"/>${Array.from({length:Math.floor(h/12)},(_,r)=>`<rect x="${x+6}" y="${78-h+5+r*12}" width="6" height="6" fill="#FDFEF8"/><rect x="${x+21}" y="${78-h+5+r*12}" width="6" height="6" fill="#FDFEF8"/>`).join('')}`;}).join('');
  const parts={1:`${G.fence(30,150,78)}${G.tree(330,80,.55)}`,2:houses,3:`${G.pine(60,80,.6)}${G.pine(110,80,.75)}${G.pine(330,80,.7)}${G.pine(250,82,.5)}`,4:towers};
  const sk={1:['#B9E0F2','#EAF6E6','#A9D27F','#86B95C'],2:['#FCE0C0','#FBF2DF','#D9CDB4','#C9BB9C'],3:['#BCD8CB','#E1EEDC','#93C273','#74A957'],4:['#BFDDF0','#EEF1EC','#B9C3A6','#9FAE8A']}[W.id];
  ZN=[];
  return `<svg class="wbanner" viewBox="0 0 400 90" preserveAspectRatio="xMidYMid slice" aria-hidden="true">${G.sky(k,...sk)}<rect width="400" height="90" fill="url(#sk${k})"/>${G.sun(360,24).replace(/r="34"/,'r="16"').replace(/r="24"/,'r="11"')}<rect y="72" width="400" height="18" fill="url(#gd${k})"/>${parts[W.id]||''}</svg>`;
}
function trailSvg(W){
  // a winding trail through the world's levels
  const n=W.levels.length, pts=W.levels.map((l,i)=>[40+i*(320/(n-1)),i%2?78:34]);
  let d=`M${pts[0][0]} ${pts[0][1]}`;for(let i=1;i<n;i++){const [x0,y0]=pts[i-1],[x1,y1]=pts[i];d+=` C${x0+20} ${y0} ${x1-20} ${y1} ${x1} ${y1}`;}
  return {pts,svg:`<svg class="trailsvg" viewBox="0 0 400 112" aria-hidden="true"><path d="${d}" fill="none" stroke="#C3A874" stroke-width="12" stroke-linecap="round"/><path d="${d}" fill="none" stroke="#E3D2A8" stroke-width="8" stroke-linecap="round" stroke-dasharray="1 12"/></svg>`};
}
function renderMap(confirming){
  const due=dueWords().length, st=streakNow();
  const cur=LEVELS.find(l=>!starsOf(l.id)&&unlocked(l.id));
  const worlds=WORLDS.map(W=>{
    const open=worldUnlocked(W.id), done=W.levels.filter(l=>starsOf(l.id)).length;
    const {pts,svg}=trailSvg(W);
    const nodes=W.levels.map((l,i)=>{const op=unlocked(l.id),s=starsOf(l.id),c=cur&&cur.id===l.id;
      return `<button class="lnode${s?' done':''}${c?' current':''}${l.boss?' boss':''}${me().hard[l.id]?' gold':''}" data-id="${l.id}" ${op?'':'disabled'} style="left:${pts[i][0]/4}%;top:${pts[i][1]/1.12}%" aria-label="${esc(l.title[tgt()])}">${op?(l.boss?'★':i+1):'·'}${s?`<span class="ns">${'●'.repeat(s)}${'○'.repeat(3-s)}</span>`:''}${c?`<span class="here">${bunnySvg()}</span>`:''}</button>`;}).join('');
    return `<section class="wcard${open?'':' wlocked'}" data-w="${W.id}">
      ${worldBanner(W)}
      <div class="whead"><div><div class="eyebrow">${t('worldOf')} ${W.id}</div><h2>${esc(W.name[tgt()])}</h2><small class="muted">${esc(W.name[nat()])}</small></div><span class="wcount">${done}/${W.levels.length}</span></div>
      <div class="trail2">${svg}${nodes}</div>
      ${open?'':`<p class="muted lockline">🔒 ${t('locked')}</p>`}
    </section>`;}).join('');
  show(`<div class="wrap">
    <div class="top"><div class="brand">El <span>Conejo</span></div><span class="spacer"></span>
      <span class="eyebrow">${t('learning')}</span><button class="btn small" id="snd">${t('sound')}: ${save.sound?t('on_'):t('off_')}</button><button class="btn small" id="sw">${t('switchLang')}</button></div>
    <div class="panel reviewcard"><div class="rv-l"><span class="streakn">${st}</span><small>${t('streak')}</small></div>
      <div class="rv-m"><b>${t('reviewTitle')}</b><span class="muted">${due?`${due} ${t(due===1?'reviewDue1':'reviewDue')}`:t('reviewNone')}</span></div>
      <button class="btn primary" id="rev" ${Object.keys(me().words).length?'':'disabled'}>${t('reviewGo')}</button></div>
    <p class="eyebrow maptitle">${t('mapTitle')}</p>
    ${worlds}
    ${confirming?`<div class="confirm"><b>${t('resetQ')}</b><div class="row"><button class="btn small primary" id="yes">${t('erase')}</button><button class="btn small" id="no">${t('cancel')}</button></div></div>`:''}
    <div class="row"><span class="save-note">${t('saveNote')}</span><span class="spacer"></span><button class="link" id="reset">${t('reset')}</button></div>
  </div>`);
  app.querySelectorAll('.lnode[data-id]').forEach(b=>b.onclick=()=>{sfx('click');openLevel(b.dataset.id);});
  $('#sw').onclick=()=>{save.target=null;persist();renderTitle();};
  $('#snd').onclick=()=>{save.sound=!save.sound;persist();renderMap();};
  $('#rev').onclick=()=>startReview();
  $('#reset').onclick=()=>renderMap(true);
  if(confirming){$('#yes').onclick=()=>{save.lang[tgt()]=blankSave().lang[tgt()];persist();renderMap();};$('#no').onclick=()=>renderMap();}
  const c=app.querySelector('.lnode.current');if(c&&!confirming)c.scrollIntoView({block:'center'});
}
function openLevel(id){
  const l=levelById(id);
  if(!me().intro[l.world]){return renderStory(WORLDS[l.world-1],'intro',()=>{me().intro[l.world]=true;persist();renderIntro(id);});}
  renderIntro(id);
}
function renderStory(W,which,next){
  const npcs=W.cast||[];
  show(`<div class="wrap"><div class="panel story">
    ${worldBanner(W)}
    <div class="eyebrow">${t('worldOf')} ${W.id}</div><h2>${esc(W.name[tgt()])}</h2>
    <div class="cast">${npcs.map(k=>`<svg viewBox="-40 -80 80 86" aria-hidden="true"><g>${NPC_ART[NPCS[k].art]}</g></svg>`).join('')}</div>
    <p class="storytext">${esc(W[which][nat()])}</p>
    <button class="btn primary" id="go">${which==='intro'?t('storyBegin'):t('storyNext')}</button>
  </div></div>`);
  $('#go').onclick=next;
  keyHandler=e=>{if(e.key==='Enter'){e.preventDefault();next();}};
}

/* ============ LEVEL INTRO ============ */
function renderIntro(id){
  const l=levelById(id), best=starsOf(id), npc=NPCS[l.npc], hard=l.boss||l.diff==='hard';
  show(`<div class="wrap"><div class="panel">
    <div class="intro-head"><svg class="npc-big" viewBox="-44 -84 88 90" aria-hidden="true">${NPC_ART[npc.art]}</svg><div>
      <div class="eyebrow">${t('worldOf')} ${l.world} · ${t('level')} ${l.num}${l.boss?' · '+t('boss'):''}</div><h2>${esc(l.title[tgt()])}</h2><p class="muted">${esc(l.title[nat()])}</p></div></div>
    <div class="facts">
      <div class="fact"><small>${t('topic')}</small>${esc(l.theme[nat()])}</div>
      <div class="fact"><small>${t('difficulty')}</small><span class="chip ${l.boss?'hard':l.diff}">${l.boss?t('boss'):t(l.diff)}</span></div>
      <div class="fact"><small>${t('best')}</small>${stars(best)}${me().hard[id]?` <span class="goldtag">${t('hardDone')}</span>`:''}</div>
    </div>
    <p>${hard?t('off'):t('on')}.${hard?'':` <span class="muted">${t('translatedCounts')}</span>`}</p>
    <div class="row"><button class="btn primary" id="go">${t('startLesson')}</button>
      ${best?`<button class="btn" id="skip">${t('skipLesson')}</button>`:''}
      ${best&&!hard?`<button class="btn" id="hardm" title="${esc(t('hardDesc'))}">${t('hardMode')}</button>`:''}
      <span class="spacer"></span><button class="link" id="back">${t('back')}</button></div>
  </div></div>`);
  $('#go').onclick=()=>renderStudy(id);
  if(best)$('#skip').onclick=()=>startLevel(id);
  if($('#hardm'))$('#hardm').onclick=()=>startLevel(id,true);
  $('#back').onclick=()=>renderMap();
}

/* ============ LESSON and REVIEW (one quiz engine) ============ */
let quiz=null;
function reviewExtras(l,n=3){
  // words from earlier levels that are due come back inside this lesson
  const own=new Set(l.lesson.map(wkey));
  return dueWords().filter(r=>r.lv!==l.id&&!own.has(norm(r[tgt()]))).slice(0,n).map(r=>({it:{es:r.es,en:r.en,alt:r.alt},lv:r.lv,review:true}));
}
function renderStudy(id){
  const l=levelById(id), extra=reviewExtras(l);
  show(`<div class="wrap"><div class="panel">
    <div><div class="eyebrow">${t('lesson')} · ${l.world}-${l.num}</div><h2>${esc(l.title[tgt()])}</h2></div>
    <p class="muted">${t('study')}</p>
    <div class="vocab">${l.lesson.map(w=>`<div class="word"><div><b>${esc(w[tgt()])}</b><span>${esc(w[nat()])}</span></div>${speakBtn(w[tgt()])}</div>`).join('')}
    ${extra.map(x=>`<div class="word rv"><div><em>${t('reviewWord')}</em><b>${esc(x.it[tgt()])}</b><span>${esc(x.it[nat()])}</span></div>${speakBtn(x.it[tgt()])}</div>`).join('')}</div>
    <div class="row"><button class="btn primary" id="ready">${t('ready')}</button><span class="spacer"></span><button class="link" id="back">${t('back')}</button></div>
  </div></div>`);
  $('#ready').onclick=()=>{
    const items=[...l.lesson.map(it=>({it,lv:l.id})),...extra];
    runQuiz({items,label:`${t('lesson')} · ${l.world}-${l.num}`,sub:`${t('afterLesson')} ${t('level')} ${l.num}: ${l.title[tgt()]}`,done:()=>renderReady(id)});
  };
  $('#back').onclick=()=>renderMap();
}
function startReview(){
  let rec=dueWords().slice(0,12);
  if(rec.length<4)rec=[...rec,...weakWords().filter(r=>!rec.includes(r))].slice(0,8);
  const items=rec.map(r=>({it:{es:r.es,en:r.en,alt:r.alt},lv:r.lv,review:true}));
  if(!items.length)return renderMap();
  show(`<div class="wrap"><div class="panel center">
    <div class="hero-art" style="width:110px">${bunnySvg()}</div><h2>${t('reviewTitle')}</h2><p class="muted" style="max-width:46ch">${t('reviewIntro')}</p>
    <button class="btn primary" id="go">${t('reviewGo')} (${items.length})</button><button class="link" id="back">${t('back')}</button></div></div>`);
  $('#go').onclick=()=>runQuiz({items,label:t('reviewTitle'),sub:'',done:()=>{streakTouch();sfx('win');
    show(`<div class="wrap"><div class="panel center"><div class="hero-art" style="width:110px">${bunnySvg()}${carrotSvg()}</div><h2>${t('reviewDone')}</h2>
      <p><span class="streakn big">${streakNow()}</span> ${t('streakDays')}</p><p class="muted">${items.length} ${t('reviewKept')}</p><button class="btn primary" id="m">${t('map')}</button></div></div>`);
    $('#m').onclick=()=>renderMap();}});
  $('#back').onclick=()=>renderMap();
}
function runQuiz(cfg){
  const its=cfg.items, kinds=['mc','type'];
  if(canSpeak)kinds.push('listen');
  const queue=shuffle(its).map((x,i)=>({...x,kind:kinds[i%kinds.length]}));
  if(its.length>=4)queue.unshift({kind:'match',set:shuffle(its).slice(0,4)});
  quiz={cfg,queue,cleared:0,pool:its.map(x=>x.it)};
  renderQuiz();
}
function distractors(it,n=3){
  const pool=[...quiz.pool,...Object.values(me().words).map(r=>({es:r.es,en:r.en}))].filter(o=>norm(o[tgt()])!==norm(it[tgt()])&&norm(o[nat()])!==norm(it[nat()]));
  const uniq=[];pool.forEach(o=>{if(!uniq.some(u=>norm(u[nat()])===norm(o[nat()])))uniq.push(o);});
  return shuffle(uniq).slice(0,n);
}
function renderQuiz(){
  if(!quiz.queue.length)return quiz.cfg.done();
  const q=quiz.queue[0], total=quiz.cleared+quiz.queue.length, pct=Math.round(100*quiz.cleared/total);
  let body='';
  if(q.kind==='match'){
    const L=shuffle(q.set), Rr=shuffle(q.set);
    body=`<p class="ask">${t('matchIt')}</p><div class="match"><div>${L.map((x,i)=>`<button class="choice mL" data-k="${i}">${esc(x.it[tgt()])}</button>`).join('')}</div><div>${Rr.map((x,i)=>`<button class="choice mR" data-k="${i}">${esc(x.it[nat()])}</button>`).join('')}</div></div>`;
    q.L=L;q.R=Rr;
  }else if(q.kind==='mc'||q.kind==='listen'){
    if(!q.opts)q.opts=shuffle([q.it,...distractors(q.it)]);
    body=q.kind==='mc'?`<p class="ask">${t('whatMeans')}</p><div class="q-prompt">${esc(q.it[tgt()])}${speakBtn(q.it[tgt()])}</div>`
      :`<p class="ask">${t('listenPick')}</p><div class="q-prompt"><button class="speak big" data-speak="${esc(q.it[tgt()])}" aria-label="${t('listen')}">${speakerIcon}</button><button class="speak slowb" data-slow="${esc(q.it[tgt()])}" aria-label="${t('slow')}">${slowIcon}</button></div>`;
    body+=`<div class="choices">${q.opts.map((o,i)=>`<button class="choice" data-i="${i}"><span class="num">${i+1}</span><span>${esc(o[nat()])}</span></button>`).join('')}</div>`;
  }else{
    body=`<p class="ask">${t('typeIt')}</p><div class="q-prompt">${esc(q.it[nat()])}</div>
      <div class="typebox"><input id="ti" autocomplete="off" autocapitalize="off" spellcheck="false" aria-label="${t('typeIt')}"><button class="btn leaf" id="chk">${t('check')}</button></div>${accentKeys()}`;
  }
  show(`<div class="wrap"><div class="panel">
    <div class="row"><span class="eyebrow">${esc(quiz.cfg.label)}</span>${q.review?`<span class="chip rvchip">${t('reviewWord')}</span>`:''}<span class="spacer"></span><span class="muted" style="font-size:14px">${quiz.queue.length} ${t('left')}</span><button class="link" id="qback">${t('back')}</button></div>
    <div class="progress"><i style="width:${pct}%"></i></div>
    ${quiz.cfg.sub?`<p class="muted" style="font-size:14px">${esc(quiz.cfg.sub)}</p>`:''}
    <div id="qbody">${body}</div></div></div>`);
  $('#qback').onclick=()=>renderMap();
  if(q.kind==='listen')later(()=>speak(q.it[tgt()]),300);
  let phase='ask';
  const finish=(ok,note,mine)=>{
    quiz.queue.shift();
    wordResult(q.it,q.lv,ok);
    if(ok){quiz.cleared++;sfx('ok');}else{sfx('bad');quiz.queue.push({...q,kind:q.kind==='type'?'mc':'type',opts:null});}
    const head=yoursHtml(q.kind==='type'?t('yourResponse'):t('yourChoice'),mine);
    if(ok&&!note){phase='done';$('#qbody').innerHTML=head+`<div class="fb good"><b>${t('correct')}</b>${q.kind==='listen'?`<span class="ans"><b>${esc(q.it[tgt()])}</b> = ${esc(q.it[nat()])}</span>`:''}</div>`;later(renderQuiz,q.kind==='listen'?1400:900);return;}
    phase='fb';
    $('#qbody').innerHTML=head+(ok?`<div class="fb good"><b>${t('correct')}</b><span class="ans">${note}</span>`
      :`<div class="fb bad"><b>${t('notQuite')}</b><span class="ans"><b>${esc(q.it[tgt()])}</b> = <b>${esc(q.it[nat()])}</b></span><span>${t('comesBack')}</span>`)
      +`<div class="row"><button class="btn small" id="c">${t('cont')}</button><span class="keyhint"><kbd>Enter</kbd> ${t('pressEnterGo')}</span></div></div>`;
    $('#c').onclick=renderQuiz;
  };
  if(q.kind==='match'){
    let sel=null, left=4;
    const pairOk=(a,b)=>q.L[+a.dataset.k]===q.R[+b.dataset.k];
    const tap=b=>{
      if(b.disabled)return;
      const side=b.classList.contains('mL')?'L':'R';
      if(!sel||sel.side===side){app.querySelectorAll('.match .sel').forEach(x=>x.classList.remove('sel'));sel={b,side};b.classList.add('sel');sfx('click');return;}
      const [a,c]=side==='R'?[sel.b,b]:[b,sel.b];sel.b.classList.remove('sel');sel=null;
      if(pairOk(a,c)){[a,c].forEach(x=>{x.disabled=true;x.classList.add('right');});sfx('ok');if(--left===0){quiz.queue.shift();quiz.cleared++;later(renderQuiz,500);}}
      else{[a,c].forEach(x=>{x.classList.add('wrongpick');setTimeout(()=>x.classList.remove('wrongpick'),500);});sfx('bad');}
    };
    app.querySelectorAll('.match .choice').forEach(b=>b.onclick=()=>tap(b));
  }else if(q.kind==='mc'||q.kind==='listen'){
    const choose=i=>{if(phase!=='ask')return;finish(q.opts[i]===q.it,'',q.opts[i][nat()]);};
    app.querySelectorAll('.choice').forEach(b=>b.onclick=()=>choose(+b.dataset.i));
    keyHandler=e=>{
      if(phase==='ask'&&/^[1-4]$/.test(e.key)&&+e.key<=q.opts.length){e.preventDefault();choose(+e.key-1);}
      else if(phase==='fb'&&e.key==='Enter'){e.preventDefault();renderQuiz();}
    };
  }else{
    const inp=$('#ti');inp.focus();wireAccents(inp);
    const check=()=>{
      if(phase!=='ask')return;
      const v=inp.value.trim();if(!v){inp.focus();return;}
      const g=grade(v,[q.it[tgt()],...((q.it.alt&&q.it.alt[tgt()])||[])]);
      finish(g.ok,g.ok?gradeNote(g):'',v);
    };
    $('#chk').onclick=check;
    keyHandler=e=>{if(e.key!=='Enter')return;e.preventDefault();if(phase==='ask')check();else if(phase==='fb')renderQuiz();};
  }
}
function accentKeys(){
  if(tgt()!=='es')return '';
  return `<div class="accents">${['á','é','í','ó','ú','ñ','¿','¡'].map(c=>`<button type="button" data-ch="${c}">${c}</button>`).join('')}</div>`;
}
function wireAccents(inp){
  app.querySelectorAll('[data-ch]').forEach(b=>b.onclick=()=>{
    if(inp.disabled)return;
    const s=inp.selectionStart??inp.value.length,e=inp.selectionEnd??inp.value.length;
    inp.setRangeText(b.dataset.ch,s,e,'end');inp.focus();
  });
}
function renderReady(id){
  show(`<div class="wrap"><div class="panel center">
    <div class="hero-art" style="width:120px">${bunnySvg()}</div>
    <h2>${t('lessonDone')}</h2><p class="muted" style="max-width:52ch">${t('scoring')}</p>
    <button class="btn primary" id="go">${t('begin')}</button></div></div>`);
  $('#go').onclick=()=>startLevel(id);
  keyHandler=e=>{if(e.key==='Enter'){e.preventDefault();startLevel(id);}};
}

/* ============ RESULTS ============ */
const catStars=x=>x>=.85?3:x>=.6?2:1;
function renderResults(){
  const p=play, l=p.l, n=l.nodes.length;
  const acc=p.first/n, used=p.reveals.size+p.hints;
  const trScore=p.hard?null:clamp(1-used/Math.max(4,p.revealable*0.35));
  const timeScore=p.elapsed<=p.par?1:clamp(1-(p.elapsed-p.par)/(2*p.par));
  const score=p.hard?(0.8*acc+0.2*timeScore):(0.6*acc+0.25*trScore+0.15*timeScore);
  const st=score>=.85?3:score>=.6?2:1;
  me().stars[l.id]=Math.max(starsOf(l.id),st);
  if(p.hardMode)me().hard[l.id]=true;
  // the level's words have now been used in a real conversation
  l.lesson.forEach(it=>wordRec(it,l.id));
  persist();sfx('win');
  const idx=levelIndex(l.id), nextL=LEVELS[idx+1], worldEnd=l.boss;
  show(`<div class="wrap"><div class="panel center">
    <div class="eyebrow">${l.world}-${l.num} · ${esc(l.title[tgt()])}${p.hardMode?' · '+t('hardMode'):''}</div>
    <h2>${t('reached')}</h2>
    ${stars(st,'big-stars')}
    <div class="breakdown" style="width:100%;text-align:left">
      <div class="brow"><div><b>${t('accuracy')}</b><small>${p.first}/${n} ${t('firstTry')}</small></div><span class="val">${Math.round(acc*100)}%</span>${stars(catStars(acc))}</div>
      <div class="brow"><div><b>${t('translations')}</b><small>${p.hard?t('noTr'):`${p.reveals.size} ${t('used')} · ${p.hints} ${t('hintUsed')}`}</small></div><span class="val">${p.hard?'—':used}</span>${p.hard?'<span></span>':stars(catStars(trScore))}</div>
      <div class="brow"><div><b>${t('time')}</b><small>${t('target')} ${fmt(p.par)}</small></div><span class="val">${fmt(p.elapsed)}</span>${stars(catStars(timeScore))}</div>
    </div>
    <div class="cando"><b>${t('canNow')}:</b> ${esc(l.can[nat()])}</div>
    <div class="tip"><b>${t('tipTitle')}</b><p>${l.note[nat()]}</p></div>
    <details class="lw"><summary>${t('wordsLearned')} (${l.lesson.length})</summary><div class="vocab">${l.lesson.map(w=>`<div class="word"><div><b>${esc(w[tgt()])}</b><span>${esc(w[nat()])}</span></div>${speakBtn(w[tgt()])}</div>`).join('')}</div></details>
    ${!nextL&&worldEnd?`<p class="muted">${t('allDone')}</p>`:''}
    <div class="row" style="justify-content:center">
      ${nextL?`<button class="btn primary" id="next">${t('next')}</button>`:''}
      <button class="btn" id="replay">${t('replay')}</button><button class="btn" id="map">${t('map')}</button></div>
  </div></div>`);
  const goNext=()=>{if(worldEnd){const W=WORLDS[l.world-1];renderStory(W,'outro',()=>nextL?openLevel(nextL.id):renderMap());}else openLevel(nextL.id);};
  if(nextL)$('#next').onclick=goNext;
  $('#replay').onclick=()=>startLevel(l.id,p.hardMode);
  $('#map').onclick=()=>{if(worldEnd&&!me().intro['o'+l.world]){me().intro['o'+l.world]=true;persist();renderStory(WORLDS[l.world-1],'outro',renderMap);}else renderMap();};
}

/* ============ BOOT ============ */
(async()=>{
  show(`<div class="wrap title-screen"><div class="hero-art">${bunnySvg()}</div><p class="muted">…</p></div>`);
  try{await loadContent();}catch(e){show(`<div class="wrap"><div class="panel"><h2>El Conejo</h2><p>The levels could not load (${esc(e.message)}). Reload the page to try again.</p></div></div>`);return;}
  if(save.target==='es'||save.target==='en')renderMap();else renderTitle();
})();
