/* ============ MORE SCENERY (beta 2, worlds 3 and 4) ============ */
Object.assign(G,{
  // a footbridge over a river with one loose plank; x is the river's middle
  brokenBridge:(x,id='bridge')=>{const d=x-755;const river=`M${744+d} 176C${738+d} 206 ${716+d} 232 ${706+d} 256S${690+d} 290 ${688+d} 300H${824+d}C${820+d} 288 ${808+d} 270 ${802+d} 252S${778+d} 204 ${770+d} 176Z`;Z.d(river);Z.line(`M${757+d} 176C${750+d} 220 ${744+d} 256 ${756+d} 300`,112);
    return `<g id="${id}"><g transform="translate(${d} 0)"><path d="M744 176C738 206 716 232 706 256S690 290 688 300H824C820 288 808 270 802 252S778 204 770 176Z" fill="#6FB7D9" ${K1}/><g class="ripple"><path d="M748 200q5-3 10 0M720 280q8-4 16 0M780 284q8-4 16 0" stroke="#fff" stroke-width="2" fill="none" stroke-linecap="round"/></g>
      <rect x="694" y="232" width="7" height="30" fill="#7A4E33" ${K1}/><rect x="808" y="232" width="7" height="30" fill="#7A4E33" ${K1}/><rect x="722" y="236" width="5" height="12" fill="#7A4E33" ${K1}/><rect x="782" y="236" width="5" height="12" fill="#7A4E33" ${K1}/>
      <path d="M697 236H732M778 236H812" stroke="#25311F" stroke-width="5" stroke-linecap="round"/><path d="M697 236H732M778 236H812" stroke="#C49A6C" stroke-width="3" stroke-linecap="round"/>
      <path d="M690 246H736L732 250L737 254H690Z" fill="#C49A6C" ${K1}/><path d="M818 246H774L778 250L772 254H818Z" fill="#C49A6C" ${K1}/><path d="M700 246v8M712 246v8M724 246v8M806 246v8M794 246v8M784 246v8" stroke="#8A6440" stroke-width="1"/>
      <g class="plank" id="plank"><path d="M734 248l6 -1 8 15-6 2z" fill="#C49A6C" ${K1}/></g></g></g>`;},
  // the long grassy hill that rises to the right, from x0 (foot) to x0+830 (top)
  bigHill:(x0)=>{const d=x0-380;return `<g transform="translate(${d} 0)"><path d="M380 300C420 282 440 270 460 266C560 248 660 228 800 212C880 204 940 198 1000 196L1260 194V310H380Z" fill="#B3D48F"/><path d="M380 300C420 282 440 270 460 266C560 248 660 228 800 212C880 204 940 198 1000 196L1260 194" fill="none" stroke="#86AE69" stroke-width="3"/></g>`;},
  // one of the other animals standing still (for crowds and cameo visits); faces right unless flip
  critter:(name,x,y,flip=0,s=1)=>{const n=NPCS[name];Z.rect(x-26*s,y-(n.head+10)*s,52*s,(n.head+12)*s);return `<g transform="translate(${x} ${y}) scale(${flip?-s:s},${s})">${n.fly?'':`<ellipse cx="0" cy="1" rx="${n.sh||20}" ry="4" fill="#1E3B24" opacity=".17"/>`}<g class="bob" style="animation-delay:-${(x%9)/4}s">${NPC_ART[n.art]}</g></g>`;},
  // a sign with a flat board on a post (for words, not arrows)
  board:(x,y,label,id='')=>{const w=Math.max(46,label.length*7+16);Z.rect(x-w/2-2,y-52,w+4,54);return `<g ${idA(id)}><rect x="${x-3}" y="${y-36}" width="6" height="36" fill="#8A5A3B" ${K1}/><rect x="${x-w/2}" y="${y-52}" width="${w}" height="18" rx="3" fill="#E9C893" ${K}/>${txt(x,y-39,label,10.5)}</g>`;},
  // a far-off city in a valley between x1 and x2
  cityFar:(x1,x2)=>{let s='';for(let x=x1;x<x2;x+=26){const h=22+((x*13)%30);s+=`<rect x="${x}" y="${178-h}" width="22" height="${h}" fill="#AEBBC8"/>${Array.from({length:Math.floor(h/10)},(_,r)=>`<rect x="${x+5}" y="${178-h+4+r*10}" width="4" height="4" fill="#D3DDE6"/><rect x="${x+13}" y="${178-h+4+r*10}" width="4" height="4" fill="#D3DDE6"/>`).join('')}`;}return s;},
  // a fallen log lying across a stream
  log:(x1,x2,y,id='log')=>`<g ${idA(id)}><rect x="${x1}" y="${y-9}" width="${x2-x1}" height="12" rx="6" fill="#8A5A3B" ${K}/><path d="M${x1+16} ${y-5}H${x2-30}M${x1+40} ${y-1}H${x2-12}" stroke="#6E4630" stroke-width="1.3" stroke-linecap="round"/><ellipse cx="${x2-2}" cy="${y-3}" rx="4" ry="6" fill="#D9B27C" ${K1}/></g>`,
  // a street running away from the viewer, with a zebra crossing along the sidewalk line; x is its middle, w its width at the front
  crossStreet:(x,w,id='street')=>{const t=w*.42;Z.d(`M${x-t/2} 176L${x-w/2} 300H${x+w/2}L${x+t/2} 176Z`);let z='';for(let i=0;i<Math.floor((w-24)/16);i++){const zx=x-w/2+16+i*16;z+=`<rect x="${zx}" y="252" width="9" height="40" fill="#F4F2EA"/>`;}
    return `<g ${idA(id)}><path d="M${x-t/2} 176L${x-w/2} 300H${x+w/2}L${x+t/2} 176Z" fill="#6B7177"/><path d="M${x-t/2} 176L${x-w/2} 300M${x+t/2} 176L${x+w/2} 300" stroke="#D9D6CC" stroke-width="3"/><path d="M${x} 180V246" stroke="#F3E3A0" stroke-width="2.4" stroke-dasharray="10 9"/>${z}</g>`;},
  // the dark inside of a cave from x1 to x2
  caveInside:(x1,x2)=>`<rect x="${x1}" y="0" width="${x2-x1}" height="300" fill="#3B3A36"/><path d="M${x1} 60Q${(x1+x2)/2} -10 ${x2} 60V0H${x1}Z" fill="#2A2926"/><rect x="${x1}" y="236" width="${x2-x1}" height="64" fill="#57544C"/>`
});
