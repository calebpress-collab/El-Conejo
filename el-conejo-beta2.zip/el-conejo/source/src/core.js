const UI = {
 en:{learning:'Learning Spanish',switchLang:'Switch language',reset:'Reset progress',resetQ:'Erase all stars for Spanish?',erase:'Erase',cancel:'Cancel',
  saveNote:'Progress saves in this browser.',goal:'The carrot patch',level:'Level',easy:'Easy',medium:'Medium',hard:'Hard',
  topic:'Topic',difficulty:'Difficulty',best:'Best',lives:'Lives',translations:'Translations',on:'Tap any word to see it in English',off:'No translations. You are on your own',
  startLesson:'Start lesson',skipLesson:'Skip to level',back:'Back to map',lesson:'Lesson',
  study:'Study these words. Then answer every question correctly to open the level. Wrong answers come back at the end.',
  ready:"I'm ready",whatMeans:'What does this mean?',typeIt:'Type this in Spanish:',check:'Check',correct:'Correct!',
  notQuite:'Not quite.',answer:'Answer:',comesBack:'This one comes back at the end.',cont:'Continue',left:'left',
  accentNote:'Watch the accents:',typoNote:'Small spelling slip. It is spelled:',altNote:'Another way to say it:',
  pressEnter:'to check',pressEnterGo:'to continue',afterLesson:'Finish this lesson to play',
  lessonDone:'Lesson complete',scoring:'The level starts now. Your stars come from accuracy, how many translations you use, and your time. The lesson does not count.',
  begin:'Start level',youSay:'What do you say?',whatDo:'What do you do?',tapPlace:'Tap a place in the scene.',yourReply:'Type your reply in Spanish',say:'Say it',nice:'Nice!',
  notUnderstood:"They didn't understand that.",hint:'Hint: it starts with',tr:'translated',lost:'El Conejo got lost',
  lostBody:'You ran out of lives. The carrots are still waiting.',retry:'Try again',reached:'You reached the carrots!',accuracy:'Accuracy',
  firstTry:'answered right on the first try',time:'Time',target:'target',used:'words translated',noTr:'not available on hard levels',
  next:'Next level',replay:'Replay',map:'Map',allDone:'All five test levels are done. More levels coming soon.',
  translate:'Translate',quit:'Leave level',listen:'Listen',you:'You',yourChoice:'Your choice',yourResponse:'Your response',tryAgain:'Try again',theAnswer:'The answer is:',
  hSerEstar:'“{w}” is a form of <i>ser</i>. For where something is or how someone feels, Spanish uses <i>estar</i>.',hEstarSer:'“{w}” is a form of <i>estar</i>. Here you need <i>ser</i>.',hBe:'“{w}” doesn’t match who you’re talking about. Check am / is / are.',
  hEnding:'“{w}” has the wrong ending. Think about who is doing it.',hSpell:'Check the spelling of “{w}”.',hWrong:'“{w}” isn’t the word you need here. The right word starts with “{c}”.',
  hExtra:'“{w}” doesn’t belong in this answer.',hMissingAfter:'A word is missing after “{p}”. It starts with “{c}”.',hMissingStart:'A word is missing at the start. It starts with “{c}”.'},
 es:{learning:'Aprendiendo inglés',switchLang:'Cambiar idioma',reset:'Borrar progreso',resetQ:'¿Borrar todas las estrellas de inglés?',erase:'Borrar',cancel:'Cancelar',
  saveNote:'El progreso se guarda en este navegador.',goal:'El huerto de zanahorias',level:'Nivel',easy:'Fácil',medium:'Medio',hard:'Difícil',
  topic:'Tema',difficulty:'Dificultad',best:'Mejor',lives:'Vidas',translations:'Traducciones',on:'Toca cualquier palabra para verla en español',off:'Sin traducciones. Estás por tu cuenta',
  startLesson:'Empezar lección',skipLesson:'Ir al nivel',back:'Volver al mapa',lesson:'Lección',
  study:'Estudia estas palabras. Luego responde bien todas las preguntas para abrir el nivel. Las respuestas incorrectas vuelven al final.',
  ready:'Estoy listo',whatMeans:'¿Qué significa esto?',typeIt:'Escribe esto en inglés:',check:'Comprobar',correct:'¡Correcto!',
  notQuite:'No exactamente.',answer:'Respuesta:',comesBack:'Esta pregunta vuelve al final.',cont:'Continuar',left:'pendientes',
  accentNote:'Ojo con los acentos:',typoNote:'Pequeño error de ortografía. Se escribe:',altNote:'Otra forma de decirlo:',
  pressEnter:'para comprobar',pressEnterGo:'para continuar',afterLesson:'Termina esta lección para jugar el',
  lessonDone:'Lección completa',scoring:'El nivel empieza ahora. Tus estrellas dependen de la precisión, cuántas traducciones usas y tu tiempo. La lección no cuenta.',
  begin:'Empezar nivel',youSay:'¿Qué dices?',whatDo:'¿Qué haces?',tapPlace:'Toca un lugar en la escena.',yourReply:'Escribe tu respuesta en inglés',say:'Decirlo',nice:'¡Bien!',
  notUnderstood:'No te entendieron.',hint:'Pista: empieza con',tr:'traducidas',lost:'El Conejo se perdió',
  lostBody:'Te quedaste sin vidas. Las zanahorias te siguen esperando.',retry:'Intentar de nuevo',reached:'¡Llegaste a las zanahorias!',accuracy:'Precisión',
  firstTry:'correctas al primer intento',time:'Tiempo',target:'meta',used:'palabras traducidas',noTr:'no disponible en niveles difíciles',
  next:'Siguiente nivel',replay:'Repetir',map:'Mapa',allDone:'Terminaste los cinco niveles de prueba. Pronto habrá más.',
  translate:'Traducir',quit:'Salir del nivel',listen:'Escuchar',you:'Tú',yourChoice:'Tu elección',yourResponse:'Tu respuesta',tryAgain:'Intentar otra vez',theAnswer:'La respuesta es:',
  hSerEstar:'“{w}” es una forma de <i>ser</i>. Aquí se necesita <i>estar</i>.',hEstarSer:'“{w}” es una forma de <i>estar</i>. Aquí se necesita <i>ser</i>.',hBe:'“{w}” no concuerda con el sujeto. Revisa am / is / are.',
  hEnding:'“{w}” tiene la terminación equivocada. Piensa en quién lo hace.',hSpell:'Revisa cómo se escribe “{w}”.',hWrong:'“{w}” no es la palabra que necesitas. La correcta empieza con “{c}”.',
  hExtra:'“{w}” sobra en esta respuesta.',hMissingAfter:'Falta una palabra después de “{p}”. Empieza con “{c}”.',hMissingStart:'Falta una palabra al principio. Empieza con “{c}”.'}
};
// what the other character says when they don't understand, in the language being learned
const CONFUSED={es:['¿Qué?','¿Cómo?','No entiendo…','¿Eh?','¿Perdón?'],en:['Huh?','What?',"I don't understand…",'Sorry?','Hmm?']};
const NOT_THAT={es:'¡No, por ahí no!',en:'No, not that way!'};
const MAX_LIVES=5;

/* ============ HELPERS ============ */
const app=document.getElementById('app');
const $=s=>document.querySelector(s);
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const shuffle=a=>{a=a.slice();for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;};
const pick=a=>a[Math.floor(Math.random()*a.length)];
const clamp=x=>Math.max(0,Math.min(1,x));
const parseLine=s=>s.split(' / ').map(c=>{const [es,en]=c.split('|');return {es,en};});
const cap=s=>s.charAt(0).toUpperCase()+s.slice(1);
const fmt=s=>{s=Math.round(s);return Math.floor(s/60)+':'+String(s%60).padStart(2,'0');};

let screenId=0, keyHandler=null, timer=null;
function later(fn,ms){const id=screenId;setTimeout(()=>{if(id===screenId)fn();},ms);}
document.addEventListener('keydown',e=>{if(keyHandler&&!e.isComposing)keyHandler(e);});
function stopTimer(){if(timer){clearInterval(timer);timer=null;}}
function show(html){stopTimer();screenId++;keyHandler=null;app.innerHTML=html;window.scrollTo(0,0);wireSpeak(app);}

/* ---- answer checking ---- */
const CONTR=[[/\bi'm\b/g,'i am'],[/\bim\b/g,'i am'],[/\bit's\b/g,'it is'],[/\bits\b/g,'it is'],[/\bwhat's\b/g,'what is'],[/\bwhats\b/g,'what is'],[/\bdon't\b/g,'do not'],[/\bi'd\b/g,'i would'],[/\byou're\b/g,'you are'],[/\bthey're\b/g,'they are'],[/\bwanna\b/g,'want to']];
function norm(s,keepAccents){
  s=String(s).toLowerCase().replace(/[’‘`´]/g,"'");
  CONTR.forEach(([r,v])=>{s=s.replace(r,v);});
  if(!keepAccents)s=s.normalize('NFD').replace(/[\u0300-\u036f]/g,'');
  return s.replace(/[¿?¡!.,;:"'()]/g,' ').replace(/\s+/g,' ').trim();
}
function lev(a,b){
  if(Math.abs(a.length-b.length)>3)return 99;
  let p=Array.from({length:b.length+1},(_,j)=>j);
  for(let i=1;i<=a.length;i++){const c=[i];for(let j=1;j<=b.length;j++)c[j]=Math.min(p[j]+1,c[j-1]+1,p[j-1]+(a[i-1]===b[j-1]?0:1));p=c;}
  return p[b.length];
}
// words whose small spelling differences change the grammar (ser/estar, person, tense…): never "close enough"
const GRAM=new Set('soy eres es somos son estoy estas esta estamos estan estoy fue era tengo tienes tiene tenemos tienen llamo llamas llama quiero quieres quiere puedo puedes puede voy vas va como comes come am is are was were have has do does go goes'.split(' '));
function typoOk(a,b){
  const A=a.split(' '),B=b.split(' ');if(A.length!==B.length)return false;
  let diff=0;
  for(let i=0;i<A.length;i++){
    const x=A[i],y=B[i];if(x===y)continue;
    if(x.length<5||GRAM.has(x)||GRAM.has(y)||lev(x,y)>1||x[0]!==y[0]||x.slice(-2)!==y.slice(-2))return false;
    diff++;
  }
  return diff>0&&diff<=2;
}
const SER=new Set('ser soy eres es somos son fue era'.split(' ')), ESTAR=new Set('estar estoy estas esta estamos estan'.split(' ')), BE=new Set('am is are was were be'.split(' '));
// line the answer up word by word with the closest accepted answer, and explain the first thing that differs
function align(u,c){
  const m=u.length,n=c.length,d=Array.from({length:m+1},(_,i)=>Array.from({length:n+1},(_,j)=>i?j?0:i:j));
  for(let i=1;i<=m;i++)for(let j=1;j<=n;j++)d[i][j]=Math.min(d[i-1][j]+1,d[i][j-1]+1,d[i-1][j-1]+(u[i-1]===c[j-1]?0:1));
  const ops=[];let i=m,j=n;
  while(i||j){
    if(i&&j&&d[i][j]===d[i-1][j-1]+(u[i-1]===c[j-1]?0:1)){ops.unshift([u[i-1]===c[j-1]?'eq':'sub',u[i-1],c[j-1]]);i--;j--;}
    else if(i&&d[i][j]===d[i-1][j]+1){ops.unshift(['del',u[i-1]]);i--;}
    else{ops.unshift(['ins',null,c[j-1]]);j--;}
  }
  return ops;
}
function hintFor(input,accepted){
  const u=norm(input).split(' ').filter(Boolean);
  let best=null;
  for(const a of accepted){const ops=align(u,norm(a).split(' '));const cost=ops.filter(o=>o[0]!=='eq').length;if(!best||cost<best.cost)best={ops,cost};}
  const k=best.ops.findIndex(o=>o[0]!=='eq');if(k<0)return '';
  const [op,uw,cw]=best.ops[k];
  let prev=null;for(let i=k-1;i>=0;i--){if(best.ops[i][1]){prev=best.ops[i][1];break;}}
  const f=(key,o)=>t(key).replace(/\{(\w)\}/g,(_,x)=>esc(o[x]||''));
  if(op==='del')return f('hExtra',{w:uw});
  if(op==='ins')return f(prev?'hMissingAfter':'hMissingStart',{p:prev,c:cw[0]});
  if(tgt()==='es'&&SER.has(uw)&&ESTAR.has(cw))return f('hSerEstar',{w:uw});
  if(tgt()==='es'&&ESTAR.has(uw)&&SER.has(cw))return f('hEstarSer',{w:uw});
  if(tgt()==='en'&&BE.has(uw)&&BE.has(cw))return f('hBe',{w:uw});
  if((GRAM.has(uw)||GRAM.has(cw))&&uw.length>2&&cw.length>2&&uw.slice(0,2)===cw.slice(0,2))return f('hEnding',{w:uw});
  if(lev(uw,cw)<=2)return f('hSpell',{w:uw});
  return f('hWrong',{w:uw,c:cw[0]});
}
/* returns {ok, kind:'exact'|'accent'|'typo'|'alt', canon} — accepted[0] is the model answer shown back to the player */
function grade(input,accepted){
  const canon=accepted[0], v=norm(input), vA=norm(input,true);
  if(!v)return {ok:false,canon};
  if(norm(canon,true)===vA)return {ok:true,kind:'exact',canon};
  if(norm(canon)===v)return {ok:true,kind:'accent',canon};
  if(accepted.slice(1).some(a=>norm(a)===v))return {ok:true,kind:'alt',canon};
  if(typoOk(norm(canon),v))return {ok:true,kind:'typo',canon};
  if(accepted.slice(1).some(a=>typoOk(norm(a),v)))return {ok:true,kind:'alt',canon};
  return {ok:false,canon};
}
function gradeNote(g){
  if(g.kind==='accent')return `${t('accentNote')} <b>${esc(g.canon)}</b>`;
  if(g.kind==='typo')return `${t('typoNote')} <b>${esc(g.canon)}</b>`;
  if(g.kind==='alt')return `${t('altNote')} <b>${esc(g.canon)}</b>`;
  return '';
}

/* ---- speech ---- */
const canSpeak='speechSynthesis' in window;
const speakerIcon='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 9h4l5-4v14l-5-4H4z" fill="currentColor"/><path d="M16 8.5a5 5 0 0 1 0 7M18.5 6a8.5 8.5 0 0 1 0 12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';
/* ============ MORE INTERFACE WORDS (beta 2) ============ */
Object.assign(UI.en,{
  allDone:'You finished every world in this beta. ¡Felicidades!',
  review:'Garden review',reviewDue:'words ready to review',reviewDue1:'word ready to review',reviewNone:'Nothing due. Practice your weakest words',reviewGo:'Review',reviewTitle:'Daily garden review',
  reviewIntro:'These words are about to slip away. Bring them back before they wilt.',reviewDone:'Review done',reviewKept:'words strengthened',
  streak:'day streak',streakDays:'days in a row',worldOf:'World',levelsDone:'levels done',locked:'Locked',
  newWord:'New',reviewWord:'Review',matchIt:'Match the pairs',listenPick:'Listen. What did you hear?',play:'Play',
  hardMode:'Hard mode',hardDesc:'No translations and no hints. Earn a gold ring.',hardDone:'Hard mode cleared',
  hintBtn:'Hint',hintUsed:'hints used',tipTitle:'Grammar tip',canNow:'You can now',wordsLearned:'Words from this level',
  slow:'Slow',sound:'Sound',on_:'On',off_:'Off',listenStep:'Listen to what they say',hearAgain:'Hear it again',heardLine:'They said:',
  boss:'Final conversation',storyBegin:'Begin',storyNext:'Continue',cleared:'Cleared',translatedCounts:'Only words from this level’s lesson count as translations.',
  mapTitle:'The road to the Carrot Festival',chooseLevel:'Choose a level',worldDone:'World complete'
});
Object.assign(UI.es,{
  allDone:'Terminaste todos los mundos de esta beta. Congratulations!',
  review:'Repaso del huerto',reviewDue:'palabras para repasar',reviewDue1:'palabra para repasar',reviewNone:'Nada pendiente. Practica tus palabras más débiles',reviewGo:'Repasar',reviewTitle:'Repaso diario del huerto',
  reviewIntro:'Estas palabras se están olvidando. Repásalas antes de que se marchiten.',reviewDone:'Repaso terminado',reviewKept:'palabras reforzadas',
  streak:'días seguidos',streakDays:'días seguidos',worldOf:'Mundo',levelsDone:'niveles completos',locked:'Bloqueado',
  newWord:'Nueva',reviewWord:'Repaso',matchIt:'Une las parejas',listenPick:'Escucha. ¿Qué oíste?',play:'Jugar',
  hardMode:'Modo difícil',hardDesc:'Sin traducciones ni pistas. Gana un anillo dorado.',hardDone:'Modo difícil superado',
  hintBtn:'Pista',hintUsed:'pistas usadas',tipTitle:'Consejo de gramática',canNow:'Ahora puedes',wordsLearned:'Palabras de este nivel',
  slow:'Lento',sound:'Sonido',on_:'Sí',off_:'No',listenStep:'Escucha lo que dice',hearAgain:'Escuchar otra vez',heardLine:'Dijo:',
  boss:'Conversación final',storyBegin:'Empezar',storyNext:'Continuar',cleared:'Superado',translatedCounts:'Solo cuentan como traducciones las palabras de la lección de este nivel.',
  mapTitle:'El camino a la Fiesta de la Zanahoria',chooseLevel:'Elige un nivel',worldDone:'Mundo completo'
});

/* ============ SAVE (v2) ============ */
const SAVE_KEY='el-conejo-beta2';
function blankSave(){return {target:null,sound:true,lang:{es:{stars:{},hard:{},words:{},streak:{n:0,last:null,freeze:null},intro:{}},en:{stars:{},hard:{},words:{},streak:{n:0,last:null,freeze:null},intro:{}}}};}
function loadSave(){try{const s=JSON.parse(localStorage.getItem(SAVE_KEY));if(s&&s.lang&&s.lang.es&&s.lang.en)return s;}catch(e){}return blankSave();}
let save=loadSave();
function persist(){try{localStorage.setItem(SAVE_KEY,JSON.stringify(save));}catch(e){}}
const tgt=()=>save.target, nat=()=>save.target==='es'?'en':'es';
const t=k=>UI[nat()][k];
const me=()=>save.lang[tgt()];
const today=()=>{const d=new Date();return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');};
const dayNum=s=>Math.round(Date.parse(s+'T12:00:00')/864e5);

/* ============ CONTENT ============ */
let WORLDS=[], LEVELS=[];
async function loadContent(){
  const files=['content/w1.json','content/w2.json','content/w3.json','content/w4.json'];
  const got=await Promise.allSettled(files.map(f=>fetch(f).then(r=>{if(!r.ok)throw new Error(f);return r.json();})));
  WORLDS=got.filter(g=>g.status==='fulfilled').map(g=>g.value);
  if(!WORLDS.length)throw new Error(files[0]);
  LEVELS=WORLDS.flatMap(w=>w.levels.map((l,i)=>Object.assign(l,{world:w.id,num:i+1,boss:i===w.levels.length-1})));
}
const levelById=id=>LEVELS.find(l=>l.id===id);
const levelIndex=id=>LEVELS.findIndex(l=>l.id===id);
const starsOf=id=>me().stars[id]||0;
const unlocked=id=>{const i=levelIndex(id);return i===0||starsOf(LEVELS[i-1].id)>0;};
const worldUnlocked=w=>unlocked(WORLDS[w-1].levels[0].id);

/* ============ WORD MEMORY (spaced review) ============
   Every lesson item is tracked per learner. A right answer moves it up a box, a miss sends it back to box 0.
   Box n comes back after GAPS[n] days, so practice lands just before a word is forgotten. */
const GAPS=[0,1,3,7,14,30,60];
const wkey=it=>norm(it[tgt()]);
function wordRec(it,lv){
  const W=me().words, k=wkey(it);
  if(!W[k])W[k]={es:it.es,en:it.en,alt:it.alt||null,lv,box:0,due:today(),seen:0,right:0,wrong:0};
  return W[k];
}
function wordResult(it,lv,ok){
  const r=wordRec(it,lv);r.seen++;
  if(ok){r.right++;r.box=Math.min(GAPS.length-1,r.box+1);}else{r.wrong++;r.box=0;}
  r.due=new Date((dayNum(today())+GAPS[r.box])*864e5).toISOString().slice(0,10);
  persist();
}
function weaken(it,lv){const r=wordRec(it,lv);r.box=0;r.due=today();persist();}
const dueWords=()=>Object.values(me().words).filter(r=>r.seen>0&&dayNum(r.due)<=dayNum(today())).sort((a,b)=>a.box-b.box||dayNum(a.due)-dayNum(b.due));
const weakWords=()=>Object.values(me().words).filter(r=>r.seen>0).sort((a,b)=>(a.right-a.wrong)-(b.right-b.wrong)||a.box-b.box);
function streakTouch(){
  const s=me().streak, d=dayNum(today());
  if(s.last===today())return;
  const gap=s.last?d-dayNum(s.last):99;
  const week=Math.floor(d/7);
  if(gap===1)s.n++;
  else if(gap===2&&s.freeze!==week){s.n++;s.freeze=week;}
  else s.n=1;
  s.last=today();persist();
}
const streakNow=()=>{const s=me().streak;if(!s.last)return 0;const gap=dayNum(today())-dayNum(s.last);return gap<=1||(gap===2&&s.freeze!==Math.floor(dayNum(today())/7))?s.n:0;};

/* ============ SOUND ============ */
let actx=null;
function sfx(kind){
  if(!save.sound)return;
  try{
    actx=actx||new (window.AudioContext||window.webkitAudioContext)();
    const now=actx.currentTime, g=actx.createGain();g.connect(actx.destination);
    const tone=(f1,f2,dur,type='sine',vol=.12,delay=0)=>{const o=actx.createOscillator(),gg=actx.createGain();o.type=type;o.frequency.setValueAtTime(f1,now+delay);o.frequency.exponentialRampToValueAtTime(f2,now+delay+dur);gg.gain.setValueAtTime(0.0001,now+delay);gg.gain.exponentialRampToValueAtTime(vol,now+delay+.015);gg.gain.exponentialRampToValueAtTime(0.0001,now+delay+dur);o.connect(gg);gg.connect(g);o.start(now+delay);o.stop(now+delay+dur+.02);};
    if(kind==='hop')tone(320,520,.09,'sine',.05);
    else if(kind==='ok'){tone(660,660,.12,'triangle',.1);tone(880,880,.16,'triangle',.1,.1);}
    else if(kind==='bad')tone(300,200,.25,'triangle',.08);
    else if(kind==='coin'){tone(988,988,.07,'square',.04);tone(1319,1319,.18,'square',.04,.07);}
    else if(kind==='pop'){tone(200,900,.12,'sine',.14);tone(1200,1600,.08,'triangle',.06,.1);}
    else if(kind==='splash'){const b=actx.createBuffer(1,actx.sampleRate*.35,actx.sampleRate),d=b.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=(Math.random()*2-1)*Math.pow(1-i/d.length,2);const s=actx.createBufferSource(),f=actx.createBiquadFilter();f.type='bandpass';f.frequency.value=1200;s.buffer=b;s.connect(f);f.connect(g);g.gain.value=.25;s.start();}
    else if(kind==='click')tone(800,600,.04,'square',.03);
    else if(kind==='win'){[523,659,784,1047].forEach((f,i)=>tone(f,f,.18,'triangle',.09,i*.11));}
  }catch(e){}
}

/* ============ SPEECH: normal and slow ============ */
function speak(text,rate){try{if(!canSpeak)return;const u=new SpeechSynthesisUtterance(text);u.lang=tgt()==='es'?'es-MX':'en-US';u.rate=rate||.9;speechSynthesis.cancel();speechSynthesis.speak(u);}catch(e){}}
const slowIcon='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 15c0-4 3-7 8-7s8 3 8 7z" fill="currentColor"/><path d="M19 13c1.5 0 2.5-1 2.5-2.2S20.5 9 19.4 9.4" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/><path d="M6 15v2.5M10 15v2.5M14 15v2.5M17 15v2.5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>';
const speakBtn=(text)=>canSpeak?`<span class="spk"><button class="speak" data-speak="${esc(text)}" aria-label="${t('listen')}">${speakerIcon}</button><button class="speak slowb" data-slow="${esc(text)}" aria-label="${t('slow')}">${slowIcon}</button></span>`:'';
function wireSpeak(root){
  root.querySelectorAll('[data-speak]').forEach(b=>b.onclick=e=>{e.stopPropagation();speak(b.dataset.speak);});
  root.querySelectorAll('[data-slow]').forEach(b=>b.onclick=e=>{e.stopPropagation();speak(b.dataset.slow,.55);});
}
