/* ============ CHARACTERS ============ */
const NPCS={
  turtle:{art:'turtle',es:'Tortuga',en:'Turtle',speed:95,faces:1,head:36,sh:22},
  fox:{art:'fox',es:'Zorro',en:'Fox',speed:130,faces:1,head:52,sh:22},
  hedgehog:{art:'hedgehog',es:'Erizo',en:'Hedgehog',speed:100,faces:1,head:46,sh:20},
  owl:{art:'owl',es:'Búho',en:'Owl',speed:170,fly:1,head:48,sh:0},
  frog:{art:'frog',es:'Rana',en:'Frog',speed:130,head:34,sh:17},
  mole:{art:'mole',es:'Topo',en:'Mole',speed:90,faces:1,head:30,sh:20},
  hen:{art:'hen',es:'Gallina',en:'Hen',speed:110,faces:1,head:48,sh:18},
  squirrel:{art:'squirrel',es:'Ardilla',en:'Squirrel',speed:150,faces:1,head:46,sh:16},
  mouse:{art:'mouse',es:'Ratón',en:'Mouse',speed:130,faces:1,head:44,sh:16},
  cat:{art:'cat',es:'Gato',en:'Cat',speed:140,faces:1,head:44,sh:20},
  goat:{art:'goat',es:'Cabra',en:'Goat',speed:120,faces:1,head:50,sh:22},
  pigeon:{art:'pigeon',es:'Paloma',en:'Pigeon',speed:140,faces:1,head:38,sh:14},
  abuela:{art:'abuela',es:'Abuela',en:'Grandma',speed:110,faces:1,head:74,sh:24}
};
const npcOf=L=>NPCS[L.npc];

/* ============ SCENES ============
   A level's scene is data: presets for sky, ground and backdrop, then a list of props.
   Each prop is [name, ...arguments]; an argument written as {"es":…,"en":…} is shown in the language being learned. */
const SKIES={day:['#B9E0F2','#EAF6E6'],warm:['#FCE0C0','#FBF2DF'],forest:['#BCD8CB','#E1EEDC'],cool:['#C6D3E5','#EEF2E4'],evening:['#F4C7A6','#EEDDE6'],rain:['#A9B8C6','#D7DFE3'],city:['#BFDDF0','#EEF1EC']};
const GROUNDS={grass:['#A9D27F','#86B95C'],meadow:['#B5CF83','#9DBB69'],forest:['#93C273','#74A957'],town:['#D9CDB4','#C9BB9C'],city:['#B9C3A6','#9FAE8A']};
const lang=v=>v&&typeof v==='object'&&!Array.isArray(v)&&('es' in v)?v[tgt()]:v;
function buildScene(L,npcG,bunG){
  const sc=L.scene, W=sc.w, k='s'+L.id;
  ZN=[];
  const [a,b]=SKIES[sc.sky]||SKIES.day, [g1,g2]=GROUNDS[sc.ground||'grass'];
  let s='';
  if(sc.sky==='indoor'){s+=G.room(W);}
  else{
    s+=G.sky(k,a,b,g1,g2)+G.base(k,W);
    if(sc.sky!=='rain')s+=G.sun(sc.sun||Math.round(W*.12),58);
    const nc=Math.max(2,Math.round(W/380));for(let i=0;i<nc;i++)s+=sc.sky==='rain'?G.cloudDark(60+i*W/nc,24+(i%2)*18):G.cloud(140+i*W/nc,32+(i%2)*28,.8+(i%3)*.15);
    const bd=sc.back||'hills';
    if(bd==='hills')s+=G.hills(W,168,14,'#D3E8BB',260)+Array.from({length:Math.round(W/260)},(_,i)=>G.smalltree(60+i*260+((i*97)%80),174,.85)).join('');
    if(bd==='town')s+=G.hills(W,170,10,'#E3DCC0',260)+G.townBack(W);
    if(bd==='pines')s+=G.pinesBack(W);
    if(bd==='mountains')s+=G.mountains(W)+G.hills(W,172,10,'#C9DDB2',240);
    if(bd==='city')s+=G.skyline(W);
    s+=G.ground(k,W);
    if(sc.sky==='rain')s+=G.rainfall(W);
  }
  for(const it of sc.items)s+=prop(it,npcG);
  // characters never stand on flowers or grass tufts
  const spots=[sc.start,...L.nodes.flatMap(n=>[n.b,n.n,n.from].filter(Boolean)),...sc.finale.walk];
  const n0=ZN.length;
  spots.forEach(([x,y])=>Z.rect(x-34,y-90,68,94));
  for(let i=n0;i<ZN.length;i++)ZN[i]=ZN[i].replace('<rect ','<rect data-spot="1" ');
  s=s.includes('%NPC%')?s.replace('%NPC%',npcG)+bunG:s+npcG+bunG;
  return s+`<g class="ng" opacity="0" fill="#000">${ZN.join('')}</g>`;
}
function prop(it,npcG){
  const [name,...args0]=it, args=args0.map(lang);
  if(name==='npc')return '%NPC%';
  if(name==='g')return `<g id="${args[0]}"${args[2]?` class="${args[2]}"`:''}>${args0[1].map(x=>prop(x,npcG)).join('')}</g>`;
  if(name==='zone'){Z.rect(...args);return '';}
  if(name==='tint')return `<rect x="${args[0]}" y="0" width="${args[1]}" height="300" fill="${args[2]||'#1F4A2A'}" opacity="${args[3]||.18}"/>`;
  if(name==='raw')return args[0];
  if(!G[name]){console.warn('unknown prop',name);return '';}
  return G[name](...args);
}
